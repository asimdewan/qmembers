

(function ($) {
    Drupal.behaviors.qmembers1 = {
        attach: function (context) {

            var qmembers_vars = $('#qmembers-js-vars-workaround').attr('data-json');
            qmembers_vars = JSON.parse(qmembers_vars);


            $('form').submit(function (event) {

                event.preventDefault();

                var form_id = $(this).attr('id');

                submitForm(form_id);
            });


            $('.qmembers-form-submit-send').click(function(){

                var form_id = $(this).attr('data-form-id');

                $('.qmembers-loading').show();

                submitForm(form_id);
            });

            function submitForm(form_id){

                var form      = $('form#' + form_id);
                var form_data = form.serialize(); //Encode form elements for submission
                var post_url  = form.attr("action"); //get form action url
                var request_method = 'POST';

                // Exclude forms
                if (form_id == 'qmembers-form-personal-picture') return false;
                else if (form_id == 'qmembers-service-provider') return false;
                else if (form_id.includes("qmembers-restricted-uploads") == true) return false;
                // -------------

                jQuery.ajax({
                    url: post_url,
                    type: request_method,
                    data: form_data
                }).done(function (response) { //

                    $('.qmembers-loading').hide();

                    response = response.trim();

                    var isJson = true;
                    try {
                        responseObject = $.parseJSON(response);
                    }
                    catch (err) {
                        isJson = false;
                    }

                    // Clear error fields
                    $(":text,:password,[type='email'],select").each(function(){
                        $(this).css("background-color", "transparent");
                    });

                    $("[id*='_error']").each(function(){
                        $(this).html('');
                    });

                    if (isJson) {
                        $.each(responseObject, function (key, value) {
                            $('#' + key).css("background-color", "#EFB1B7");
                            $('#' + key + '_error').html("<br/>"+value);
                        });
                    } else {

                        $('#' + form_id + '-result').html(response);
                    }

                });
            }

            // billing address - other
            $('input[type=radio][name="billing_address_membership"]').change(function() {
                if (this.value == '3') {
                    $('#form-billing_other-membership').attr("hidden",false);
                    $('#form-billing_other-membership-buttons-2').attr("hidden",false);
//                    $('#form-billing_normal-membership').attr("hidden",true);
                }
                else {
                    $('#form-billing_other-membership').attr("hidden",true);
                    $('#form-billing_other-membership-buttons-2').attr("hidden",true);
//                    $('#form-billing_normal-membership').attr("hidden",false);
                }
            });

            // display regions (federal states)
            $('select#country_personal,select#country_professional,select#country_membership').change(function() {

                if (this.value == 'Germany' || this.value == 'Deutschland') {
                    $('.qmembers-form-state-wrapper').addClass('qmembers-form-state-wrapper-active');
                }
                else {
                    $('.qmembers-form-state-wrapper').removeClass('qmembers-form-state-wrapper-active');
                    $('.qmembers-form-state-wrapper select option').removeAttr("selected");
                }
            });

            // termination form
            $('#form-member-data-membership-termination-button').click(function() {
                $('#form-membership-termination').attr("hidden",false);
                $('#form-member-data-membership-termination-button').attr("hidden",true);
            });

            $('#form-member-data-termination-cancel-button').click(function() {
                $('#form-membership-termination').attr("hidden",true);
                $('#form-member-data-membership-termination-button').attr("hidden",false);
            });


            // Display member list count
            var count = $('#qmembers-form-memberlist-count-hidden').attr('data-count');
            $('#qmembers-form-memberlist-count').html(count);
            if (count == 1){

                $('#qmembers-form-memberlist-count-text').html('Mitglied');
            }

            // Service provider
            $('form#qmembers-service-provider').submit(function (event) {
                event.preventDefault();

                var resetFilter = true;
                searchServiceProvider(resetFilter);
            });

            $('form#qmembers-service-provider-search-filter').submit(function (event) {
                event.preventDefault();

                var resetFilter = false;
                searchServiceProvider(resetFilter);
            });

            $('#qmembers-service-provider-filter2 span').click(function(){

                var filter2 = $(this).attr('data-value');
                $('form#qmembers-service-provider-search-filter input[name="filter2"]').val(filter2);

                var resetFilter = false;
                searchServiceProvider(resetFilter);
            });

            function searchServiceProvider(resetFilter){

                var search  = $('form#qmembers-service-provider input[name="search"]').val();
                var filter1 = '';
                var filter2 = '';

                if (!resetFilter){
                    filter1 = $('form#qmembers-service-provider-search-filter input[name="filter1"]').val();
                    filter2 = $('form#qmembers-service-provider-search-filter input[name="filter2"]').val();
                }

                /*
                var parameter =        Drupal.settings.qmembers.list_search_parameter_name              + '=' + search;
                    parameter += '&' + Drupal.settings.qmembers.service_provider_parameter_name_filter1 + '=' + filter1;
                    parameter += '&' + Drupal.settings.qmembers.service_provider_parameter_name_filter2 + '=' + filter2;
                */

                var parameter =    qmembers_vars.list_search_parameter_name              + '=' + search;
                parameter += '&' + qmembers_vars.service_provider_parameter_name_filter1 + '=' + filter1;
                parameter += '&' + qmembers_vars.service_provider_parameter_name_filter2 + '=' + filter2;

                window.location.search = parameter;
            }

        }
    }
})(jQuery);



// Toggle elements
function qmembersToggle(element){
    jQuery(element).toggle();
}

// Display/Hide Menu
jQuery( window ).resize(function() {

    if (window.innerWidth > 1205){
        jQuery('#qmembers-page-sidebar').show();
    }
    else{
        jQuery('#qmembers-page-sidebar').hide();
    }
});

