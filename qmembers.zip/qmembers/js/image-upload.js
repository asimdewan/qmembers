
(function ($) {
    Drupal.behaviors.qmembers2 = {
        attach: function (context) {


            $(document).ready(function(){
                $image_crop = $('#qmembers-personal-picture').croppie({
                    viewport: {
                        width: 180,
                        height: 180,
                        type: 'square'
                    },
                    boundary: {
                        width: 180,
                        height: 180
                    }
                });


                // change of profile image
                $("#picture_personal").change(function(){

                    $("label.qmembers-form-personal-picture-label-alone").addClass('qmembers-form-personal-picture-label').removeClass('qmembers-form-personal-picture-label-alone');
                    $("button.qmembers-form-personal-picture-submit").show();


                    if (this.files && this.files[0]) {

                        var maxFileSizeMB = $(this).attr('data-max-image-size');
                        // precheck file size
                        var _size = this.files[0].size;
                        var fSExt = new Array('Bytes', 'KB', 'MB', 'GB'),
                            i=0;while(_size>900){_size/=1024;i++;}
                        if ( fSExt[i] == 'GB' ) {
                            alert ('Das Bild darf maximal ' + maxFileSizeMB + ' MB groß sein.');
                            return false;
                        }

                        if ( fSExt[i] == 'MB' ) {
                            var exactSize = (Math.round(_size*100)/100); // MB

                            if (exactSize > maxFileSizeMB){
                                alert('Das Bild darf maximal ' + maxFileSizeMB + ' MB groß sein.');
                                return false;
                            }
                        }

                        var reader = new FileReader();
                        reader.onload = function (e) {
                            $('.qmembers-personal-picture-default').hide();
                            $('.qmembers-personal-picture-box').show();

                            $image_crop.croppie('bind', {
                                url: e.target.result
                            }).then(function(){
                                $original_image = e.target.result;
                            });
                        };
                        reader.readAsDataURL(this.files[0]);

                    }
                });

                // submit profile image
                $('form#qmembers-form-personal-picture').submit(function (event) {

                    event.preventDefault();
                    // Submit file
                    var form_id = $(this).attr('id');
                    var post_url = $(this).attr('action');
                    var request_id = $('.request_id', this).val();
                    var request_method = 'POST';

                    $image_crop.croppie('result', {
                        type: 'canvas',
                        size: 'viewport'
                    }).then(function (response) {

                        var formData = new FormData();
                        formData.append('picture_personal', response);
                        formData.append('request_id', request_id);

                        if (typeof $original_image == 'undefined') {
                            //console.log('Original Image did not change');
                        } else {
                            formData.append('original_picture_personal', $original_image);
                        }

                        jQuery.ajax({
                            type: request_method,
                            enctype: 'multipart/form-data',
                            url:  post_url,
                            data: formData,
                            contentType: false,
                            cache: false,
                            processData:false
                        }).done(function (response) {
                            response = response.trim();
                            var isJson = true;
                            try {
                                responseObject = $.parseJSON(response);
                            }
                            catch (err) {
                                isJson = false;
                            }

                            if (isJson) {
                                if (responseObject.image_url) {

                                    $('#' + form_id + '-result').addClass('qmembers-form-personal-picture-result-positive').html('Bild gespeichert.');
                                    window.location.reload();
                                }
                            } else {
                                $('#' + form_id + '-result').html(response);
                            }
                        });
                    });
                });

            });


        }
    }
})(jQuery);