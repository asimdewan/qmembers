
(function ($) {
    Drupal.behaviors.qmembers3 = {
        attach: function (context) {

            $(document).ready(function(){

                $('form').submit(function (event) {

                    event.preventDefault();

                    var form_id = $(this).attr('id');

                    if (form_id.includes("qmembers-restricted-uploads") == true){

                        if (form_id.includes("multipart") == true) submitMultipartForm(form_id);
                        else submitForm(form_id);
                    }
                });

                function submitForm(form_id){

                    var form      = $('form#' + form_id);
                    var form_data = form.serialize(); //Encode form elements for submission
                    var post_url  = form.attr("action"); //get form action url
                    var request_method = 'POST';

                    jQuery.ajax({
                        url: post_url,
                        type: request_method,
                        data: form_data
                    }).done(function (response) { //

                        response = response.trim();

                        var isJson = true;
                        try {
                            responseObject = $.parseJSON(response);
                        }
                        catch (err) {
                            isJson = false;
                        }

                        if (isJson) {

                        } else {
                            $('#' + form_id + '-result').html(response);
                        }

                    });
                }

                function submitMultipartForm(form_id){

                   // Add your code to submit a multipart form

                }

            });

        }
    }
})(jQuery);