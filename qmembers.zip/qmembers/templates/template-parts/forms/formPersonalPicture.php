<?php ?>

<div class="qmembers-form-picture">
    <div class="qmembers-personal-picture-default">
        <?php if (empty($personal_picture)) :?>
            <img src="<?php echo QMEMBERS_FILE_URL_PROFILE_PLACEHOLDER_IMAGE;?>" >
        <?php else: ?>
            <img src="<?php echo $personal_picture;?>" >
        <?php endif; ?>
    </div>

    <div class="qmembers-personal-picture-box" style="display: none;">
        <img id="qmembers-personal-picture" src="<?php echo $personal_picture;?>" >
    </div>

    <form id="qmembers-form-personal-picture" action="<?php echo QMEMBERS_DRUPAL_AJAX_PATH;?>">
        <label for="picture_personal" class="qmembers-form-personal-picture-label-alone"><?php echo $qmembers_text->get('picture_personal'); ?>
            <input type="file" id="picture_personal" name="picture_personal" data-max-image-size="<?php echo $qmembers_config['max-image-size-picture-personal'];?>" />
        </label>
        <br/>
        <input type="hidden" class="request_id" name="request_id" value="formPersonalPictureSubmit"/>
        <button type="submit" class="qmembers-form-personal-picture-submit">
            <span class="qmembers-form-personal-picture-submit-text">
                <?php echo $qmembers_text->get('picture_personal-submit-button'); ?>
                <i class="fa fa-check fa-lg"></i>
            </span>
        </button>

        <div id="qmembers-form-personal-picture-result"></div>

        <div id="qmembers-form-personal-picture-info"><?php echo $qmembers_text->get('picture_personal-upload-info'); ?></div>
    </form>

</div>
