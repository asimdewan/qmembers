<div class="qmembers-form-memberlist">

    <div class="qmembers-form-memberlist-picture-container" style="background-image: url(<?php echo $value['personal_picture']; ?>)"></div>

    <div class="qmembers-form-data-memberlist-detail">
        <div class="qmembers-form-data-memberlist-member">
            <div><?php echo $value['first_name_personal']; ?> <?php echo $value['last_name_personal']; ?></div>
            <div><?php echo $value['function_professional']; ?>, <?php echo $value['company_professional']; ?></div>
        </div>
        <div><?php echo $value['city_professional']; ?></div>
        <?php /*
        <div class="qmembers-form-data-memberlist-email">
            <a href="mailto:<?php echo $value['email_professional']; ?>"><?php echo $this->text->get('contact_memberlist'); ?></a>
        </div>
        */?>
    </div>
</div>

