<?php

    $session_name = $qmembers_config['session']['name'];

?>


<div>
    <?php echo $qmembers_text->get('form-member-data-personal-explanation'); ?>
</div>

<?php require QMEMBERS_PATH_FORMS . 'formPersonalPicture.php';?>

<form id="<?php echo $form_id; ?>" class="qmembers-form" action="<?php echo QMEMBERS_DRUPAL_AJAX_PATH;?>">

    <div class="qmembers-form" >

        <div class="qmembers-label-input-error-wrapper qmembers-label-input-error-wrapper-first">
            <label for="salutation_personal"><?php echo $qmembers_text->get('salutation_personal'); ?><span><?php echo $qmembers_text->get('mandatory_sign'); ?></span></label>
            <span class="qmembers-input-error-wrapper">
                <select id="salutation_personal" name="salutation_personal">
                    <option value="Weiblich" <?php if( $salution_personal == 'Weiblich' ) echo 'selected="selected"';?> >
                        <?php echo $qmembers_text->get('form-member-data-personal-salutation-mrs');?>
                    </option>
                    <option value="Männlich" <?php if( $salution_personal == 'Männlich' ) echo 'selected="selected"';?>>
                        <?php echo $qmembers_text->get('form-member-data-personal-salutation-mr');?>
                    </option>
                </select>
                <span class="qmembers-error" id="salutation_personal_error"></span>
            </span>
        </div>

        <div class="qmembers-label-input-error-wrapper">
            <label for="title_personal"><?php echo $qmembers_text->get('title_personal'); ?> </label>
            <span class="qmembers-input-error-wrapper">
                <input type="text" id="title_personal" name="title_personal" value="<?php echo $_SESSION[$session_name]['user']['title_personal']; ?>" />
                <span class="qmembers-error" id="title_personal_error"></span>
            </span>
        </div>

        <div class="qmembers-label-input-error-wrapper">
            <label for="first_name_personal"><?php echo $qmembers_text->get('first_name_personal'); ?><span><?php echo $qmembers_text->get('mandatory_sign'); ?></span></label>
            <span class="qmembers-input-error-wrapper">
                <input type="text" id="first_name_personal" name="first_name_personal" value="<?php echo $_SESSION[$session_name]['user']['first_name_personal']; ?>" />
                <span class="qmembers-error" id="first_name_personal_error"></span>
            </span>
        </div>

        <div class="qmembers-label-input-error-wrapper">
            <label for="last_name_personal"><?php echo $qmembers_text->get('last_name_personal'); ?><span><?php echo $qmembers_text->get('mandatory_sign'); ?></span></label>
            <span class="qmembers-input-error-wrapper">
                <input type="text" id="last_name_personal" name="last_name_personal" value="<?php echo $_SESSION[$session_name]['user']['last_name_personal']; ?>" />
                <span class="qmembers-error" id="last_name_personal_error"></span>
            </span>
           <?php /* <span id="sign_info_name_change"></span><span id="info_name_change"> <?php echo $qmembers_text->get('info_name_change'); ?> </span> */?>
        </div>

        <div class="qmembers-label-input-error-wrapper">
            <label for="birthdate_personal"><?php echo $qmembers_text->get('birthdate_personal'); ?><span><?php echo $qmembers_text->get('mandatory_sign'); ?></span></label>
            <span class="qmembers-input-error-wrapper">
                <select id="birthdate_personal_day" name="birthdate_personal_day">
                    <?php
                        $i = 1;
                        while ($i <= 31): ?>

                        <option value="<?php echo $i;?>" <?php if($birthdate_personal_split['day'] == $i) echo 'selected="selected"';?> >
                            <?php echo $i;?>
                        </option>

                    <?php
                        $i++;
                        endwhile;
                    ?>
                </select>

                <select id="birthdate_personal_month" name="birthdate_personal_month">
                    <?php
                    $i = 1;
                    while ($i <= 12): ?>

                        <option value="<?php echo $i;?>" <?php if($birthdate_personal_split['month'] == $i) echo 'selected="selected"';?> >
                            <?php echo $qmembers_text->get('name-of-month-' . $i);?>
                        </option>

                        <?php
                        $i++;
                    endwhile;
                    ?>
                </select>

                <select id="birthdate_personal_year" name="birthdate_personal_year">
                    <?php
                    $i = date('Y', time() ) - 120;
                    while ($i <= date('Y', time() ) ): ?>

                        <option value="<?php echo $i;?>" <?php if($birthdate_personal_split['year'] == $i) echo 'selected="selected"';?> >
                            <?php echo $i;?>
                        </option>

                        <?php
                        $i++;
                    endwhile;
                    ?>
                </select>
            </span>
        </div>

        <div class="qmembers-label-input-error-wrapper">
            <label for="line_personal"><?php echo $qmembers_text->get('line_personal'); ?></label>
            <span class="qmembers-input-error-wrapper">
                <input type="text" id="line_personal" name="line_personal" value="<?php echo $_SESSION[$session_name]['user']['line_personal']; ?>" />
            </span>
        </div>

        <div class="qmembers-label-input-error-wrapper">
            <label for="street_number_personal"><?php echo $qmembers_text->get('street_number_personal'); ?><span><?php echo $qmembers_text->get('mandatory_sign'); ?></span></label>
            <span class="qmembers-input-error-wrapper">
                <input type="text" id="street_number_personal" name="street_number_personal" value="<?php echo $_SESSION[$session_name]['user']['street_number_personal']; ?>" />
                <span class="qmembers-error" id="street_number_personal_error"></span>
            </span>
        </div>

        <div class="qmembers-label-input-error-wrapper">
            <label for="zip_personal"><?php echo $qmembers_text->get('zip_personal'); ?><span><?php echo $qmembers_text->get('mandatory_sign'); ?></span></label>
            <span class="qmembers-input-error-wrapper">
                <input type="text" id="zip_personal" name="zip_personal" value="<?php echo $_SESSION[$session_name]['user']['zip_personal']; ?>" />
                <span class="qmembers-error" id="zip_personal_error"></span>
            </span>
        </div>

        <div class="qmembers-label-input-error-wrapper">
            <label for="city_personal"><?php echo $qmembers_text->get('city_personal'); ?><span><?php echo $qmembers_text->get('mandatory_sign'); ?></span></label>
            <span class="qmembers-input-error-wrapper">
                <input type="text" id="city_personal" name="city_personal" value="<?php echo $_SESSION[$session_name]['user']['city_personal']; ?>" />
                <span class="qmembers-error" id="city_personal_error"></span>
            </span>
        </div>

        <div class="qmembers-label-input-error-wrapper">
            <label for="country_personal"><?php echo $qmembers_text->get('country_personal'); ?><span><?php echo $qmembers_text->get('mandatory_sign'); ?></span></label>
            <span class="qmembers-input-error-wrapper">
                <select name="country_personal" id="country_personal">
                    <option value=""><?php echo $qmembers_text->get('country_personal_choose'); ?></option>
                    <?php foreach ($countries as $country) :?>
                        <option value="<?php echo $country; ?>" <?php echo $_SESSION[$session_name]['user']['country_personal'] == $country ? 'selected="selected"' : ''; ?>><?php echo $country; ?></option>
                    <?php endforeach; ?>
                </select>
                <span class="qmembers-error" id="country_personal_error"></span>
            </span>
        </div>

        <?php if (variable_get('qmembers_show_states_in_forms', TRUE) == TRUE) : ?>

        <div class="qmembers-label-input-error-wrapper qmembers-form-state-wrapper <?php if($_SESSION[$session_name]['user']['country_personal'] == 'Germany' || $_SESSION[$session_name]['user']['country_personal'] == 'Deutschland') echo 'qmembers-form-state-wrapper-active';?>">
            <label for="state_personal"><?php echo $qmembers_text->get('state_personal'); ?> </label>
            <span class="qmembers-input-error-wrapper">
                <?php /*
                    <input type="text" id="state_personal" name="state_personal" value="<?php echo $_SESSION[$session_name]['user']['state_personal']; ?>" />
                */?>
                <select name="state_personal" id="state_personal">
                    <option value=""><?php echo $qmembers_text->get('state_personal_choose'); ?></option>
                    <?php foreach ($states as $state) :?>
                        <option value="<?php echo $state; ?>" <?php echo $_SESSION[$session_name]['user']['state_personal'] == $state ? 'selected="selected"' : ''; ?>><?php echo $state; ?></option>
                    <?php endforeach; ?>
                </select>
                <span class="qmembers-error" id="state_personal_error"></span>
            </span>
        </div>

        <?php endif; ?>

        <br/>

        <div class="qmembers-label-input-error-wrapper">
            <label for="email_personal"><?php echo $qmembers_text->get('email_personal'); ?><span><?php echo $qmembers_text->get('mandatory_sign'); ?></span> <span><?php echo $qmembers_text->get('private'); ?></span></label>
            <span class="qmembers-input-error-wrapper">
                <input type="text" id="email_personal" name="email_personal" value="<?php echo $_SESSION[$session_name]['user']['email_personal']; ?>" />
                <span class="qmembers-error" id="email_personal_error"></span>
            </span>
        </div>

        <div class="qmembers-label-input-error-wrapper">
            <label for="phone_personal"><?php echo $qmembers_text->get('phone_personal'); ?><span><?php echo $qmembers_text->get('mandatory_sign'); ?></span> <span><?php echo $qmembers_text->get('private'); ?></span></label>
            <span class="qmembers-input-error-wrapper">
                <input type="text" id="phone_personal" name="phone_personal" value="<?php echo $_SESSION[$session_name]['user']['phone_personal']; ?>" />
                <span class="qmembers-error" id="phone_personal_error"></span>
            </span>
        </div>

        <div class="qmembers-label-input-error-wrapper">
            <label for="xing_personal"><?php echo $qmembers_text->get('xing_personal'); ?> </label>
            <span class="qmembers-input-error-wrapper">
                <input type="text" id="xing_personal" name="xing_personal" value="<?php echo $_SESSION[$session_name]['user']['xing_personal']; ?>" />
            </span>
        </div>

        <div class="qmembers-label-input-error-wrapper">
            <label for="linkedin_personal"><?php echo $qmembers_text->get('linkedin_personal'); ?> </label>
            <span class="qmembers-input-error-wrapper">
                <input type="text" id="linkedin_personal" name="linkedin_personal" value="<?php echo $_SESSION[$session_name]['user']['linkedin_personal']; ?>" />
            </span>
        </div>

        <div id="result-wrapper">
            <div class="qmembers-loading element-invisible">
                <?php echo $qmembers_text->get('data-is-being-saved');?>
            </div>
            <div id="<?php echo $form_id; ?>-result"></div>
        </div>

        <input type="hidden" name="request_id" value="formMemberDataPersonalSubmit"/>

        <!--<span class="submit-icon">-->
            <input type="button" class="qmembers-form-submit-send" data-form-id="<?php echo $form_id;?>" id="<?php echo $form_id;?>-submit" value="<?php echo $qmembers_text->get('form-member-data-personal-submit-button'); ?>"/>
        <!--</span>-->

        <a href="<?php echo $qmembers_config['url-member-data-personal'] ?>"><?php echo $qmembers_text->get('form-member-data-personal-cancel-button'); ?></a>
        <span id="mandatory-field"><span><?php echo $qmembers_text->get('mandatory_sign'); ?></span> <span><?php echo $qmembers_text->get('mandatory'); ?></span></span>

    </div>
</form>