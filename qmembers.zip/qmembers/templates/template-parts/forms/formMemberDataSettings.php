<?php

$session_name = $qmembers_config['session']['name'];

?>

<div>
    <?php echo $qmembers_text->get('form-member-data-settings-explanation'); ?>
</div>

<form id="<?php echo $form_id; ?>" class="qmembers-form" action="<?php echo QMEMBERS_DRUPAL_AJAX_PATH;?>">

    <div>
        <span id="title_password_settings"><?php echo $qmembers_text->get('title_password_settings'); ?></span>
    </div>


    <label for="password_old_settings"><?php echo $qmembers_text->get('password_old_settings'); ?></label>
    <br/>
    <input type="password" id="password_old_settings" name="password_old_settings" />
    <span class="qmembers-error" id="password_old_settings_error"></span>

    <label for="password_new_settings"><?php echo $qmembers_text->get('password_new_settings'); ?></label>
    <br/>
    <input type="password" id="password_new_settings" name="password_new_settings"/>
    <span class="qmembers-error" id="password_new_settings_error"></span>

    <label for="password_new_repeat_settings"><?php echo $qmembers_text->get('password_new_repeat_settings'); ?></label>
    <br/>
    <input type="password" id="password_new_repeat_settings" name="password_new_repeat_settings"/>
    <span class="qmembers-error" id="password_new_repeat_settings_error"></span>

    <br/>


    <div id="<?php echo $form_id; ?>-result"></div>

    <input type="hidden" name="request_id" value="formMemberDataSettingsSubmit"/>
    <!--<span class="submit-icon">-->
        <input type="submit" id="<?php echo $form_id;?>-submit" value="<?php echo $qmembers_text->get('form-member-data-settings-submit-button'); ?>"/>
    <!--</span>-->
    <?php /*  Cancel button is in design draft, but is not needed here
    <a href="<?php echo $qmembers_config['url-member-data-settings'] ?>"><?php echo $qmembers_text->get('form-member-data-settings-cancel-button'); ?></a>
    */ ?>

</form>



