<?php

?>


<form id="<?php echo $form_id;?>" class="qmembers-form" action="<?php echo QMEMBERS_DRUPAL_AJAX_PATH;?>">

    <div class="qmembers-label-input-error-wrapper">
        <label for="email"><?php echo $qmembers_text->get('email');?>: </label>
        <span class="qmembers-input-error-wrapper">
            <input type="email" id="email" name="email"/>
            <span class="qmembers-error" id="email_error"></span>
        </span>
    </div>

    <br/>

    <div class="qmembers-label-input-error-wrapper">
        <label for="password"><?php echo $qmembers_text->get('password');?>: </label>
        <span class="qmembers-input-error-wrapper">
            <input type="password" id="password" name="password"/>
            <span class="qmembers-error" id="password_error"></span>
        </span>
    </div>

    <div id="<?php echo $form_id;?>-result"></div>

    <input type="hidden" name="request_id" value="formLoginSubmit"/>

    <span class="submit-icon">
        <input type="submit" id="<?php echo $form_id;?>-submit" value="<?php echo $qmembers_text->get('form-login-submit-button');?>"/>
    </span>
    <a id="login-form-pw" href="<?php echo $qmembers_config['url-password-recover'] ?>"><?php echo $qmembers_text->get('form-login-password-recover-button'); ?></a>

</form>

