<?php ?>

<div id="qmembers-service-provider-search-filter-container">

    <div id="qmembers-service-provider-info-text">
        <?php echo $qmembers_text->get('service-provider-info-text'); ?>
    </div>

    <br/>

    <form id="<?php echo $form_id; ?>" class="qmembers-form" action="<?php echo QMEMBERS_CURRENT_URL;?>">

        <div id="qmembers-service-provider-filter1-container">
            <label id="qmembers-service-provider-filter1-label" for="qmembers-service-provider-filter1"><?php echo $qmembers_text->get('service-provider-filter1-label'); ?></label>
            <input type="text"   id="qmembers-service-provider-filter1" name="filter1" placeholder="<?php echo $qmembers_text->get('service-provider-filter1-placeholder'); ?>" value= "<?php echo $filter1; ?>"/>
        </div>

        <div id="qmembers-service-provider-filter2-container">
            <div id="qmembers-service-provider-filter2-label">
                <?php echo $qmembers_text->get('service-provider-filter2-label'); ?>
            </div>

            <div id="qmembers-service-provider-filter2">
                <span data-value="0-9">0-9</span>

                <?php foreach(range('A', 'Z') as $letter):?>

                    <span data-value="<?php echo $letter;?>"><?php echo $letter;?></span>

                <?php endforeach;?>
            </div>
        </div>

        <input type="hidden" name="filter2" value="<?php echo $filter2;?>"/>
    </form>

    <div id="qmembers-service-provider-search-filter-search-reset">
        <a href="<?php echo QMEMBERS_CURRENT_URL_WITHOUT_PARAMS;?>">
            <?php echo $qmembers_text->get('reset-search');?>
        </a>
    </div>
</div>
