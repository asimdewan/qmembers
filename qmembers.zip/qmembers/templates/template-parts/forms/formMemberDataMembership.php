<?php

$session_name = $qmembers_config['session']['name'];

?>

<div>
    <?php echo $qmembers_text->get('form-member-data-membership-explanation'); ?>
</div>

<form id="<?php echo $form_id_prim_email; ?>" class="qmembers-form  qmembers-form-member-data-membership-radio" action="<?php echo QMEMBERS_DRUPAL_AJAX_PATH;?>">

    <label for="prim_email_membership" class="qmembers-form-member-data-membership-label-title"><?php echo $qmembers_text->get('prim_email_membership'); ?></label>

    <br/>
    <div class="qmembers-form-label-title-descr">
        <?php echo $qmembers_text->get('prim_email_membership_descr'); ?>
    </div>

    <div>
        <input type="radio" id="prim_email_membership_personal" name="prim_email_membership" value="personal_email" <?php echo ($_SESSION[$session_name]['user']['prim_email_membership'] == 'personal_email')?'checked':'' ?>><label for="prim_email_membership_personal"><?php echo $qmembers_text->get('prim_email_membership_personal'); ?></label><br/>
        <input type="radio" id="prim_email_membership_business" name="prim_email_membership" value="business_email" <?php echo ($_SESSION[$session_name]['user']['prim_email_membership'] == 'business_email')?'checked':'' ?>><label for="prim_email_membership_business"><?php echo $qmembers_text->get('prim_email_membership_business'); ?></label><br/>
        <span class="qmembers-error" id="prim_email_membership_error"></span>
    </div>

    <br/>

    <div id="<?php echo $form_id_prim_email; ?>-result"></div>

    <input type="hidden" name="request_id" value="formMemberDataMembershipPrimEmailSubmit"/>
    <input type="submit" id="<?php echo $form_id_prim_email;?>-submit" value="<?php echo $qmembers_text->get('form-member-data-membership-submit-button'); ?>"/>

</form>

<form id="<?php echo $form_id_bill; ?>" class="qmembers-form  qmembers-form-member-data-membership-radio" action="<?php echo QMEMBERS_DRUPAL_AJAX_PATH;?>">

    <label for="billing_address_membership" class="qmembers-form-member-data-membership-label-title"><?php echo $qmembers_text->get('billing_address_membership'); ?></label>
    <div>
        <input type="radio" id="billing_private_membership" name="billing_address_membership" value="1" <?php echo ($_SESSION[$session_name]['user']['billing_address_membership'] == 1)?'checked':'' ?>><label for="billing_private_membership"><?php echo $qmembers_text->get('billing_private_membership'); ?></label><br/>
        <input type="radio" id="billing_company_membership" name="billing_address_membership" value="2" <?php echo ($_SESSION[$session_name]['user']['billing_address_membership'] == 2)?'checked':'' ?>><label for="billing_company_membership"><?php echo $qmembers_text->get('billing_company_membership'); ?></label><br/>
        <input type="radio" id="billing_other_membership"   name="billing_address_membership" value="3" <?php echo ($_SESSION[$session_name]['user']['billing_address_membership'] == 3)?'checked':'' ?>><label for="billing_other_membership"><?php echo $qmembers_text->get('billing_other_membership'); ?></label>
        <span class="qmembers-error" id="billing_address_membership_error"></span>
    </div>

    <br/>

    <div id="form-billing_other-membership" <?php echo ($_SESSION[$session_name]['user']['billing_address_membership'] == '3' )?'':'hidden' ?>>

        <div class="qmembers-label-input-error-wrapper">
            <label for="title_membership"><?php echo $qmembers_text->get('title_membership'); ?></label>
            <span class="qmembers-member-data-membership-input-error-wrapper">
                <input type="text" id="title_membership" name="title_membership" value="<?php echo $_SESSION[$session_name]['user']['title_membership']; ?>" />
                <span class="qmembers-error" id="title_membership_error"></span>
            </span>
        </div>

        <div class="qmembers-label-input-error-wrapper">
            <label for="first_name_membership"><?php echo $qmembers_text->get('first_name_membership'); ?> <span><?php echo $qmembers_text->get('mandatory_sign'); ?></span></label>
            <span class="qmembers-member-data-membership-input-error-wrapper">
                <input type="text" id="first_name_membership" name="first_name_membership" value="<?php echo $_SESSION[$session_name]['user']['first_name_membership']; ?>" />
                <span class="qmembers-error" id="first_name_membership_error"></span>
            </span>
        </div>

        <div class="qmembers-label-input-error-wrapper">
            <label for="last_name_membership"><?php echo $qmembers_text->get('last_name_membership'); ?> <span><?php echo $qmembers_text->get('mandatory_sign'); ?></span></label>
            <span class="qmembers-member-data-membership-input-error-wrapper">
                <input type="text" id="last_name_membership" name="last_name_membership" value="<?php echo $_SESSION[$session_name]['user']['last_name_membership']; ?>" />
                <span class="qmembers-error" id="last_name_membership_error"></span>
            </span>
        </div>

        <div class="qmembers-label-input-error-wrapper">
            <label for="company_membership"><?php echo $qmembers_text->get('company_membership'); ?> <span><?php echo $qmembers_text->get('mandatory_sign'); ?></span></label>
            <span class="qmembers-member-data-membership-input-error-wrapper">
                <input type="text" id="company_membership" name="company_membership" value="<?php echo $_SESSION[$session_name]['user']['company_membership']; ?>" />
                <span class="qmembers-error" id="company_membership_error"></span>
            </span>
        </div>

        <div class="qmembers-label-input-error-wrapper">
            <label for="department_membership"><?php echo $qmembers_text->get('department_membership'); ?> </label>
            <span>
                <input type="text" id="department_membership" name="department_membership" value="<?php echo $_SESSION[$session_name]['user']['department_membership']; ?>" />
            </span>
        </div>

        <div class="qmembers-label-input-error-wrapper">
            <label for="office_number_membership"><?php echo $qmembers_text->get('office_number_membership'); ?> </label>
            <span>
                <input type="text" id="office_number_membership" name="office_number_membership" value="<?php echo $_SESSION[$session_name]['user']['office_number_membership']; ?>" />
            </span>
        </div>

        <div class="qmembers-label-input-error-wrapper">
            <label for="line_membership"><?php echo $qmembers_text->get('line_membership'); ?></label>
            <span>
                <input type="text" id="line_membership" name="line_membership" value="<?php echo $_SESSION[$session_name]['user']['line_membership']; ?>" />
            </span>
        </div>

        <div class="qmembers-label-input-error-wrapper">
            <label for="street_number_membership"><?php echo $qmembers_text->get('street_number_membership'); ?><span><?php echo $qmembers_text->get('mandatory_sign'); ?></span></label>
            <span class="qmembers-member-data-membership-input-error-wrapper">
                <input type="text" id="street_number_membership" name="street_number_membership" value="<?php echo $_SESSION[$session_name]['user']['street_number_membership']; ?>" />
                <span class="qmembers-error" id="street_number_membership_error"></span>
            </span>
        </div>

        <div class="qmembers-label-input-error-wrapper">
            <label for="zip_membership"><?php echo $qmembers_text->get('zip_membership'); ?><span><?php echo $qmembers_text->get('mandatory_sign'); ?></span></label>
            <span class="qmembers-member-data-membership-input-error-wrapper">
                <input type="text" id="zip_membership" name="zip_membership" value="<?php echo $_SESSION[$session_name]['user']['zip_membership']; ?>" />
                <span class="qmembers-error" id="zip_membership_error"></span>
            </span>
        </div>

        <div class="qmembers-label-input-error-wrapper">
            <label for="city_membership"><?php echo $qmembers_text->get('city_membership'); ?><span><?php echo $qmembers_text->get('mandatory_sign'); ?></span></label>
            <span class="qmembers-member-data-membership-input-error-wrapper">
                <input type="text" id="city_membership" name="city_membership" value="<?php echo $_SESSION[$session_name]['user']['city_membership']; ?>" />
                <span class="qmembers-error" id="city_membership_error"></span>
            </span>
        </div>

        <div class="qmembers-label-input-error-wrapper">
            <label for="country_membership"><?php echo $qmembers_text->get('country_membership'); ?><span><?php echo $qmembers_text->get('mandatory_sign'); ?></span></label>
            <span class="qmembers-member-data-membership-input-error-wrapper">
                <select name="country_membership" id="country_membership">
                    <option value=""><?php echo $qmembers_text->get('country_membership_choose'); ?></option>
                    <?php foreach ($countries as $country) :?>
                        <option value="<?php echo $country; ?>" <?php echo $_SESSION[$session_name]['user']['country_membership'] == $country ? 'selected="selected"' : ''; ?>><?php echo $country; ?></option>
                    <?php endforeach; ?>
                </select>
                <span class="qmembers-error" id="country_membership_error"></span>
            </span>
        </div>

        <?php if (variable_get('qmembers_show_states_in_forms', TRUE) == TRUE) : ?>

            <div class="qmembers-label-input-error-wrapper qmembers-form-state-wrapper <?php if($_SESSION[$session_name]['user']['country_membership'] == 'Germany' || $_SESSION[$session_name]['user']['country_membership'] == 'Deutschland') echo 'qmembers-form-state-wrapper-active';?>">
                <label for="state_membership"><?php echo $qmembers_text->get('state_membership'); ?> </label>
                <span class="qmembers-member-data-membership-input-error-wrapper">
                   <?php /*
                    <input type="text" id="state_membership" name="state_membership" value="<?php echo $_SESSION[$session_name]['user']['state_membership']; ?>" />
                    */ ?>
                    <select name="state_membership" id="state_membership">
                        <option value=""><?php echo $qmembers_text->get('state_membership_choose'); ?></option>
                        <?php foreach ($states as $state) :?>
                            <option value="<?php echo $state; ?>" <?php echo $_SESSION[$session_name]['user']['state_membership'] == $state ? 'selected="selected"' : ''; ?>><?php echo $state; ?></option>
                        <?php endforeach; ?>
                    </select>
                    <span class="qmembers-error" id="state_membership_error"></span>
                </span>
            </div>

        <?php endif; ?>

        <div class="qmembers-label-input-error-wrapper">
            <label for="email_membership"><?php echo $qmembers_text->get('email_membership'); ?><span><?php echo $qmembers_text->get('mandatory_sign'); ?></span></label>
            <span class="qmembers-input-error-wrapper">
                <input type="text" id="email_membership" name="email_membership" value="<?php echo $_SESSION[$session_name]['user']['email_membership']; ?>" />
                <span class="qmembers-error" id="email_membership_error"></span>
            </span>
        </div>

        <div class="qmembers-label-input-error-wrapper">
            <label for="phone_membership"><?php echo $qmembers_text->get('phone_membership'); ?><span><?php echo $qmembers_text->get('mandatory_sign'); ?></span></label>
            <span class="qmembers-input-error-wrapper">
                <input type="text" id="phone_membership" name="phone_membership" value="<?php echo $_SESSION[$session_name]['user']['phone_membership']; ?>" />
                <span class="qmembers-error" id="phone_membership_error"></span>
            </span>
        </div>

        <br/>
        <span id="data-saved"><?php echo $qmembers_text->get('billing_data_saved_successfully'); ?></span>
    </div>

    <div id="<?php echo $form_id_bill; ?>-result"></div>

    <input type="hidden" name="request_id" value="formMemberDataMembershipSubmit"/>
    <!--<span class="submit-icon">-->
        <input type="submit" id="<?php echo $form_id_bill;?>-submit-1" value="<?php echo $qmembers_text->get('form-member-data-membership-submit-button'); ?>"/>
    <!--</span>-->
    <div id="form-billing_other-membership-buttons">
        <div id="form-billing_other-membership-buttons-2" <?php echo ($_SESSION[$session_name]['user']['billing_address_membership'] == $qmembers_text->get('billing_other_membership'))?'':'hidden' ?>>

            <a href="<?php echo $qmembers_config['url-member-data-membership'] ?>"><?php echo $qmembers_text->get('form-member-data-membership-cancel-button'); ?></a>
            <span id="mandatory-field"><span><?php echo $qmembers_text->get('mandatory_sign'); ?></span> <span><?php echo $qmembers_text->get('mandatory'); ?></span></span>

        </div>
    </div>

</form>

<form id="<?php echo $form_id_press; ?>" class="qmembers-form  qmembers-form-member-data-membership-radio" action="<?php echo QMEMBERS_DRUPAL_AJAX_PATH;?>">

    <label for="press_magazine_membership" class="qmembers-form-member-data-membership-label-title"><?php echo $qmembers_text->get('press_magazine_membership'); ?></label>
    <div>
        <span id="press_deliver_membership"><?php echo $qmembers_text->get('press_deliver_membership'); ?></span><br/>
        <input type="radio" id="press_private_membership" name="press_magazine_membership" value="1" <?php echo ($_SESSION[$session_name]['user']['press_magazine_membership'] == 1)?'checked':'' ?>><label for="press_private_membership"><?php echo $qmembers_text->get('press_private_membership'); ?></label><br/>
        <input type="radio" id="press_company_membership" name="press_magazine_membership" value="2" <?php echo ($_SESSION[$session_name]['user']['press_magazine_membership'] == 2)?'checked':'' ?>><label for="press_company_membership"><?php echo $qmembers_text->get('press_company_membership'); ?></label>
        <span class="qmembers-error" id="press_magazine_membership_error"></span>
    </div>

    <br/>

    <div id="<?php echo $form_id_press; ?>-result"></div>

    <input type="hidden" name="request_id" value="formMemberDataMembershipPressSubmit"/>
    <!--<span class="submit-icon">-->
        <input type="submit" id="<?php echo $form_id_press;?>-submit-2" value="<?php echo $qmembers_text->get('form-member-data-membership-submit-button'); ?>"/>
    <!--</span>-->
</form>

    <br/>
    <br/>

    <span id="changes_label_membership" class="qmembers-form-member-data-membership-label-title"><?php echo $qmembers_text->get('changes_label_membership'); ?></span>

    <br/>

    <span id="changes_info_membership"><?php echo $qmembers_text->get('changes_info_membership'); ?></span>

    <br/>
    <br/>


<?php /*
    <span id="termination_membership" class="qmembers-form-member-data-membership-label-title"><?php echo $qmembers_text->get('termination_membership'); ?></span>
    <br/>
*/?>
    <a id="form-member-data-membership-termination-button" onclick="qmembersToggle('#form-membership-termination');">
        <?php echo $qmembers_text->get('form-member-data-membership-termination-button'); ?>
    </a>


<!-- MEMBERSHIP TERMINATION -->

<div id="form-membership-termination" hidden>

    <h3>
        <?php echo $qmembers_text->get('form-member-data-termination-title'); ?>
    </h3>

    <?php if (!$qmembers_config['display-membership-termination-form']):?>

        <?php echo $qmembers_text->get('membership-termination-info-text-instead-of-termination-form');?>

    <?php else:?>

    <form id="<?php echo $form_id_temination; ?>" class="qmembers-form" action="<?php echo QMEMBERS_DRUPAL_AJAX_PATH;?>">

        <div>
            <span id="membership_n_termination"><?php echo $qmembers_text->get('membership_n_termination'); ?> <?php echo $user->getCustomerNumberToBeDisplayed(); ?></span>
        </div>

        <?php if (!empty($_SESSION[$session_name]['user']['message_termination']) ):?>

            <div id="qmembers-membership-canceled-info">
                <?php echo $qmembers_text->get('membership-canceled-info'); ?>
            </div>

            <div>
                <span><?php echo $qmembers_text->get('membership_canceled_date'); ?> <?php if ( isset($_SESSION[$session_name]['user']['membership_canceled']) ) echo $_SESSION[$session_name]['user']['membership_canceled']; ?></span>
            </div>

            <div>
                <span><?php echo $qmembers_text->get('membership_until'); ?> <?php echo $_SESSION[$session_name]['user']['membership_until']; ?></span>
            </div>

        <?php endif;?>

        <div>
            <span><?php echo $qmembers_text->get('membership_from'); ?> <?php echo $membership_from; ?></span>
        </div>

        <div>
            <span><?php echo $qmembers_text->get('membership_level'); ?> <?php echo $membership_level_display_name; ?></span>
        </div>

        <div>
            <span><?php echo $_SESSION[$session_name]['user']['first_name_personal']; ?> <?php echo $_SESSION[$session_name]['user']['last_name_personal']; ?></span>
            <br/>
            <span><?php echo $_SESSION[$session_name]['user']['street_number_personal']; ?>, <?php echo $_SESSION[$session_name]['user']['zip_personal']; ?> <?php echo $_SESSION[$session_name]['user']['city_personal']; ?>, <?php echo $_SESSION[$session_name]['user']['country_personal']; ?></span>
        </div>


        <?php if (empty($_SESSION[$session_name]['user']['message_termination']) ):?>

            <div>
                <span id="title_text_termination"><?php echo $qmembers_text->get('title_text_termination'); ?></span>
                <br/>
                <span id="text_termination"><?php echo $qmembers_text->get('text_termination'); ?></span>
            </div>


            <label for="reason_termination"><?php echo $qmembers_text->get('reason_termination'); ?></label>
            <br/>
            <select id="reason_termination" name="reason_termination">
                <option value=""><?php echo $qmembers_text->get('reason_0_termination'); ?></option>
                <?php foreach ($reasons as $reason) :?>
                    <option value="<?php echo $reason; ?>" <?php echo $_SESSION[$session_name]['user']['reason_termination'] == $reason ? 'selected="selected"' : ''; ?>><?php echo $reason; ?></option>
                <?php endforeach; ?>
            </select>
            <span class="qmembers-error" id="reason_termination"></span>

            <br/>

            <label for="message_termination"><?php echo $qmembers_text->get('message_termination'); ?> </label>
            <br/>
            <textarea id="message_termination" name="message_termination"><?php echo $_SESSION[$session_name]['user']['message_termination']; ?></textarea>
            <span class="qmembers-error" id="message_termination_error"></span>

            <br/>

            <?php /*
            <input type="checkbox" id="disclaimer_termination" name="disclaimer_termination" <?php echo $_SESSION[$session_name]['user']['disclaimer_termination'] ? 'checked="checked"' : ''; ?> />
            <label for="disclaimer_termination"><?php echo $qmembers_text->get('disclaimer_termination'); ?> </label>
            <span class="qmembers-error" id="disclaimer_termination_error"></span>

            <div>
                <span id="text_disclaimer_termination"><?php echo $qmembers_text->get('text_disclaimer_termination'); ?></span>
            </div>
            <br/>
            <br/>

            */?>

            <div id="<?php echo $form_id_temination; ?>-result"></div>

            <input type="hidden" name="request_id" value="formMemberDataTerminationSubmit"/>
            <!--<span class="submit-icon">-->
                <input type="submit" id="<?php echo $form_id_temination;?>-submit" value="<?php echo $qmembers_text->get('form-member-data-termination-submit-button'); ?>"/>
            <!--</span>-->
            <a id="form-member-data-termination-cancel-button" onclick="qmembersToggle('#form-membership-termination');"><?php echo $qmembers_text->get('form-member-data-termination-cancel-button'); ?></a>
        <?php endif;?>
    </form>

    <?php endif;?>

</div>

