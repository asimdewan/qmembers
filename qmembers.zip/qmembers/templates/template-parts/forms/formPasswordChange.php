<?php
    if ( isset($_GET[$qmembers_config['hash-password-change-parameter-name']]) ) $hash_password_change = $_GET[$qmembers_config['hash-password-change-parameter-name']];
?>


<form id="<?php echo $form_id;?>" class="qmembers-form" action="<?php echo QMEMBERS_DRUPAL_AJAX_PATH;?>">

    <div class="qmembers-label-input-error-wrapper">
        <label for="change_password"><?php echo $qmembers_text->get('change_password'); ?>:</label>
        <span class="qmembers-input-error-wrapper">
            <input type="password" id="change_password" name="change_password"/>
            <span class="qmembers-error" id="change_password_error"></span>
        </span>
    </div>

    <br/>

    <div class="qmembers-label-input-error-wrapper">
        <label for="repeat_change_password"><?php echo $qmembers_text->get('repeat_change_password'); ?>:</label>
        <span class="qmembers-input-error-wrapper">
            <input type="password" id="repeat_change_password" name="repeat_change_password"/>
            <span class="qmembers-error" id="repeat_change_password_error"></span>
        </span>
    </div>

    <br/>

    <div id="<?php echo $form_id;?>-result"></div>

    <input type="hidden" name="request_id" value="formPasswordChangeSubmit"/>
    <input type="hidden" name="hash_password_change" value="<?php echo $hash_password_change; ?>"/>
    <input type="submit" id="<?php echo $form_id;?>-submit" value="<?php echo $qmembers_text->get('form-password-change-submit-button');?>"/>
    <a href="<?php echo $qmembers_config['login-url']; ?>"><?php echo $qmembers_text->get('form-password-change-back-button'); ?></a>

</form>

