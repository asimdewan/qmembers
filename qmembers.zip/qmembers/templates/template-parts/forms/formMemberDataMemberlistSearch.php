<?php

$session_name = $qmembers_config['session']['name'];

?>

<div class="qmembers-form-memberlist-members">
    <span id="qmembers-form-memberlist-count"><?php echo $members_memberlist; ?></span> <span id="qmembers-form-memberlist-count-text"><?php echo $members_count_text; ?></span>
</div>

<form id="<?php echo $form_id; ?>" class="qmembers-form" action="<?php echo QMEMBERS_DRUPAL_AJAX_PATH;?>">

    <input type="text" id="search_memberlist" name="search_memberlist" placeholder="<?php echo $qmembers_text->get('search_memberlist'); ?>" value= "<?php echo $search_parameter; ?>"/>
    <span class="qmembers-error" id="search_memberlist_error"></span>

    <div id="<?php echo $form_id; ?>-result"></div>

    <input type="hidden" name="request_id" value="formMemberDataMemberlistSubmit"/>
    <input type="submit" id="<?php echo $form_id;?>-submit" value="<?php echo $qmembers_text->get('form-member-data-memberlist-submit-button'); ?>"/>

</form>
