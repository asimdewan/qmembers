<?php ?>

<div class="qmembers-service-provider-count-container">
    <span id="qmembers-service-provider-count"><?php echo $count; ?></span> <span id="qmembers-service-provider-count-text"><?php echo $count_text; ?></span>
</div>

<form id="<?php echo $form_id; ?>" class="qmembers-form" action="<?php echo QMEMBERS_CURRENT_URL;?>">
    <input type="text" id="qmembers-service-provider-search" name="search" placeholder="<?php echo $qmembers_text->get('search-service-provider-list'); ?>" value= "<?php echo $search; ?>"/>
</form>

