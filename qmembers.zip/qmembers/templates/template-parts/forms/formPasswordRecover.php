<?php

?>


<form id="<?php echo $form_id;?>" class="qmembers-form" action="<?php echo QMEMBERS_DRUPAL_AJAX_PATH;?>">

    <div class="qmembers-label-input-error-wrapper">
        <label for="email"><?php echo $qmembers_text->get('email');?>: </label>
        <span class="qmembers-input-error-wrapper">
            <input type="email" id="email" name="email"/>
            <span class="qmembers-error" id="email_error"></span>
        </span>
    </div>

    <br/>

    <div id="<?php echo $form_id;?>-result"></div>

    <input type="hidden" name="request_id" value="formPasswordRecoverSubmit"/>

    <input type="submit" id="<?php echo $form_id;?>-submit" value="<?php echo $qmembers_text->get('form-password-recover-submit-button');?>"/>
    <a href="<?php echo $qmembers_config['login-url']; ?>"><?php echo $qmembers_text->get('form-password-recover-back-button'); ?></a>

</form>

