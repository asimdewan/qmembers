<?php

$session_name = $qmembers_config['session']['name'];

?>

<div>
    <?php echo $qmembers_text->get('form-member-data-professional-explanation'); ?>
</div>

<form id="<?php echo $form_id; ?>" class="qmembers-form qmembers-form-data" action="<?php echo QMEMBERS_DRUPAL_AJAX_PATH;?>">

    <div class="qmembers-label-input-error-wrapper-first">
        <label for="company_professional"><?php echo $qmembers_text->get('company_professional'); ?> <span><?php echo $qmembers_text->get('mandatory_sign'); ?></span></label>
        <span class="qmembers-input-error-wrapper">
            <input type="text" id="company_professional" name="company_professional" value="<?php echo $_SESSION[$session_name]['user']['company_professional']; ?>" />
            <span class="qmembers-error" id="company_professional_error"></span>
        </span>
    </div>

    <div class="qmembers-label-input-error-wrapper">
        <label for="function_professional"><?php echo $qmembers_text->get('function_professional'); ?> <span><?php echo $qmembers_text->get('mandatory_sign'); ?></span></label>
        <span class="qmembers-input-error-wrapper">
            <input type="text" id="function_professional" name="function_professional" value="<?php echo $_SESSION[$session_name]['user']['function_professional']; ?>" />
            <span class="qmembers-error" id="function_professional_error"></span>
        </span>
    </div>

    <div class="qmembers-label-input-error-wrapper">
        <label for="department_professional"><?php echo $qmembers_text->get('department_professional'); ?> </label>
        <span class="qmembers-input-error-wrapper">
            <input type="text" id="department_professional" name="department_professional" value="<?php echo $_SESSION[$session_name]['user']['department_professional']; ?>" />
        </span>
    </div>

    <div class="qmembers-label-input-error-wrapper">
        <label for="office_number_professional"><?php echo $qmembers_text->get('office_number_professional'); ?> </label>
        <span class="qmembers-input-error-wrapper">
            <input type="text" id="office_number_professional" name="office_number_professional" value="<?php echo $_SESSION[$session_name]['user']['office_number_professional']; ?>" />
        </span>
    </div>

    <div class="qmembers-label-input-error-wrapper">
        <label for="line_professional"><?php echo $qmembers_text->get('line_professional'); ?></label>
        <span class="qmembers-input-error-wrapper">
            <input type="text" id="line_professional" name="line_professional" value="<?php echo $_SESSION[$session_name]['user']['line_professional']; ?>" />
        </span>
    </div>

    <div class="qmembers-label-input-error-wrapper">
        <label for="street_number_professional"><?php echo $qmembers_text->get('street_number_professional'); ?><span><?php echo $qmembers_text->get('mandatory_sign'); ?></span></label>
        <span class="qmembers-input-error-wrapper">
            <input type="text" id="street_number_professional" name="street_number_professional" value="<?php echo $_SESSION[$session_name]['user']['street_number_professional']; ?>" />
            <span class="qmembers-error" id="street_number_professional_error"></span>
        </span>
    </div>

    <div class="qmembers-label-input-error-wrapper">
        <label for="zip_professional"><?php echo $qmembers_text->get('zip_professional'); ?><span><?php echo $qmembers_text->get('mandatory_sign'); ?></span></label>
        <span class="qmembers-input-error-wrapper">
            <input type="text" id="zip_professional" name="zip_professional" value="<?php echo $_SESSION[$session_name]['user']['zip_professional']; ?>" />
            <span class="qmembers-error" id="zip_professional_error"></span>
        </span>
    </div>

    <div class="qmembers-label-input-error-wrapper">
        <label for="city_professional"><?php echo $qmembers_text->get('city_professional'); ?><span><?php echo $qmembers_text->get('mandatory_sign'); ?></span></label>
        <span class="qmembers-input-error-wrapper">
            <input type="text" id="city_professional" name="city_professional" value="<?php echo $_SESSION[$session_name]['user']['city_professional']; ?>" />
            <span class="qmembers-error" id="city_professional_error"></span>
        </span>
    </div>

    <div class="qmembers-label-input-error-wrapper">
        <label for="country_professional"><?php echo $qmembers_text->get('country_professional'); ?><span><?php echo $qmembers_text->get('mandatory_sign'); ?></span></label>
        <span class="qmembers-input-error-wrapper">
            <select name="country_professional" id="country_professional">
                <option value=""><?php echo $qmembers_text->get('country_professional_choose'); ?></option>
                <?php foreach ($countries as $country) :?>
                    <option value="<?php echo $country; ?>" <?php echo $_SESSION[$session_name]['user']['country_professional'] == $country ? 'selected="selected"' : ''; ?>><?php echo $country; ?></option>
                <?php endforeach; ?>
            </select>
            <span class="qmembers-error" id="country_professional_error"></span>
        </span>
    </div>

    <?php if (variable_get('qmembers_show_states_in_forms', TRUE) == TRUE) : ?>

    <div class="qmembers-label-input-error-wrapper qmembers-form-state-wrapper <?php if($_SESSION[$session_name]['user']['country_professional'] == 'Germany' || $_SESSION[$session_name]['user']['country_professional'] == 'Deutschland') echo 'qmembers-form-state-wrapper-active';?>">
        <label for="state_professional"><?php echo $qmembers_text->get('state_professional'); ?> </label>
        <span class="qmembers-input-error-wrapper">
           <?php /*
             <input type="text" id="state_professional" name="state_professional" value="<?php echo $_SESSION[$session_name]['user']['state_professional']; ?>" />
            */ ?>
            <select name="state_professional" id="state_professional">
                <option value=""><?php echo $qmembers_text->get('state_professional_choose'); ?></option>
                <?php foreach ($states as $state) :?>
                    <option value="<?php echo $state; ?>" <?php echo $_SESSION[$session_name]['user']['state_professional'] == $state ? 'selected="selected"' : ''; ?>><?php echo $state; ?></option>
                <?php endforeach; ?>
            </select>
            <span class="qmembers-error" id="state_professional_error"></span>
        </span>
    </div>

    <?php endif; ?>

    <!--<br/>-->

    <div class="qmembers-label-input-error-wrapper">
        <label for="email_professional"><?php echo $qmembers_text->get('email_professional'); ?><span><?php // echo $qmembers_text->get('mandatory_sign'); ?></span> <span><?php echo $qmembers_text->get('professional'); ?></span></label>
        <span class="qmembers-input-error-wrapper">
            <input type="text" id="email_professional" name="email_professional" value="<?php echo $_SESSION[$session_name]['user']['email_professional']; ?>" />
            <span class="qmembers-error" id="email_professional_error"></span>
        </span>
    </div>

    <div class="qmembers-label-input-error-wrapper">
        <label for="phone_professional"><?php echo $qmembers_text->get('phone_professional'); ?><span><?php echo $qmembers_text->get('mandatory_sign'); ?></span> <span><?php echo $qmembers_text->get('professional'); ?></span></label>
        <span class="qmembers-input-error-wrapper">
            <input type="text" id="phone_professional" name="phone_professional" value="<?php echo $_SESSION[$session_name]['user']['phone_professional']; ?>" />
            <span class="qmembers-error" id="phone_professional_error"></span>
        </span>
    </div>

    <?php if($qmembers_config['display-vat-professional-field']):?>
    <div class="qmembers-label-input-error-wrapper">
        <label for="vat_professional"><?php echo $qmembers_text->get('vat_professional'); ?> </label>
        <span class="qmembers-input-error-wrapper">
            <input type="text" id="vat_professional" name="vat_professional" value="<?php echo $_SESSION[$session_name]['user']['vat_professional']; ?>" />
        </span>
    </div>
    <?php endif;?>

    <div class="qmembers-label-input-error-wrapper">
        <label for="business_professional"><?php echo $qmembers_text->get('business_professional'); ?> </label>
        <span class="qmembers-input-error-wrapper">
            <?php /*
            <input type="text" id="business_professional" name="business_professional" value="<?php echo $_SESSION[$session_name]['user']['business_professional']; ?>" />
            */ ?>
            <select name="business_professional" id="v">
                <option value=""><?php echo $qmembers_text->get('business_professional_choose'); ?></option>
                <?php foreach ($businesses as $business) :?>
                    <option value="<?php echo $business; ?>" <?php echo $_SESSION[$session_name]['user']['business_professional'] == $business ? 'selected="selected"' : ''; ?>><?php echo $business; ?></option>
                <?php endforeach; ?>
            </select>
            <span class="qmembers-error" id="business_professional_error"></span>
        </span>
    </div>

    <div id="result-wrapper">
        <div class="qmembers-loading element-invisible">
            <?php echo $qmembers_text->get('data-is-being-saved');?>
        </div>
        <div id="<?php echo $form_id; ?>-result"></div>
    </div>

    <input type="hidden" name="request_id" value="formMemberDataProfessionalSubmit"/>
    <!--<span class="submit-icon">-->
        <input type="button" class="qmembers-form-submit-send" data-form-id="<?php echo $form_id;?>" id="<?php echo $form_id;?>-submit" value="<?php echo $qmembers_text->get('form-member-data-professional-submit-button'); ?>"/>
    <!--</span>-->
    <a href="<?php echo $qmembers_config['url-member-data-professional'] ?>"><?php echo $qmembers_text->get('form-member-data-professional-cancel-button'); ?></a>
    <span id="mandatory-field"><span><?php echo $qmembers_text->get('mandatory_sign'); ?></span> <span><?php echo $qmembers_text->get('mandatory'); ?></span></span>

</form>
