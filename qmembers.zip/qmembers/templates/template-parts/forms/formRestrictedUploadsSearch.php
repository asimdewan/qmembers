<?php

// Important: Each form needs to have an id that starts with: qmembers-restricted-uploads
?>
<form id="qmembers-restricted-uploads-search" action="<?php echo QMEMBERS_DRUPAL_AJAX_PATH;?>">

    <input id="qmembers-restricted-uploads-search-field" type="text" maxlength="<?php echo $qmembers_config['form']['restricted-uploads-search']['search']['max_len'];?>" name="search" value="<?php echo $search;?>" placeholder="<?php echo $qmembers_text->get('restricted-uploads-placeholder-search-field');?>"/>

    <select id="qmembers-restricted-uploads-filter1" name="filter1">
        <option value="" <?php if($filter1 == 'all') echo 'selected="selected"';?> ><?php echo $qmembers_text->get('restricted-uploads-filter1-option-all');?></option>

        <?php foreach($categories as $category):?>
            <option value="<?php echo $category['title'];?>" <?php if($filter1 == $category['title']) echo 'selected="selected"';?> ><?php echo $category['title'];?></option>
        <?php endforeach;?>
    </select>

    <select id="qmembers-restricted-uploads-filter2" name="filter2">
        <option value=""><?php echo $qmembers_text->get('restricted-uploads-filter2-option-all');?></option>

        <?php foreach($groups as $group):?>
            <option value="<?php echo $group['id'];?>" <?php if($filter2 == $group['id']) echo 'selected="selected"'?> ><?php echo $group['title'];?></option>
        <?php endforeach;?>
    </select>

    <input type="hidden" name="search_page" value="<?php echo $search_page;?>"/>
    <input type="hidden" name="request_id" value="submitRestrictedUploadsSearch"/>

    <button type="submit"><?php echo $qmembers_text->get('restricted-uploads-search-submit-button');?></button>

</form>
