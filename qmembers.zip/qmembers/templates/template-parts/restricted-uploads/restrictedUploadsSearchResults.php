<?php ?>

<div id="<?php echo $form_id;?>-result">

    <?php
    if ($count == 0) echo 'No search results (<-- this text should be put here as text array, like all text in the code of this module - just check other parts of the module that include text. All text is being entered in includes/text.php.)';

    foreach($search_results as $key => $search_result):
    ?>

        <!-- Create your HTML markup -->
        <div class="qmembers-restricted-uploads-result-block">
            <div id="qmembers-restricted-uploads-result-item1"><?php echo $search_result['dummy-data1'];?></div>
            <div id="qmembers-restricted-uploads-result-item2"><?php echo $search_result['dummy-data2'];?></div>
            <div id="qmembers-restricted-uploads-result-item3"><?php echo $search_result['dummy-data3'];?></div>
            <div id="qmembers-restricted-uploads-result-item4"><?php echo $search_result['dummy-data4'];?></div>
        </div>

    <?php endforeach;?>

    <!-- Example: How to check if user belongs to the content team -->
    <?php if($user_belongs_to_content_team):?>
        This user belongs to the content team.
    <?php else:?>
        This user doesn't belong to the content team.
    <?php endif;?>

</div>
