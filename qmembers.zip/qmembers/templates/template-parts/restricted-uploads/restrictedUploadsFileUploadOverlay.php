<?php ?>

<div id="qmembers-restricted-uploads-file-upload-overlay">

    <?php
    if(!$user_has_file_upload_permission) echo $qmembers_text->get('you-are-not-allowed-to-upload-files');

    if($user_has_file_upload_permission):?>

        Add overlay content for file upload here and hide this div id via SCSS later.

    <?php endif;?>
</div>

