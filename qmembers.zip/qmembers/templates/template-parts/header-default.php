<?php  ?>

<!-- !Leaderboard Region -->
<?php //print render($page['leaderboard']); ?>

<div id="header-container">
    <header id="header"<?php //print $header_attributes; ?>>

        <div id="header-inner">

            <!-- !Mitgliederseiten-Logo Region -->
            <?php print render($page['mitgliederseiten_logo']); ?>

            <div id="header-description">
                <?php echo $qmembers_text->get('header-default--bdp-member-area');?>
            </div>

            <?php if ($qmembers_user->isLoggedIn()):?>
            <div id="header-info-container">

                <div id="header-info">
                    <?php if ($qmembers_user->getMembershipLevel()):?>
                    <span id="qmembers-membership-level"><?php echo $qmembers_user->getMembershipLevelDisplayName();?></span>
                    <span>|</span>
                    <?php endif;?>

                    <span id="qmembers-member-id">
                        <?php echo $qmembers_text->get('header-default--member-id') . ': ' . $qmembers_user->getCustomerNumberToBeDisplayed();?>
                    </span>
                    <a href="<?php echo $qmembers_config['logout-url'];?>">
                        <?php echo $qmembers_text->get('header-default--logout');?>
                    </a>
                </div>

                <div id="sidebar-mobile-icon" onclick="qmembersToggle('#qmembers-page-sidebar');">
                </div>
            </div>
            <?php endif;?>
        </div>
    </header>
</div>