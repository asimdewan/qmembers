<?php echo $text_label; ?> (<?php echo $results_number; ?>)
