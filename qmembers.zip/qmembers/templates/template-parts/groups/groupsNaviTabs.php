<?php ?>
<nav id='member-data-navi-tabs'>

    <?php if($regional_groups_exist):?>
        <a <?php echo ($tab_id == '')?'class="member-data-navi-tabs-active"':'' ?> href="<?php echo $qmembers_config['url-member-data-groups']; ?>"><?php echo $qmembers_text->get('navigation-groups-all'); ?></a>
    <?php endif?>

    <a <?php echo ($tab_id == $filter_work_groups)?'class="member-data-navi-tabs-active"':'' ?> href="<?php echo $qmembers_config['url-member-data-groups'].'?'.$qmembers_config['groups-filter-parameter-name'].'=' . $filter_work_groups; ?>"><?php echo $qmembers_text->get('navigation-groups-professional'); ?></a>

    <?php if($regional_groups_exist):?>
        <a <?php echo ($tab_id == $filter_regional_groups)?'class="member-data-navi-tabs-active"':'' ?> href="<?php echo $qmembers_config['url-member-data-groups'].'?'.$qmembers_config['groups-filter-parameter-name'].'=' . $filter_regional_groups; ?>"><?php echo $qmembers_text->get('navigation-groups-national'); ?></a>
    <?php endif?>

    <a <?php echo ($tab_id == 'subscribed')?'class="member-data-navi-tabs-active"':'' ?> href="<?php echo $qmembers_config['url-member-data-groups'].'?'.$qmembers_config['groups-filter-parameter-name'].'=subscribed'; ?>"><?php echo $qmembers_text->get('navigation-groups-personal'); ?></a>

</nav>