<?php ?>

<div class="qmembers-group-summary">
    <div class="qmembers-group-summary-img">
        <div class="qmembers-group-summary-group">
            <div class="qmembers-group-summary-title"><?php echo $title;?></div>
        </div>
    </div>

    <div class="qmembers-group-row">

        <div class="qmembers-group-image-container" style="background-image: url(<?php echo $img_url;?>)"></div>

        <div class="qmembers-group-info">

            <span class="qmembers-group-summary-text"><?php echo $summary;?></span>
            <span class="qmembers-group-summary-read-more">
                <a href="<?php echo $node_url;?>"><?php echo $read_more;?></a>
            </span>
            <div class="qmembers-group-summary-join">
                <form id="<?php echo $form_id.$summary_index.'-join'; ?>" <?php echo ($belongs_user)?'hidden':''; ?> class="qmembers-form-summary-join" action="<?php echo QMEMBERS_DRUPAL_AJAX_PATH;?>">
                    <input type="hidden" name="request_id" value="formGroupsJoinSubmit"/>
                    <input type="hidden" name="group_id" value="<?php echo $group_id;?>"/>
                    <input type="submit" value="<?php echo $this->text->get('join_group_groups'); ?>"/>
                </form>
                <div id="<?php echo $form_id.$summary_index.'-join'; ?>-result" class="qmembers-groups-join-ajax-result"></div>
            </div>
            <div class="qmembers-group-summary-leave">
                <form id="<?php echo $form_id.$summary_index.'-leave'; ?>" <?php echo ($belongs_user)?'':'hidden'; ?> class="qmembers-form-summary-leave<?php echo ($belongs_user)?'-visible':''; ?>" action="<?php echo QMEMBERS_DRUPAL_AJAX_PATH;?>">
                    <input type="hidden" name="request_id" value="formGroupsLeaveSubmit"/>
                    <input type="hidden" name="group_id" value="<?php echo $group_id;?>"/>
                    <div class="qmembers-group-summary-belongs<?php echo ($belongs_user)?'-visible':''; ?>"><?php echo $this->text->get('belongs_group_groups'); ?> </div>
                    <input type="submit" value="<?php echo $this->text->get('leave_group_groups'); ?>"/>
                </form>
                <div id="<?php echo $form_id.$summary_index.'-leave'; ?>-result" class="qmembers-groups-leave-ajax-result"></div>
                <span id="group_id_error"></span>
            </div>
        </div>
    </div>
</div>


