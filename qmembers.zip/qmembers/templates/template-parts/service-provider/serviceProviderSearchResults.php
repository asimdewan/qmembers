<?php ?>

<div class="qmembers-service-provider-result-block">

    <div class="qmembers-service-provider-name">
        <?php echo $value['service_provider_company'];?>
    </div>

    <div class="qmembers-service-provider-street">
        <?php echo $value['service_provider_street'];?>
    </div>

    <div class="qmembers-service-provider-zip-city">
        <span class="qmembers-service-provider-zip">
            <?php echo $value['service_provider_zip'];?>
        </span>
        <span class="qmembers-service-provider-city">
            <?php echo $value['service_provider_city'];?>
        </span>
    </div>

</div>








