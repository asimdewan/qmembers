<?php  ?>


<h1 class="qmembers-node-title">
    <?php $NodeGroupDetails->displayGroupTitle();?>
</h1>

<br/>

<button id="qmembers-group-details-back-button" onclick="history.back();">
    <i class="fa fa-chevron-left fa-sm"></i>
    <?php echo $qmembers_text->get('group-details--back-to-list');?>
</button>
