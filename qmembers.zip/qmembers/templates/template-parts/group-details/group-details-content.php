<?php ?>

<img src="<?php echo $img_url;?>" />

<br/>

<div class="qmembers-group-details-body">
    <?php echo $body;?>
</div>

<div class="qmembers-group-details-contacts">
    <?php

    foreach ($contact_descriptions as $key => $contact_description){

        //$contact_img_filename       = $contact_people[$key]->field_image['und'][0]['filename'];
        //$contact_img_uri            = file_build_uri($contact_img_filename);
        $contact_img_uri            = $contact_people[$key]->field_image['und'][0]['uri'];
        $contact_img_url            = image_style_url($this->config['image-style-for-group-contact-person-image'], $contact_img_uri );
        //$contact_img_url             = file_create_url($contact_img_uri);

        $contact_title              = $contact_description['value'];
        $first_name                 = $contact_people[$key]->field_p_vorname['und']['0']['value'];
        $last_name                  = $contact_people[$key]->field_p_name['und']['0']['value'];
        $company                    = $contact_people[$key]->field_p_firma['und']['0']['value'];
        $email                      = $contact_people[$key]->field_p_email['und']['0']['email'];
    ?>

        <div class="qmembers-group-details-contact">

            <div class="qmembers-group-details-contact-title">
                <?php echo $contact_title;?>
            </div>

            <div class="qmembers-group-details-contact-infos">

                <div class="qmembers-group-details-contact-image">
                    <img src="<?php echo $contact_img_url;?>" />
                </div>


                <div class="qmembers-group-details-contact-details">

                    <div class="qmembers-group-details-contact-name">
                        <?php echo $first_name . ' ' . $last_name;?>
                    </div>

                    <div class="qmembers-group-details-contact-company">
                        <?php echo $company;?>
                    </div>

                    <div class="qmembers-group-details-contact-email">
                        <a href="mailto:<?php echo $email;?>"><?php echo $email;?></a>
                    </div>

                </div>
            </div>
        </div>

    <?php } // END: foreach ?>
</div>


