<?php ?>
<nav id='member-data-navi-tabs'>

    <a <?php echo ($tab_id == 'qmembers-form-member-data-personal')?'class="member-data-navi-tabs-active"':'' ?> href="<?php echo $qmembers_config['url-member-data-personal']; ?>"><?php echo $qmembers_text->get('navigation-member-data-personal'); ?></a>
    <a <?php echo ($tab_id == 'qmembers-form-member-data-professional')?'class="member-data-navi-tabs-active"':'' ?> href="<?php echo $qmembers_config['url-member-data-professional']; ?>"><?php echo $qmembers_text->get('navigation-member-data-professional'); ?></a>
    <a <?php echo ($tab_id == 'qmembers-form-member-data-membership')?'class="member-data-navi-tabs-active"':'' ?>href="<?php echo $qmembers_config['url-member-data-membership']; ?>"><?php echo $qmembers_text->get('navigation-member-data-membership'); ?></a>
    <a <?php echo ($tab_id == 'qmembers-form-member-data-settings')?'class="member-data-navi-tabs-active"':'' ?>href="<?php echo $qmembers_config['url-member-data-settings']; ?>"><?php echo $qmembers_text->get('navigation-member-data-settings'); ?></a>

</nav>