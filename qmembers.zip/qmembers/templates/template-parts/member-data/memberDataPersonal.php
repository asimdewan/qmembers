<?php

    $session_name = $qmembers_config['session']['name'];

?>

<div>
    <?php echo $qmembers_text->get('form-member-data-personal-explanation'); ?>
</div>


<?php require QMEMBERS_PATH_FORMS . 'formPersonalPicture.php';?>


<div class="qmembers-form">

    <div class="qmembers-form qmembers-form-data" >

        <label for="salutation_personal"><?php echo $qmembers_text->get('salutation_personal'); ?></label>
        <span id="salutation_personal" name="salutation_personal"> <?php echo ($_SESSION[$session_name]['user']['salutation_personal'] == "")?$qmembers_text->get('empty_field'):$user->getDisplayNameForSalutationPersonal(); ?> </span>

        <br/>

        <label for="title_personal"><?php echo $qmembers_text->get('title_personal'); ?> </label>
        <span id="title_personal" name="title_personal"> <?php echo ($_SESSION[$session_name]['user']['title_personal'] == "")?$qmembers_text->get('empty_field'):$_SESSION[$session_name]['user']['title_personal']; ?> </span>

        <br/>

        <label for="first_name_personal"><?php echo $qmembers_text->get('first_name_personal'); ?></label>
        <span id="first_name_personal" name="first_name_personal"> <?php echo ($_SESSION[$session_name]['user']['first_name_personal'] == "")?$qmembers_text->get('empty_field'):$_SESSION[$session_name]['user']['first_name_personal']; ?> </span>

        <br/>

        <label for="last_name_personal"><?php echo $qmembers_text->get('last_name_personal'); ?></label>
        <span id="last_name_personal" name="last_name_personal"> <?php echo ($_SESSION[$session_name]['user']['last_name_personal'] == "")?$qmembers_text->get('empty_field'):$_SESSION[$session_name]['user']['last_name_personal']; ?> </span>

        <br/>

        <label for="birthdate_personal"><?php echo $qmembers_text->get('birthdate_personal'); ?></label>
        <span id="birthdate_personal" name="birthdate_personal"> <?php echo ($_SESSION[$session_name]['user']['birthdate_personal'] == "")?$qmembers_text->get('empty_field'):$_SESSION[$session_name]['user']['birthdate_personal']; ?> </span>

        <br/>

        <label for="line_personal"><?php echo $qmembers_text->get('line_personal'); ?></label>
        <span id="line_personal" name="line_personal"> <?php echo ($_SESSION[$session_name]['user']['line_personal'] == "")?$qmembers_text->get('empty_field'):$_SESSION[$session_name]['user']['line_personal']; ?> </span>

        <br/>

        <label for="street_number_personal"><?php echo $qmembers_text->get('street_number_personal'); ?></label>
        <span id="street_number_personal" name="street_number_personal"> <?php echo ($_SESSION[$session_name]['user']['street_number_personal'] == "")?$qmembers_text->get('empty_field'):$_SESSION[$session_name]['user']['street_number_personal']; ?> </span>

        <br/>

        <label for="zip_personal"><?php echo $qmembers_text->get('zip_personal'); ?></label>
        <span id="zip_personal" name="zip_personal"> <?php echo ($_SESSION[$session_name]['user']['zip_personal'] == "")?$qmembers_text->get('empty_field'):$_SESSION[$session_name]['user']['zip_personal']; ?> </span>

        <br/>

        <label for="city_personal"><?php echo $qmembers_text->get('city_personal'); ?></label>
        <span id="city_personal" name="city_personal"> <?php echo ($_SESSION[$session_name]['user']['city_personal'] == "")?$qmembers_text->get('empty_field'):$_SESSION[$session_name]['user']['city_personal']; ?> </span>

        <br/>

        <label for="country_personal"><?php echo $qmembers_text->get('country_personal'); ?> </label>
        <span id="country_personal" name="country_personal"> <?php echo ($_SESSION[$session_name]['user']['country_personal'] == "")?$qmembers_text->get('empty_field'):$_SESSION[$session_name]['user']['country_personal']; ?> </span>

        <?php if (variable_get('qmembers_show_states_in_forms', TRUE) == TRUE) : ?>

        <br/>

        <label for="state_personal"><?php echo $qmembers_text->get('state_personal'); ?> </label>
        <span id="state_personal" name="state_personal"> <?php echo ($_SESSION[$session_name]['user']['state_personal'] == "")?$qmembers_text->get('empty_field'):$_SESSION[$session_name]['user']['state_personal']; ?> </span>

        <?php endif; ?>

        <br/>
        <br/>

        <label for="email_personal"><?php echo $qmembers_text->get('email_personal'); ?> <span><?php echo $qmembers_text->get('private'); ?></span></label>
        <span id="email_personal" name="email_personal"> <?php echo ($_SESSION[$session_name]['user']['email_personal'] == "")?$qmembers_text->get('empty_field'):$_SESSION[$session_name]['user']['email_personal']; ?> </span>

        <br/>

        <label for="phone_personal"><?php echo $qmembers_text->get('phone_personal'); ?> <span><?php echo $qmembers_text->get('private'); ?></span></label>
        <span id="phone_personal" name="phone_personal"> <?php echo ($_SESSION[$session_name]['user']['phone_personal'] == "")?$qmembers_text->get('empty_field'):$_SESSION[$session_name]['user']['phone_personal']; ?> </span>

        <br/>

        <label for="xing_personal"><?php echo $qmembers_text->get('xing_personal'); ?> </label>
        <span id="xing_personal" name="xing_personal"> <?php echo ($_SESSION[$session_name]['user']['xing_personal'] == "")?$qmembers_text->get('empty_field'):$_SESSION[$session_name]['user']['xing_personal']; ?> </span>

        <br/>

        <label for="linkedin_personal"><?php echo $qmembers_text->get('linkedin_personal'); ?> </label>
        <span id="linkedin_personal" name="linkedin_personal"> <?php echo ($_SESSION[$session_name]['user']['linkedin_personal'] == "")?$qmembers_text->get('empty_field'):$_SESSION[$session_name]['user']['linkedin_personal']; ?> </span>

        <br/>

        <a id="data-submit" href="<?php echo $qmembers_config['url-member-data-personal'].'?'.$qmembers_config['view-option-parameter-name'].'=1' ?>"><?php echo $qmembers_text->get('member-data-personal-edit-button'); ?></a>

        <span id="data-saved">Ihre Daten wurden erfolgreich gespeichert!</span>
    </div>
</div>
