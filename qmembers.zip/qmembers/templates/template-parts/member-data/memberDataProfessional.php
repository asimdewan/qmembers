<?php

$session_name = $qmembers_config['session']['name'];

?>

<div>
    <?php echo $qmembers_text->get('form-member-data-professional-explanation'); ?>
</div>

<div class="qmembers-form qmembers-form-data">

    <label for="company_professional"><?php echo $qmembers_text->get('company_professional'); ?> </label>
    <span id="company_professional" name="company_professional"> <?php echo ($_SESSION[$session_name]['user']['company_professional'] == "")?$qmembers_text->get('empty_field'):$_SESSION[$session_name]['user']['company_professional']; ?> </span>

    <br/>

    <label for="function_professional"><?php echo $qmembers_text->get('function_professional'); ?> </label>
    <span id="function_professional" name="function_professional"> <?php echo ($_SESSION[$session_name]['user']['function_professional'] == "")?$qmembers_text->get('empty_field'):$_SESSION[$session_name]['user']['function_professional']; ?> </span>

    <br/>

    <label for="department_professional"><?php echo $qmembers_text->get('department_professional'); ?> </label>
    <span id="department_professional" name="department_professional"> <?php echo ($_SESSION[$session_name]['user']['department_professional'] == "")?$qmembers_text->get('empty_field'):$_SESSION[$session_name]['user']['department_professional']; ?> </span>

    <br/>

    <label for="office_number_professional"><?php echo $qmembers_text->get('office_number_professional'); ?> </label>
    <span id="office_number_professional" name="office_number_professional"> <?php echo ($_SESSION[$session_name]['user']['office_number_professional'] == "")?$qmembers_text->get('empty_field'):$_SESSION[$session_name]['user']['office_number_professional']; ?> </span>

    <br/>

    <label for="line_professional"><?php echo $qmembers_text->get('line_professional'); ?></label>
    <span id="line_professional" name="line_professional"> <?php echo ($_SESSION[$session_name]['user']['line_professional'] == "")?$qmembers_text->get('empty_field'):$_SESSION[$session_name]['user']['line_professional']; ?> </span>

    <br/>

    <label for="street_number_professional"><?php echo $qmembers_text->get('street_number_professional'); ?></label>
    <span id="street_number_professional" name="street_number_professional"> <?php echo ($_SESSION[$session_name]['user']['street_number_professional'] == "")?$qmembers_text->get('empty_field'):$_SESSION[$session_name]['user']['street_number_professional']; ?> </span>

    <br/>

    <label for="zip_professional"><?php echo $qmembers_text->get('zip_professional'); ?></label>
    <span id="zip_professional" name="zip_professional"> <?php echo ($_SESSION[$session_name]['user']['zip_professional'] == "")?$qmembers_text->get('empty_field'):$_SESSION[$session_name]['user']['zip_professional']; ?> </span>

    <br/>

    <label for="city_professional"><?php echo $qmembers_text->get('city_professional'); ?></label>
    <span id="city_professional" name="city_professional"> <?php echo ($_SESSION[$session_name]['user']['city_professional'] == "")?$qmembers_text->get('empty_field'):$_SESSION[$session_name]['user']['city_professional']; ?> </span>

    <br/>

    <label for="country_professional"><?php echo $qmembers_text->get('country_professional'); ?> </label>
    <span id="country_professional" name="country_professional"> <?php echo ($_SESSION[$session_name]['user']['country_professional'] == "")?$qmembers_text->get('empty_field'):$_SESSION[$session_name]['user']['country_professional']; ?> </span>

    <br/>

    <?php if (variable_get('qmembers_show_states_in_forms', TRUE) == TRUE) : ?>

    <label for="state_professional"><?php echo $qmembers_text->get('state_professional'); ?> </label>
    <span id="state_professional" name="state_professional"> <?php echo ($_SESSION[$session_name]['user']['state_professional'] == "")?$qmembers_text->get('empty_field'):$_SESSION[$session_name]['user']['state_professional']; ?> </span>

    <br/>

    <?php endif; ?>

    <!--<br/>-->

    <label for="email_professional"><?php echo $qmembers_text->get('email_professional'); ?> <span><?php echo $qmembers_text->get('professional'); ?></span></label>
    <span id="email_professional" name="email_professional"> <?php echo ($_SESSION[$session_name]['user']['email_professional'] == "")?$qmembers_text->get('empty_field'):$_SESSION[$session_name]['user']['email_professional']; ?> </span>

    <br/>

    <label for="phone_professional"><?php echo $qmembers_text->get('phone_professional'); ?> <span><?php echo $qmembers_text->get('professional'); ?></span></label>
    <span id="phone_professional" name="phone_professional"> <?php echo ($_SESSION[$session_name]['user']['phone_professional'] == "")?$qmembers_text->get('empty_field'):$_SESSION[$session_name]['user']['phone_professional']; ?> </span>

    <br/>

    <?php if($qmembers_config['display-vat-professional-field']):?>
    <label for="vat_professional"><?php echo $qmembers_text->get('vat_professional'); ?> </label>
    <span id="vat_professional" name="vat_professional"> <?php echo ($_SESSION[$session_name]['user']['vat_professional'] == "")?$qmembers_text->get('empty_field'):$_SESSION[$session_name]['user']['vat_professional']; ?> </span>

    <br/>
    <?php endif;?>

    <label for="business_professional"><?php echo $qmembers_text->get('business_professional'); ?> </label>
    <span id="business_professional" name="business_professional"> <?php echo ($_SESSION[$session_name]['user']['business_professional'] == "")?$qmembers_text->get('empty_field'):$_SESSION[$session_name]['user']['business_professional']; ?> </span>

    <br/>

    <a id="data-submit" href="<?php echo $qmembers_config['url-member-data-professional'].'?'.$qmembers_config['view-option-parameter-name'].'=1' ?>"><?php echo $qmembers_text->get('member-data-professional-edit-button'); ?></a>

    <span id="data-saved">Ihre Daten wurden erfolgreich gespeichert!</span>
</div>
