<?php  ?>

<?php if ($title): ?>
    <h1 class="qmembers-node-title">
        <?php print $title; ?>
    </h1>
<?php endif; ?>

