<?php  ?>

<div id="node-<?php print $node->nid; ?>" class="qmembers-node-content <?php print $classes; ?>"<?php print $attributes; ?>>
