<?php

// Mitgliederseiten-Sidebar-Region
print render($page['mitgliederseiten_sidebar']);

?>