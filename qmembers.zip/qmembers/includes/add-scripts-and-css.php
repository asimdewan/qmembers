<?php

$qmembers_js 			= array();
$qmembers_js_external   = array();
$qmembers_css 			= array();
$qmembers_css_external 	= array();

// Add internal JS
$qmembers_js[] = 'functions.js';
$qmembers_js[] = 'croppie.min.js';
$qmembers_js[] = 'image-upload.js';
$qmembers_js[] = 'restricted-uploads.js';

// Add external JS
$qmembers_js_external[] = '';

// Add internal CSS
$qmembers_css[] = 'qmembers_style.css';
$qmembers_css[] = 'croppie.css';

// Add external CSS
$qmembers_css_external[] = 'https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css';

?>

