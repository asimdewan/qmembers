<?php

function qmembers_preprocess_page(&$variables) {
   
 	global $qmembers_config;

 	if (isset($variables['node']->type)) {


 	    //if (path_is_admin(current_path())) {

        //}
        //else{
            // Adds option to use a page template file according to the content type
            $variables['theme_hook_suggestions'][] = 'page__' . $variables['node']->type;
        //}


        //if (path_is_admin(current_path())) {

        //}
        //else{


                // Adds module JS and CSS according to content type
            if ( $variables['node']->type == $qmembers_config['content-type-for-member-sites'] ) {

                require QMEMBERS_FILE_ADD_SCRIPTS_AND_CSS;


              // ADDS JS
              // -------

                if ( !path_is_admin(current_path()) ) { // Important! Don't add module js to Drupal admin sites

                    // Includes internal js files
                    foreach ($qmembers_js as $js_file) {
                        if ( file_exists( QMEMBERS_PATH_JS . $js_file ) ) drupal_add_js( QMEMBERS_PATH_RELATIVE_JS . $js_file);
                    }

                  // Includes external js files
                    foreach ($qmembers_js_external as $js_file) {
                        drupal_add_js( $js_file, array('type' => 'external', 'group' => JS_DEFAULT, 'weight' => 100) );
                    }
                }


                // ADDS CSS
              // --------
                // Resets all previous drupal css if desired
                if ( $qmembers_config['reset_all_drupal_css_on_member_sites'] ) drupal_static_reset('drupal_add_css');


              // Includes CSS normalization if desired
                if ( $qmembers_config['normalize_css_on_member_sites'] ) drupal_add_css( QMEMBERS_PATH_RELATIVE_CSS . 'normalize.css', array('group' => CSS_THEME, 'weight' => 100));


              // Includes external css files
                foreach ($qmembers_css_external as $css_file) {
                    drupal_add_css( $css_file, array('type' => 'external', 'group' => CSS_THEME, 'weight' => 101) );
                }


              // Includes internal module css files
                foreach ($qmembers_css as $css_file) {
                     if ( file_exists( QMEMBERS_PATH_CSS . $css_file ) ){
                        drupal_add_css( QMEMBERS_PATH_RELATIVE_CSS . $css_file, array('group' => CSS_THEME, 'weight' => 102));
                     }
                }

            }

        //}
    }
}


/**
 * Implements hook_theme().
 */
function qmembers_theme($existing, $type, $theme, $path) {

  global $qmembers_config;

      $theme = array();

      // Match drupal page ids to our template files
      foreach ( $qmembers_config['page'] as $page => $value ){

          $id            = $value['id'][ $qmembers_config['environment'] ];
          $template_page = $value['template']['page'];
          $template_node = $value['template']['node'];

          $theme['page__node__' . $id]  = array(
              'path' => QMEMBERS_RELATIVE_PATH . 'templates',
              'template' => 'page--' . $template_page,
          );

          $theme['node__' . $id]  = array(
              'path' => QMEMBERS_RELATIVE_PATH . 'templates',
              'template' => 'node--' . $template_node,
          );
      }

      return $theme;
}



/**
 * Implements hook_menu(). Defining an AJAX URL and callback function.
 */

function qmembers_menu() {

    $qmembers_ajax_path = QMEMBERS_DRUPAL_AJAX_PATH;
    $qmembers_ajax_path = substr($qmembers_ajax_path, 1);

    $items = array();
    $items[$qmembers_ajax_path] = array(
        'title' => 'Get qmembers data',
        'page callback' => 'qmembers_ajax_callback',
        'access arguments' => array('access content'),
        'type' => MENU_CALLBACK,
    );

    // Qmembers settings pages
    $items['admin/config/qmembers'] = array(
        'title' => 'QMembers',
        'description' => 'Settings for QMembers module.',
        'position' => 'left',
        'weight' => -10,
        'page callback' => 'system_admin_menu_block_page',
        'access arguments' => array('administer site configuration'),
        'file' => 'system.admin.inc',
        'file path' => drupal_get_path('module', 'system'),

    );

    $items['admin/config/qmembers/rabbitmq'] = array(
        'title' => 'RabbitMQ',
        'description' => 'Configure RabbitMQ Settings.',
        'page callback' => 'drupal_get_form',
        'page arguments' => array('qmembers_rabbitmq_settings'),
        'access callback' => 'user_access',
        'access arguments' => array('administer site configuration'),
        'weight' => 0,
    );

    $items['admin/config/qmembers/member'] = array(
        'title' => 'Membership',
        'description' => 'Configure Membership Settings.',
        'page callback' => 'drupal_get_form',
        'page arguments' => array('qmembers_members_settings'),
        'access callback' => 'user_access',
        'access arguments' => array('administer site configuration'),
        'weight' => 0,
    );

    $items['admin/config/qmembers/portal'] = array(
        'title' => 'Portal',
        'description' => 'Configure Portal Settings.',
        'page callback' => 'drupal_get_form',
        'page arguments' => array('qmembers_portal_settings'),
        'access callback' => 'user_access',
        'access arguments' => array('administer site configuration'),
        'weight' => 0,
    );

    $items['admin/config/qmembers/password-recovery'] = array(
        'title' => 'Password Recovery',
        'description' => 'Configure Password Recovery Settings.',
        'page callback' => 'drupal_get_form',
        'page arguments' => array('qmembers_password_recovery_settings'),
        'access callback' => 'user_access',
        'access arguments' => array('administer site configuration'),
        'weight' => 10,
    );

    return $items;
}

function qmembers_password_recovery_settings() {
    $form['qmembers_password_recovery'] = array(
        '#type' => 'textfield',
        '#title' => t('Password Recovery'),
        '#default_value' => (int) variable_get('qmembers_password_recovery', 7),
        '#maxlength' => 2,
        '#description' => t('How long is the password recovery hash valid? In days.'),
        '#element_validate' => array('element_validate_integer'),
    );
    return system_settings_form($form);
}

function qmembers_members_settings() {
    $form['qmembers_delete_member_enable'] = array(
        '#type' => 'checkbox',
        '#title' => t('Enable Member deletion'),
        '#default_value' => variable_get('qmembers_delete_member_enable', FALSE),
        '#disabled' => false,
        '#description' => t('Activates the deletion of members whos membership expired.'),
        '#weight' => 1,
    );

    return system_settings_form($form);
}

function qmembers_portal_settings() {
    $form['qmembers_show_states_in_forms'] = array(
        '#type' => 'checkbox',
        '#title' => t('Enable the states.'),
        '#default_value' => variable_get('qmembers_show_states_in_forms', TRUE),
        '#disabled' => false,
        '#description' => t('Activates the visibility of the states in the personal data and business data form. (default active).'),
        '#weight' => 1,
    );

    return system_settings_form($form);
}

function qmembers_rabbitmq_settings() {
    $form['environment'] = array(
        '#type' => 'fieldset',
        '#title' => t('Environment'),
    );

    $form['environment']['qmembers_rabbitmq_environment'] = array(
        '#type' => 'select',
        '#options' => array(
            'dev' => t('dev'),
            'live'   => t('live'),
        ),
        '#description' => t('Choose if live or dev RabbitMQ is used.'),
        '#default_value' => variable_get('qmembers_rabbitmq_environment', 'dev'),
        '#required' => true,
        '#weight' => 0,
    );

    $form['enable'] = array(
        '#type' => 'fieldset',
        '#title' => t('Enable RabbitMQ'),
    );
    $form['enable']['qmembers_rabbitmq_read_enable'] = array(
        '#type' => 'checkbox',
        '#title' => t('Enable RabbitMQ Read'),
        '#default_value' => variable_get('qmembers_rabbitmq_read_enable', FALSE),
        '#disabled' => false,
        '#description' => t('Activates getting data from RabbitMQ for members.'),
        '#weight' => 1,
    );

    $form['enable']['qmembers_rabbitmq_write_enable'] = array(
        '#type' => 'checkbox',
        '#title' => t('Enable RabbitMQ Write'),
        '#default_value' => variable_get('qmembers_rabbitmq_write_enable', FALSE),
        '#disabled' => false,
        '#description' => t('Activates writing data to RabbitMQ for members.'),
        '#weight' => 2,
    );

    $form['dev'] = array(
        '#type' => 'fieldset',
        '#title' => t('Development Environment'),
    );
    $form['dev']['qmembers_rabbitmq_dev_host'] = array(
        '#type' => 'textfield',
        '#title' => t('Host'),
        '#default_value' => variable_get('qmembers_rabbitmq_dev_host', ''),
        '#required' => true,
        '#weight' => 1,
    );
    $form['dev']['qmembers_rabbitmq_dev_port'] = array(
        '#type' => 'textfield',
        '#title' => t('Port'),
        '#default_value' => variable_get('qmembers_rabbitmq_dev_port', ''),
        '#required' => true,
        '#weight' => 2,
    );

    $form['live'] = array(
        '#type' => 'fieldset',
        '#title' => t('Live Environment'),
    );
    $form['live']['qmembers_rabbitmq_live_host'] = array(
        '#type' => 'textfield',
        '#title' => t('Host'),
        '#default_value' => variable_get('qmembers_rabbitmq_live_host', ''),
        '#required' => true,
        '#weight' => 1,
    );
    $form['live']['qmembers_rabbitmq_live_port'] = array(
        '#type' => 'textfield',
        '#title' => t('Port'),
        '#default_value' => variable_get('qmembers_rabbitmq_live_port', ''),
        '#required' => true,
        '#weight' => 2,
    );

    $form['read'] = array(
        '#type' => 'fieldset',
        '#title' => t('Read connection data'),
    );
    $form['read']['qmembers_rabbitmq_read_user'] = array(
        '#type' => 'textfield',
        '#title' => t('User'),
        '#default_value' => variable_get('qmembers_rabbitmq_read_user', ''),
        '#required' => true,
        '#weight' => 3,
    );
    $form['read']['qmembers_rabbitmq_read_password'] = array(
        '#type' => 'textfield',
        '#title' => t('Password'),
        '#default_value' => variable_get('qmembers_rabbitmq_read_password', ''),
        '#required' => true,
        '#weight' => 4,
    );
    $form['read']['qmembers_rabbitmq_read_queue'] = array(
        '#type' => 'textfield',
        '#title' => t('Queue'),
        '#default_value' => variable_get('qmembers_rabbitmq_read_queue', ''),
        '#required' => true,
        '#weight' => 5,
    );
    $form['read']['qmembers_rabbitmq_read_routing_key'] = array(
        '#type' => 'textfield',
        '#title' => t('Routing Key'),
        '#default_value' => variable_get('qmembers_rabbitmq_read_routing_key', ''),
        '#required' => true,
        '#weight' => 6,
    );
    $form['read']['qmembers_rabbitmq_read_exchange'] = array(
        '#type' => 'textfield',
        '#title' => t('Exchange'),
        '#default_value' => variable_get('qmembers_rabbitmq_read_exchange', ''),
        '#required' => true,
        '#weight' => 7,
    );
    $form['read']['qmembers_rabbitmq_read_vhost'] = array(
        '#type' => 'textfield',
        '#title' => t('Vhost'),
        '#default_value' => variable_get('qmembers_rabbitmq_read_vhost', ''),
        '#required' => true,
        '#weight' => 8,
    );


    $form['write'] = array(
        '#type' => 'fieldset',
        '#title' => t('Write connection data'),
    );
    $form['write']['qmembers_rabbitmq_write_user'] = array(
        '#type' => 'textfield',
        '#title' => t('User'),
        '#default_value' => variable_get('qmembers_rabbitmq_write_user', ''),
        '#required' => true,
        '#weight' => 3,
    );
    $form['write']['qmembers_rabbitmq_write_password'] = array(
        '#type' => 'textfield',
        '#title' => t('Password'),
        '#default_value' => variable_get('qmembers_rabbitmq_write_password', ''),
        '#required' => true,
        '#weight' => 4,
    );
    $form['write']['qmembers_rabbitmq_write_queue'] = array(
        '#type' => 'textfield',
        '#title' => t('Queue'),
        '#default_value' => variable_get('qmembers_rabbitmq_write_queue', ''),
        '#required' => true,
        '#weight' => 5,
    );
    $form['write']['qmembers_rabbitmq_write_routing_key'] = array(
        '#type' => 'textfield',
        '#title' => t('Routing Key'),
        '#default_value' => variable_get('qmembers_rabbitmq_write_routing_key', ''),
        '#required' => true,
        '#weight' => 6,
    );
    $form['write']['qmembers_rabbitmq_write_exchange'] = array(
        '#type' => 'textfield',
        '#title' => t('Exchange'),
        '#default_value' => variable_get('qmembers_rabbitmq_write_exchange', ''),
        '#required' => true,
        '#weight' => 7,
    );
    $form['write']['qmembers_rabbitmq_write_vhost'] = array(
        '#type' => 'textfield',
        '#title' => t('Vhost'),
        '#default_value' => variable_get('qmembers_rabbitmq_write_vhost', ''),
        '#required' => true,
        '#weight' => 8,
    );

    return system_settings_form($form);
}

/**
 * Get qmembers data
 */

function qmembers_ajax_callback() {

    require QMEMBERS_FILE_AJAX;

}

/**
 * Implements hook_css_alter().
 *
 * Objective: REMOVES JS OF uniform MODULE WHICH CHANGES OUR FORM ELEMENTS (IF INSTALLED)
 */
function qmembers_js_alter(&$js) {

    global $qmembers_config;

    if (strpos(QMEMBERS_CURRENT_URL, $qmembers_config['member-sites-url-path-parent']) !== false){
        if ( isset( $js[drupal_get_path('module', 'uniform').'/uniform.js'] )  )
            unset($js[drupal_get_path('module', 'uniform').'/uniform.js']);
    }
}


/**
 * Add new regions
 * Implements hook_system_info_alter()
 * Adds a new "tray" region to the current theme
 */
/*  INFO: THIS CREATED PROBLEMS. AFTER SAVING SOMETHING IN THE BACK END, REGIONS DISAPPEARED OCCASIONALLY. REGIONS ARE NOW CREATED BY THEME.
function qmembers_system_info_alter(&$info, $file){
    global $theme, $qmembers_config;

    // If non-default theme configuration has been selected, set the custom theme.
    $custom_theme = isset ($theme) ? $theme : variable_get('theme_default', $qmembers_config['drupal-theme-in-use']);

    if ($file->name == $custom_theme){
        $info['regions'] = array_merge($info['regions'],  array('mitgliederseiten_logo' => t('Mitgliederseiten-Logo')));
    }

    if ($file->name == $custom_theme){
        $info['regions'] = array_merge($info['regions'],  array('mitgliederseiten_sidebar' => t('Mitgliederseiten-Sidebar')));
    }
}
*/


?>