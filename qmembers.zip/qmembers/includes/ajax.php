<?php

$qmembers_ajax_request = true;

//-------------------------------------------------------------------------------------------------

$redirect_url      = false;
$reload_page   = false;

if( isset($_POST['request_id']) ) $request_id = $_POST['request_id'];
else exit;

use includes\classes\Ajax;

$ajax = new Ajax;

if(is_callable( array( $ajax, $request_id) ) ) $result = $ajax->$request_id();
else exit;

if( isset( $result['redirect_url'] ) )        $redirect_url     = $result['redirect_url'];
if( isset( $result['reload_page'] ) )         $reload_page      = true;
//if( isset( $result['value'] ) )               echo $result['value'];
if( (isset( $result['value'] ) && !((is_array ($result['value'])) && (count($result['value']) == 0))) )    print_r ($result['value']);
if( !isset( $result['value'] )) echo $result;

// URL FORWARDING IF DESIRED
// ----------------------------------------------------------------------
if( !empty($redirect_url) ):?>
    <script type="text/javascript">
        window.location.href = "<?php echo $redirect_url;?>";
    </script>
<?php elseif($reload_page):?>
    <script type="text/javascript">
        window.location.reload();
    </script>
<?php endif;?>