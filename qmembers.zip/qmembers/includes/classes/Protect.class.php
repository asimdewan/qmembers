<?php

namespace includes\classes;

/**
 * Protect pages
 */
class Protect
{

    private $config_class;
    private $config;
    private $text;


    /**
     * Constructor function.
     * Gets configurations from Config class (to be used in this class).
     * Instantiates text class.
     */
    public function __construct($file_name)
    {
        $this->config_class = new Config;
        $this->config = $this->config_class->getAll();

        $this->text = new Text;


        $file_id = $file_name;
        $file_id = str_replace('page--','', $file_id);
        $file_id = str_replace('.tpl.php','', $file_id);

        $non_protected_pages = explode(',', $this->config['non-protected-page-templates']);

        if (!in_array($file_id,$non_protected_pages)){

            $user = new User;

            if (!$user->isLoggedIn()){
                $user->logout();
                header('location: ' . $this->config['redirect-url-after-logout']);
                exit;
            }
        }
    }
}
