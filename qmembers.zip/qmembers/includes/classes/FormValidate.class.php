<?php

/*
 *  For regex expressions: http://www.regexlib.com/Search.aspx?k=special+characters&c=0&m=0&ps=20&p=2
 */

namespace includes\classes;

use includes\classes\Config;
use includes\classes\Text;
require_once QMEMBERS_FILE_GUMP_VALIDATION; // isn't namespaced

/**
 * Validates all forms
 */
class FormValidate extends \GUMP
{
    private $config_class;
    private $config;
    private $text;
    private $rules_with_values;

    /**
     * Constructor function.
     * Gets configurations from Config class (to be used in this class).
     * Instantiates text class.
     */
    public function __construct()
    {
        $this->config_class      =  new Config;
        $this->config            = $this->config_class->getAll();

        $this->text              = new Text;

        // please refer to https://github.com/Wixel/GUMP/blob/master/README.md for more details
        $this->rules_with_values = array(
                                        'min_len','max_len','exact_len','contains','contains_list',
                                        'doesnt_contain_list','regex','min_numeric','max_numeric','file_size','image_type');

        parent::__construct();
    }


    /**
     * Validates forms
     *
     * @param array $post       Contains posted data (may also contain other data, not only form data, e.g. request_id)
     *
     * @return string           Contains validation message or nothing.
     *
     */
    public function formValidation($form_config_id, $post){

        if ( !isset($form_config_id) || empty($form_config_id) ) exit;

        $result['value'] = array();

        // No validation rules set - return error
        if ( !isset($this->config['form'][$form_config_id]) ){

            //$result['value'] = $this->text['validation--no-validation-rules-set'];
            $result['value']['validation-rules'] = $this->text['validation--no-validation-rules-set'];
            return $result;
        }

        // Create validation rule format of gump class dynamically
        foreach ( $this->config['form'][$form_config_id] as $field_name => $rules ) {

            $field_rules_string = '';

            foreach ($rules as $rule => $value) {

                if (in_array($rule, $this->rules_with_values)) {

                    if ($rule == 'regex'){
                        // assign value to rule
                        $field_rules_string .= $rule . ',/' . $value . '/|'; // Didn't work with gump
                    }
                    else{
                        // assign value to rule
                        $field_rules_string .= $rule . ',' . $value . '|';
                    }
                } else {

                   // is rule without values
                   if ( $value === true ) $field_rules_string .= $rule . '|';
                }
            }

            // Remove last "|"
            $field_rules_string = substr($field_rules_string, 0, -1);

            // Using GUMP without extending the class
            // Leave this as reference for using non-namespaced classes.
            /*
            $GUMP = new \GUMP();

            $is_valid = $GUMP->is_valid($post, array(
                $field_name => $field_rules_string      //Format = 'required|max_len,100|min_len,6',

            ));
            */

            // Validate if there are validation rules set
            if (!empty($field_rules_string)){

                $is_valid = self::validate($post, array(
                    $field_name => $field_rules_string      //Format = 'required|max_len,100|min_len,6',
                ));

                if($is_valid !== true) {

                    if ( $this->text->get('validation--' . $field_name . '-failed') ){
                        $result['value'][$field_name] = $this->text->get('validation--' . $field_name . '-failed');
                    }
                    else{
                        $result['value'][$field_name] = $this->text->get('validation-failed');
                    }
                }

            }

        }

        return $result;
    }

    /**
     * Determine if the provided value contains only alpha numeric characters with dashed and underscores.
     *
     * Usage: '<index>' => 'alpha_numeric_dash'
     *
     * @param string $field
     * @param array  $input
     * @param null   $param
     *
     * @return mixed
     */
    public function validate_alpha_numeric_dash($field, $input, $param = null)
    {
        if (!isset($input[$field]) || empty($input[$field])) {
            return;
        }

        if (!preg_match('/^([a-z0-9ÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÒÓÔÕÖßÙÚÛÜÝàáâãäåçèéêëìíîïðòóôõöùúûüýÿ_-])+$/i', $input[$field]) !== false) {
            return array(
                'field' => $field,
                'value' => $input[$field],
                'rule' => __FUNCTION__,
                'param' => $param,
            );
        }
    }

    /**
     * Validate files size
     *
     * Usage: '<index>' => 'file_size'
     *
     * @param string $field
     * @param array  $input
     * @param null   $param
     *
     * @return mixed
     */
    public function validate_file_size($field, $input, $param = null)
    {
        if (!isset($input[$field]) || empty($input[$field])) {
            return;
        }

        $bytes = $input[$field];
        $mbytes = number_format($bytes / 1048576, 4);
        

        if ($mbytes > $param || $mbytes <= 0){

            return array(
                'field' => $field,
                'value' => $input[$field],
                'rule' => __FUNCTION__,
                'param' => $param,
            );
        }
    }

    /**
     * Validate image type
     *
     * Usage: '<index>' => 'image_type'
     *
     * @param string $field
     * @param array  $input
     * @param null   $param
     *
     * @return mixed
     */
    public function validate_image_type($field, $input, $param = null)
    {
        if (!isset($input[$field]) || empty($input[$field])) {
            return;
        }

        $is_permitted = false;

        $allowed_image_types = explode('/',$param);

        foreach ($allowed_image_types as $value){

            $value = trim($value);

            if ($input[$field] == 'image/' . $value){
                $is_permitted = true;
            }
        }

        if (!$is_permitted){
            return array(
                'field' => $field,
                'value' => $input[$field],
                'rule' => __FUNCTION__,
                'param' => $param,
            );
        }

    }


    /**
     * Validate international phone format - Integer, starting with 00.
     *
     * Usage: '<index>' => 'phone_international'
     *
     * @param string $field
     * @param array  $input
     * @param null   $param
     *
     * @return mixed
     */
    public function validate_phone_international($field, $input, $param = null)
    {
        if (!isset($input[$field]) || empty($input[$field])) {
            return;
        }

        if (substr($input[$field], 0, 1) != '+' || !preg_match('/^[0-9]+$/', substr($input[$field], 1) ) ) {

            return array(
                'field' => $field,
                'value' => $input[$field],
                'rule' => __FUNCTION__,
                'param' => $param,
            );
        }
    }



}