<?php
namespace includes\classes;

use includes\classes\DatabaseClient\DatabaseClient;
use includes\classes\DatabaseClient\Mapping;
use includes\classes\RabbitMqClient\Entity\AbstractSerializableEntity;
use includes\classes\RabbitMqClient\Entity\ApiEntityInterface;
use includes\classes\RabbitMqClient\Entity\Authentication;
use includes\classes\RabbitMqClient\Entity\DatabaseEntityInterface;
use includes\classes\RabbitMqClient\Entity\Groups;
use includes\classes\RabbitMqClient\Entity\GroupSubscription;
use includes\classes\RabbitMqClient\Entity\GroupUnSubscription;
use includes\classes\RabbitMqClient\Entity\Login;
use includes\classes\RabbitMqClient\Entity\PasswordChange;
use includes\classes\RabbitMqClient\Entity\PasswordRecovery;
use includes\classes\RabbitMqClient\Entity\Settings;
use includes\classes\RabbitMqClient\Exception\ValidationException;
use includes\classes\RabbitMqClient\RabbitMqClient;
use includes\classes\RabbitMqClient\Validator\Validator;

class ApiHandler
{
    /** @var  string */
    private $errorMessage;

    /** @var  string */
    private $infoMessage;

    /** @var  array */
    private $validationErrors = [];

    /** @var  array */
    private $config;

    /** @var Authentication  */
    private $rabbitMqAuth;

    /** @var Validator  */
    private $validator;

    /** @var Mapping  */
    private $mapping;

    /** @var string  */
    private $authenticated = false;

    /** @var string  */
    public $memberID;


    public function __construct(array $config)
    {
        $this->config = $config;

        if($this->config['rabbitmq']['write']['enable']){

            $this->rabbitMqAuth = new Authentication(
                $this->config['rabbitmq']['write']['host'],
                $this->config['rabbitmq']['write']['port'],
                $this->config['rabbitmq']['write']['user'],
                $this->config['rabbitmq']['write']['password'],
                $this->config['rabbitmq']['write']['queue'],
                $this->config['rabbitmq']['write']['routing_key'],
                $this->config['rabbitmq']['write']['exchange'],
                $this->config['rabbitmq']['write']['vhost'],
                $this->config['rabbitmq']['write']['certificate']
            );
        }

        $this->validator = new Validator();

        $this->mapping = new Mapping();
    }

    public function handleLogin(Login $data)
    {
        try {
            $this->validator->validate($data);
        } catch (ValidationException $exception) {
            $this->validationErrors = $exception->getErrors();
            $this->setErrorMessage(__FUNCTION__, 'Validation Errors');
            return false;
        } catch (\Exception $exception) {
            $this->setErrorMessage(__FUNCTION__, 'Fatal Error');
            return false;
        }

        $databaseClient = new DatabaseClient($this->mapping);
        $success = $databaseClient->checkLogin($data);

        if (!$success) {
            //$this->setErrorMessage(__FUNCTION__, 'User Login failed');

            // Check if login was refused due to membership level
            $error = $databaseClient->getError();

            if($error == 'membership_level_excluded_from_login'){

                // This message will be delivered to the calling function
                $this->setInfoMessage($error);
            }

            return false;
        }

        $this->authenticated = true;
        $this->memberID      = $databaseClient->getMemberID();

        return true;
    }

    public function getMemberID(){

        if($this->authenticated) return $this->memberID;
        else return false;
    }

    public function validateOldPassword(Settings $data)
    {
        $databaseClient = new DatabaseClient($this->mapping);
        $success = $databaseClient->checkOldPassword($data);
        if (!$success) {
            $this->setErrorMessage(__FUNCTION__, $databaseClient->getError());
            return false;
        }

        return true;
    }

    public function handlePasswordRecovery(PasswordRecovery $data)
    {
        try {
            $this->validator->validate($data);
        } catch (ValidationException $exception) {
            $this->validationErrors = $exception->getErrors();
            $this->setErrorMessage(__FUNCTION__, 'Validation Errors');
            return false;
        } catch (\Exception $exception) {
            $this->setErrorMessage(__FUNCTION__, 'Fatal Error');
            return false;
        }

        $databaseClient = new DatabaseClient($this->mapping);
        $hash = $databaseClient->createPasswordRecoveryHash($data);

        if (empty($hash)) {
            // Using the line below creates an error
            //$this->setErrorMessage(__FUNCTION__, $databaseClient->getError());
            return false;
        }

        return $hash;
    }

    public function handlePasswordChange(PasswordChange $data)
    {
        try {
            $this->validator->validate($data);
        } catch (ValidationException $exception) {
            $this->validationErrors = $exception->getErrors();
            $this->setErrorMessage(__FUNCTION__, 'Validation Errors');
            return false;
        } catch (\Exception $exception) {
            $this->setErrorMessage(__FUNCTION__, 'Fatal Error');
            return false;
        }

        $databaseClient = new DatabaseClient($this->mapping);
        $success = $databaseClient->savePassword($data);
        if (!$success) {
            $this->setErrorMessage(__FUNCTION__, $databaseClient->getError());
            return false;
        }

        return true;
    }

    public function handleData(AbstractSerializableEntity $data)
    {
        try {
            $this->validator->validate($data);

            if ($data instanceof ApiEntityInterface) {
                if ($this->config['rabbitmq']['write']['enable']) {
                    $client = new RabbitMqClient();
                    $client->connect($this->rabbitMqAuth);
                    $client->publishData($data);
                    $client->disconnect();
                }
            }

            if ($data instanceof DatabaseEntityInterface) {
                $databaseClient = new DatabaseClient($this->mapping);
                $databaseClient->save($data);
            }

        } catch (ValidationException $exception) {
            $this->validationErrors = $exception->getErrors();
            $this->setErrorMessage(__FUNCTION__, 'Validation Errors');
            return false;
        } catch (\Exception $exception) {
            $this->setErrorMessage(__FUNCTION__, $exception);
            return false;
        }

        return true;
    }

    public function getError()
    {
        return $this->errorMessage;
    }

    private function setErrorMessage($function, $message)
    {
        watchdog('qmembers', 'ApiHandler: Function: ' . $function . ' Message: ' . $message, array(), WATCHDOG_ERROR);
        $this->errorMessage = $message;
    }

    public function getInfoMessage()
    {
        return $this->infoMessage;
    }

    private function setInfoMessage($message)
    {
        $this->infoMessage = $message;
    }

    public function getValidationErrors($name)
    {
        $mapping = $this->mapping->getMappingByName($name);

        $convertedErrors = array();
        foreach ($this->validationErrors as $fieldName => $validationError) {
            $convertedFieldName = $mapping[$fieldName];
            $convertedErrors[$convertedFieldName] = $validationError;
        }

        if (!empty($this->validationErrors) && empty($convertedErrors)) {
            return $this->validationErrors;
        }

        return $convertedErrors;
    }

    public function getMemberData(Login $login)
    {
        $databaseClient = new DatabaseClient($this->mapping);
        $member = $databaseClient->getMember($login);
        if (empty($member)) {
            $this->setErrorMessage(__FUNCTION__, 'Member data is empty');
            return array();
        }

        return $member;
    }

    public function getMemberDataByMemberID($memberid)
    {
        $databaseClient = new DatabaseClient($this->mapping);
        $member = $databaseClient->getMemberByMemberID($memberid);
        if (empty($member)) {
            $this->setErrorMessage(__FUNCTION__, 'Member data is empty');
            return array();
        }

        return $member;
    }

    public function getMemberlist(){
        $databaseClient = new DatabaseClient($this->mapping);
        return $databaseClient->getMembers();
    }

    public function handleGroups(AbstractSerializableEntity $data, $existingGroups)
    {
        try {
            $this->validator->validate($data);

            $groupsArray = array();
            if (!empty(trim($existingGroups))) {
                $groupsArray = explode(',', trim($existingGroups));
            }

            if ($data instanceof GroupSubscription) {
                $groupsArray[] = $data->getGroup();
            }

            if ($data instanceof GroupUnSubscription) {
                $groupsArray = array_diff($groupsArray, array($data->getGroup()));
            }
            $groupsString = implode(',', $groupsArray);

            $groups = new Groups();
            $groups->setId($data->getId());
            $groups->setGroups($groupsString);

            if ($groups instanceof ApiEntityInterface) {
                if ($this->config['rabbitmq']['write']['enable']) {
                    $client = new RabbitMqClient();
                    $client->connect($this->rabbitMqAuth);
                    $client->publishData($groups);
                    $client->disconnect();
                }
            }

            if ($groups instanceof DatabaseEntityInterface) {
                $databaseClient = new DatabaseClient($this->mapping);
                $databaseClient->save($groups);
            }

            return $groupsString;

        } catch (ValidationException $exception) {
            $this->validationErrors = $exception->getErrors();
            $this->setErrorMessage(__FUNCTION__, 'Validation Errors');
            return false;
        } catch (\Exception $exception) {
            $this->setErrorMessage(__FUNCTION__, 'Fatal Error');
            return false;
        }
    }

    public function getServiceProviders(){
        $databaseClient = new DatabaseClient($this->mapping);

        $service_providers = $databaseClient->getServiceProviders();
        if (empty($service_providers)) {
            $this->setErrorMessage(__FUNCTION__, 'Service provider data is empty');
            return array();
        }

        return $service_providers;
    }
}