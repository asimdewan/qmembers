<?php


namespace includes\classes;

/**
 * Handles all ajax requests
 */
class Ajax
{

    /**
     * Handles login form submission
     *
     * @return array        Contains processing result data.
     *
     */
    public function formLoginSubmit(){

        if ( !isset($_POST['request_id']) )              exit;
        if ( $_POST['request_id'] != 'formLoginSubmit' ) exit;

        $FormProcess = new FormProcess;

        $result = $FormProcess->formLoginSubmit($_POST);

        return $result;
    }

    /**
     * Handles the logout.
     *
     * @return bool        true or false
     *
     */
    public function logout(){

       if ( !isset($_POST['request_id']) )     exit;
       if ( $_POST['request_id'] != 'logout' ) exit;

       $user = new User;
       $result = $user->logout();
       return $result;

    }

    /**
     * Handles password recover form submission
     *
     * @return array        Contains processing result data.
     *
     */
    public function formPasswordRecoverSubmit(){

        if ( !isset($_POST['request_id']) )              exit;
        if ( $_POST['request_id'] != 'formPasswordRecoverSubmit' ) exit;

        $FormProcess = new FormProcess;

        $result = $FormProcess->formPasswordRecoverSubmit($_POST);

        return $result;
    }


    /**
     * Handles password change form submission
     *
     * @return array        Contains processing result data.
     *
     */
    public function formPasswordChangeSubmit(){

        if ( !isset($_POST['request_id']) )              exit;
        if ( $_POST['request_id'] != 'formPasswordChangeSubmit' ) exit;

        $FormProcess = new FormProcess;

        $result = $FormProcess->formPasswordChangeSubmit($_POST);

        return $result;
    }


    /**
     * Handles personal data form submission
     *
     * @return array        Contains processing result data.
     *
     */
    public function formMemberDataPersonalSubmit(){

        if ( !isset($_POST['request_id']) )              exit;
        if ( $_POST['request_id'] != 'formMemberDataPersonalSubmit' ) exit;

        $FormProcess = new FormProcess;
        $result = $FormProcess->formMemberDataPersonalSubmit($_POST);

        return $result;
    }

    /**
     * Handles professional data form submission
     *
     * @return array        Contains processing result data.
     *
     */
    public function formMemberDataProfessionalSubmit(){

        if ( !isset($_POST['request_id']) )              exit;
        if ( $_POST['request_id'] != 'formMemberDataProfessionalSubmit' ) exit;

        $FormProcess = new FormProcess;
        $result = $FormProcess->formMemberDataProfessionalSubmit($_POST);

        return $result;
    }


    /**
     * Handles membership data form submission
     *
     * @return array        Contains processing result data.
     *
     */
    public function formMemberDataMembershipSubmit(){

        if ( !isset($_POST['request_id']) )              exit;
        if ( $_POST['request_id'] != 'formMemberDataMembershipSubmit' ) exit;

        $FormProcess = new FormProcess;
        $result = $FormProcess->formMemberDataMembershipSubmit($_POST);

        return $result;
    }


    /**
     * Handles membership data form submission
     *
     * @return array        Contains processing result data.
     *
     */
    public function formMemberDataMembershipPrimEmailSubmit(){

        if ( !isset($_POST['request_id']) )              exit;
        if ( $_POST['request_id'] != 'formMemberDataMembershipPrimEmailSubmit' ) exit;

        $FormProcess = new FormProcess;
        $result = $FormProcess->formMemberDataMembershipPrimEmailSubmit($_POST);

        return $result;
    }


    /**
     * Handles membership data form submission
     *
     * @return array        Contains processing result data.
     *
     */
    public function formMemberDataMembershipPressSubmit(){

        if ( !isset($_POST['request_id']) )              exit;
        if ( $_POST['request_id'] != 'formMemberDataMembershipPressSubmit' ) exit;

        $FormProcess = new FormProcess;
        $result = $FormProcess->formMemberDataMembershipPressSubmit($_POST);

        return $result;
    }


    /**
     * Handles termination data form submission
     *
     * @return array        Contains processing result data.
     *
     */
    public function formMemberDataTerminationSubmit(){

        if ( !isset($_POST['request_id']) )              exit;
        if ( $_POST['request_id'] != 'formMemberDataTerminationSubmit' ) exit;

        $FormProcess = new FormProcess;
        $result = $FormProcess->formMemberDataTerminationSubmit($_POST);

        return $result;
    }


    /**
     * Handles settings data form submission
     *
     * @return array        Contains processing result data.
     *
     */
    public function formMemberDataSettingsSubmit(){

        if ( !isset($_POST['request_id']) )              exit;
        if ( $_POST['request_id'] != 'formMemberDataSettingsSubmit' ) exit;

        $FormProcess = new FormProcess;
        $result = $FormProcess->formMemberDataSettingsSubmit($_POST);

        return $result;
    }


    /**
     * Handles search member list form submission
     *
     * @return array        Contains processing result data.
     *
     */
    public function formMemberDataMemberlistSubmit(){

        if ( !isset($_POST['request_id']) )              exit;
        if ( $_POST['request_id'] != 'formMemberDataMemberlistSubmit' ) exit;

        $FormProcess = new FormProcess;
//        $FormProcess->formMemberDataMemberlistSubmit($_POST);
        $result = $FormProcess->formMemberDataMemberlistSubmit($_POST);

        return $result;
    }

    /**
     * Handles group join form submission
     *
     * @return array        Contains processing result data.
     *
     */
    public function formGroupsJoinSubmit(){

        if ( !isset($_POST['request_id']) )              exit;
        if ( $_POST['request_id'] != 'formGroupsJoinSubmit' ) exit;

        $FormProcess = new FormProcess;
//        $FormProcess->formMemberDataMemberlistSubmit($_POST);
        $result = $FormProcess->formGroupsJoinSubmit($_POST);

        return $result;
    }


    /**
     * Handles group leave form submission
     *
     * @return array        Contains processing result data.
     *
     */
    public function formGroupsLeaveSubmit(){

        if ( !isset($_POST['request_id']) )              exit;
        if ( $_POST['request_id'] != 'formGroupsLeaveSubmit' ) exit;

        $FormProcess = new FormProcess;
//        $FormProcess->formMemberDataMemberlistSubmit($_POST);
        $result = $FormProcess->formGroupsLeaveSubmit($_POST);

        return $result;
    }

    /**
     * Handles the search request on the restricted uploads page
     *
     * @return string        Contains search results as html.
     *
     */
    public function submitRestrictedUploadsSearch(){

        if ( !isset($_POST['request_id']) )              exit;
        if ( $_POST['request_id'] != 'submitRestrictedUploadsSearch' ) exit;

        $FormProcess = new FormProcess;
        $result = $FormProcess->submitRestrictedUploadsSearch($_POST);

        return $result;
    }

}