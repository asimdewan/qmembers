<?php

namespace includes\classes;


/**
 * Takes care about startup actions.
 */
class Init
{

    private $config_class;
    private $config;
    private $text;

    /**
     * Constructor function.
     * Gets configurations from Config class (to be used in this class).
     * Instantiates text class.
     * Performs startup actions.
     */
    public function __construct()
    {
        $this->config_class = new Config;
        $this->config       = $this->config_class->getAll();
        $this->text         = new Text;

        if (!isset($_SESSION)) {
            $session = new Session;
            $session->startSession();
        }

        $GET_action         = new GET;
        //$PHPVarsToDrupalJS  = new PHPVarsToDrupalJS;

        $user = new User;
        $user->updateSessionMemberData();
    }

}
