<?php

namespace includes\classes;

/**
 * Returns config settings.
 */
class Config
{

    /**
     * Returns all config settings
     *
     * @return array        Config settings.
     *
     */
    public function getAll(){

        require QMEMBERS_FILE_DEFAULT_CONFIG;
        if ( file_exists( QMEMBERS_FILE_CONFIG ) ) require QMEMBERS_FILE_CONFIG;

        return $qmembers_config;
    }

    /**
     * Returns the session name.
     *
     * @return string        Session name or empty string if no session name has been set.
     *
     */
    public function getSessionName(){

        $config = self::getAll();

        if ( isset($config['session']['name']) && !empty($config['session']['name']) ){

            return $config['session']['name'];
        }
        else return '';
    }

    /**
     * Returns the session data.
     *
     * @return array        Session data or $result['error'} = true
     *
     */
    public function getSessionData(){

        $config = self::getAll();

        if ( isset($config['session']) ){

            return $config['session'];
        }
        else {
            $result['error'] = true;
            return $result;
        }
    }
}