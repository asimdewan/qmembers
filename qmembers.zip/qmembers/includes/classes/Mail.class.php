<?php


namespace includes\classes;

require_once QMEMBERS_FILE_PHPMAILER; // isn't namespaced

/**
 * Processes all forms
 */
class Mail
{

    private $config_class;
    private $config;
    private $text;


    /**
     * Constructor function.
     * Gets configurations from Config class (to be used in this class).
     * Instantiates text class.
     */
    public function __construct()
    {
        $this->config_class = new Config;
        $this->config = $this->config_class->getAll();

        $this->text = new Text;
    }


    // NOW SEND THE MAIL IN ANOTHER METHOD IN A SEPARATE CLASS CALLED "mail.class.php" (YOU NEED TO CREATE THIS CLASS IN THE SAME WAY THAT WE USE OTHER CLASSES.)

    public function mailSend($to,$from,$from_name,$reply_to,$subject,$mailtext,$bcc = "",$attachment = "")
	{
		// GET PHPMAILER  (REQUIRED CLASS TO SEND MAILS)
		// ----------------------------------------------------------------------------------

        // GIVING CONTENT TO PHP CLASS
        //$mail 						    = new PHPMailer();
        $mail                               = new \PHPMailer(); // not namespaced
        $mail->Subject 					    = $subject;
        $mail->Body     					= $mailtext; 
        $mail->From     					= $from;
        $mail->FromName 					= $from_name;
        $mail->AddReplyTo($reply_to);

        if ($bcc != ""){
            $bcc = explode(',', $bcc);
            foreach ($bcc as $value) {
                $mail->AddBCC($value);
            }
        }

        $mail->Sender     					= $from;
        $mail->CharSet  					=  "utf-8";   // our charset
        $mail->AddAddress($to);

        if($attachment)
            $mail->AddAttachment($attachment);
            //$mail->AddAttachment('path_to_pdf', $name = 'Name_for_pdf',  $encoding = 'base64', $type = 'application/pdf');

        $result = $mail->Send(); 

        if(!$result) return false;
        else return true;
    }

}