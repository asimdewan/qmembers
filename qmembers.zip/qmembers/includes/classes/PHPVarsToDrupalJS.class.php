<?php

namespace includes\classes;


/**
 * Transfers PHP variables to Drupal JS
 */
class PHPVarsToDrupalJS
{
    private $config_class;
    private $config;
    private $text;

    /**
     * Constructor function.
     * Gets configurations from Config class (to be used in this class).
     * Instantiates text class.
     */
    public function __construct()
    {
        $this->config_class = new Config;
        $this->config       = $this->config_class->getAll();
        $this->text         = new Text;

        $this->addPHPVarsToDrupalJS();
    }

    /**
     * Adds PHP variables to Drupal JS
     */
    public function addPHPVarsToDrupalJS()
    {
        if( !isset($this->config['php-var-to-js']) ) return;

        $php_vars = array();

        foreach ($this->config['php-var-to-js'] as $php_key => $value){

            $js_var_name            = str_replace('-','_', $php_key );
            $php_vars[$js_var_name] = $value;
        }

        if($php_vars){
            drupal_add_js( array( QMEMBERS_MODULE_NAME => $php_vars ), array('type' => 'setting') );
        }
    }
}
