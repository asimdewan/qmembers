<?php

namespace includes\classes;


class Session
{
    private $config_class;
    private $config;
    private $text;

    /**
     * Constructor function.
     * Gets configurations from Config class.
     *
     */
    public function __construct()
    {
        $this->config_class     = new Config;
        $this->config           = $this->config_class->getAll();
        $this->text             = new Text;
    }

    /**
     * Start local session.
     *
     * @return bool         true or false
     *
     */
    public function startSession(){

        /*
        $session_data = $this->config['session'];

        if( isset($session_data['time']) )      $session_time   = $session_data['time'];
        else $session_time   = 3600;

        if( isset($session_data['path']) )      $path           = $session_data['path'];
        else $path   = '/';

        if( isset($session_data['domain']) )    $domain         = $session_data['domain'];
        else $domain   = $_SERVER['SERVER_NAME'];

        if ( isset($_SERVER['HTTPS']) )         $secure         = true; // Set to true if using https.
        else $secure = false;

        if( isset($session_data['httponly']) )  $httponly       = $session_data['httponly'];
        else $httponly   = true;

        if( isset($session_data['name']) )      $session_name   = $session_data['name'];
        else $session_name   = 'mtcd_user_session';

        ini_set('session.use_only_cookies', 1); // Forces sessions to only use cookies.
        session_set_cookie_params($session_time,$path,$domain,$secure,$httponly);
        session_name($session_name);
        session_start();
        */

        drupal_session_start();

        return true;
    }

    /**
     * Destroy local session.
     *
     * @return bool         true or false
     *
     */
    function destroySession(){


        $session_name = $this->config['session']['name'];
        if (!$session_name) return false;

        /*
        $_SESSION = array();

        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie($session_name, '', time() - 1000,$params["path"], $params["domain"],$params["secure"], $params["httponly"]);
        }

        unset($_SESSION);
        session_unset();
        session_destroy();
      */

        unset($_SESSION[$session_name]);

        return true;
    }
}