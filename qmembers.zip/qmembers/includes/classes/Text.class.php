<?php

namespace includes\classes;


/**
 * Returns text according to a text key.
 * Implements Drupals translation function and replaces placeholders with config settings.
 */
class Text
{
    private $text;
    private $text_qmemberscom = array();
    private $config;


    /**
     * Constructor function.
     * Gets configurations from Config class (to be used in the text file) and the strings.
     * Sets string variable to be used in this class.
     */
    public function __construct()
    {
        $this->config    =  new Config;
        $qmembers_config = $this->config->getAll();

        require QMEMBERS_FILE_TEXT;

        if (file_exists(QMEMBERS_COM_TEXT)){

            require QMEMBERS_COM_TEXT;
            $this->text_qmemberscom = $qmemberscom_text;
        }

        $this->text = $qmembers_text;

    }

    /**
     *
     * Returns a string according to the submitted text key.
     * Implements Drupal's translation function.
     *
     * @param string $text_key      The key of the text array
     * @return string               The (eventually translated) string with placeholders replaced.
     *
     */
    public function get($text_key){

        if ( !isset($this->text[$text_key]['text']) ) return;


        if ( isset($this->text_qmemberscom[$text_key]['text']) ){

            // qmemberscom overrides qmembers
            $string = t($this->text_qmemberscom[$text_key]['text']); // Drupal translation function
        }
        else{
            $string = t($this->text[$text_key]['text']); // Drupal translation function
        }

        if ( strpos($string, '%1' ) !== false ){

            $string = self::replacePlaceholder($string, $text_key);
        }

        return $string;
    }

    /**
     *
     * Replaces string placeholder.
     *
     * @param string $string        The string that includes placeholders.
     * @param string $text_key      The key of the text array.
     * @return string               The string with placeholders replaced.
     *
     */
    private function replacePlaceholder($string, $text_key){

        $i = 1;
        $i_max = 999;

        while ( strpos($string, '%' . $i ) !== false ){

            if ( isset($this->text_qmemberscom[$text_key]['vars'][$i] ) ){

                // qmemberscom overrides qmembers
                $search  = '%' . $i;
                $replace = $this->text_qmemberscom[$text_key]['vars'][$i];
                $string  = str_replace( $search, $replace, $string);
            }
            else{
                if ( isset($this->text[$text_key]['vars'][$i] ) ){

                    $search  = '%' . $i;
                    $replace = $this->text[$text_key]['vars'][$i];
                    $string  = str_replace( $search, $replace, $string);
                }
            }


            if ($i >= $i_max) break; // just in case...

            $i++;
        }

        return $string;
    }




}