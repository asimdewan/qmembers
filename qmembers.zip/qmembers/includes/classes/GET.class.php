<?php

namespace includes\classes;


/**
 * Processes all forms
 */
class GET
{
    private $config_class;
    private $config;
    private $text;

    /**
     * Constructor function.
     * Gets configurations from Config class (to be used in this class).
     * Instantiates text class.
     */
    public function __construct()
    {
        $this->config_class = new Config;
        $this->config = $this->config_class->getAll();

        $this->text = new Text;

        if ( isset($_GET['aktion']) ){

            if(is_callable( array( $this, $_GET['aktion']) ) ){

                $action = $_GET['aktion'];

                $this->$action();
            }
        }
    }

    public function logout(){

        $user = new User;
        $result = $user->logout();

        if ( isset($result['redirect_url']) ){
            header('location:' . $result['redirect_url']);
            exit;
        }
    }
}
