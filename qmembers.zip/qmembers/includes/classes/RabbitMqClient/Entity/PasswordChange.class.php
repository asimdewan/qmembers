<?php
namespace includes\classes\RabbitMqClient\Entity;

class PasswordChange extends AbstractSerializableEntity
{
    /** @var  string */
    private $password;

    /** @var  string */
    private $hash;

    /**
     * @return string
     */
    public function getPassword()
    {
        return $this->password;
    }

    /**
     * @param string $password
     */
    public function setPassword($password)
    {
        $this->password = $password;
    }

    /**
     * @return string
     */
    public function getHash()
    {
        return $this->hash;
    }

    /**
     * @param string $hash
     */
    public function setHash($hash)
    {
        $this->hash = $hash;
    }
}