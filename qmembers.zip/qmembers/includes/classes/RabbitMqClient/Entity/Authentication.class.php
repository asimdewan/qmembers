<?php

namespace includes\classes\RabbitMqClient\Entity;

use includes\classes\RabbitMqClient\Exception\EmptyException;
use includes\classes\RabbitMqClient\Exception\InvalidArgumentException;

class Authentication
{
    /* @var string */
    private $host;

    /* @var int */
    private $port;

    /* @var string */
    private $user;

    /* @var string */
    private $password;

    /* @var string */
    private $queue;

    /* @var string */
    private $routingKey;

    /* @var string */
    private $exchange;

    /* @var string */
    private $vhost;

    /* @var string */
    private $certificate;

    public function __construct($host, $port, $user, $password, $queue, $routingKey, $exchange, $vhost, $certificate)
    {
        $this->setHost($host);
        $this->setPort($port);
        $this->setUser($user);
        $this->setPassword($password);
        $this->setQueue($queue);
        $this->setRoutingKey($routingKey);
        $this->setExchange($exchange);
        $this->setVhost($vhost);
        $this->setCertificate($certificate);
    }

    /**
     * @return string
     */
    public function getHost()
    {
        return $this->host;
    }

    /**
     * @param string $host
     * @throws EmptyException
     */
    private function setHost($host)
    {
        if (empty($host)) {
            throw new EmptyException('The host must not be empty.');
        }
        $this->host = $host;
    }

    /**
     * @return int
     */
    public function getPort()
    {
        return $this->port;
    }

    /**
     * @param int $port
     * @throws EmptyException
     */
    private function setPort($port)
    {
        if (empty($port)) {
            throw new EmptyException('The port must not be empty.');
        }
        if (!is_numeric($port)) {
            throw new InvalidArgumentException('The port must be a number');
        }
        $this->port = $port;
    }

    /**
     * @return string
     */
    public function getUser()
    {
        return $this->user;
    }

    /**
     * @param string $user
     * @throws EmptyException
     */
    private function setUser($user)
    {
        if (empty($user)) {
            throw new EmptyException('The user must not be empty.');
        }
        $this->user = $user;
    }

    /**
     * @return string
     */
    public function getPassword()
    {
        return $this->password;
    }

    /**
     * @param string $password
     * @throws EmptyException
     */
    private function setPassword($password)
    {
        if (empty($password)) {
            throw new EmptyException('The password must not be empty.');
        }
        $this->password = $password;
    }

    /**
     * @return string
     */
    public function getQueue()
    {
        return $this->queue;
    }

    /**
     * @param string $queue
     * @throws EmptyException
     */
    private function setQueue($queue)
    {
        if (empty($queue)) {
            throw new EmptyException('The queue must not be empty.');
        }
        $this->queue = $queue;
    }

    /**
     * @return string
     */
    public function getRoutingKey()
    {
        return $this->routingKey;
    }

    /**
     * @param string $routingKey
     * @throws EmptyException
     */
    public function setRoutingKey($routingKey)
    {
        if (empty($routingKey)) {
            throw new EmptyException('The routingKey must not be empty.');
        }
        $this->routingKey = $routingKey;
    }

    /**
     * @return string
     */
    public function getExchange()
    {
        return $this->exchange;
    }

    /**
     * @param string $exchange
     * @throws EmptyException
     */
    public function setExchange($exchange)
    {
        if (empty($exchange)) {
            throw new EmptyException('The exchange must not be empty.');
        }
        $this->exchange = $exchange;
    }

    /**
     * @return string
     */
    public function getVhost()
    {
        return $this->vhost;
    }

    /**
     * @param string $vhost
     * @throws EmptyException
     */
    public function setVhost($vhost)
    {
        if (empty($vhost)) {
            throw new EmptyException('The vhost must not be empty.');
        }
        $this->vhost = $vhost;
    }

    /**
     * @param string $certificate
     * @throws EmptyException
     */
    private function setCertificate($certificate)
    {
        if (empty($certificate)) {
            throw new EmptyException('The certificate must not be empty.');
        }
        $this->certificate = $certificate;
    }

    public function getSslOptions()
    {
        return [
            'cafile' => $this->certificate
        ];
    }

}