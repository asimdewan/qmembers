<?php
namespace includes\classes\RabbitMqClient\Entity;

interface DatabaseEntityInterface
{

}