<?php
namespace includes\classes\RabbitMqClient\Entity;

use JsonSerializable;
use ReflectionClass;

class AbstractSerializableEntity implements JsonSerializable
{
    /**
     * Specify data which should be serialized to JSON
     * @link http://php.net/manual/en/jsonserializable.jsonserialize.php
     * @return mixed data which can be serialized by <b>json_encode</b>,
     * which is a value of any type other than a resource.
     * @since 5.4.0
     */
    public function jsonSerialize()
    {
        return $this->createDataArray();
    }

    public function jsonSerializeForApi()
    {
        $entityReflection = new ReflectionClass(get_class($this));
        $className = $entityReflection->getShortName();

        $data = array(
            array(
                'type' => $className,
                'data' => $this->createDataArray()
            )
        );

        return json_encode($data);
    }

    /**
     * @param string $string
     * @param bool   $capitalizeFirstChar
     *
     * @return string
     */
    public function underscoreToCamelCase($string, $capitalizeFirstChar = false)
    {
        $str = \str_replace(' ', '', \ucwords(\str_replace('_', ' ', $string)));
        if (!$capitalizeFirstChar) {
            $str = \lcfirst($str);
        }

        return $str;
    }

    /**
     * @return array of class data
     */
    public function createDataArray()
    {
        $return = array();

        $entityReflection = new ReflectionClass(get_class($this));
        $properties = $entityReflection->getProperties();

        foreach ($properties as $property) {
            $propertyName = $property->getName();
            $getter = 'get' . $this->underscoreToCamelCase($propertyName, true);
            if ($entityReflection->hasMethod($getter)) {
                $return[$propertyName] = $this->$getter();
            }
        }

        return $return;
    }
}