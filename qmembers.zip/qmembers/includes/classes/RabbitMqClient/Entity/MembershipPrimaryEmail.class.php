<?php
namespace includes\classes\RabbitMqClient\Entity;

class MembershipPrimaryEmail extends AbstractSerializableEntity implements ApiEntityInterface, DatabaseEntityInterface
{
    /** @var string */
    private $id;

    /** @var int */
    private $primaryEmail;

    /**
     * @return string
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param string $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return int
     */
    public function getPrimaryEmail()
    {
        return $this->primaryEmail;
    }

    /**
     * @param int $primaryEmail
     */
    public function setPrimaryEmail($primaryEmail)
    {
        $this->primaryEmail = $primaryEmail;
    }

}