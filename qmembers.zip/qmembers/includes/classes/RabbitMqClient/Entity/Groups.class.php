<?php
namespace includes\classes\RabbitMqClient\Entity;

class Groups extends AbstractSerializableEntity implements ApiEntityInterface, DatabaseEntityInterface
{
    /** @var  string */
    private $id;

    /** @var  string */
    private $groups;

    /**
     * @return string
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param string $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return string
     */
    public function getGroups()
    {
        return $this->groups;
    }

    /**
     * @param string $groups
     */
    public function setGroups($groups)
    {
        $this->groups = $groups;
    }
}