<?php
namespace includes\classes\RabbitMqClient\Entity;

class TerminateMembership extends AbstractSerializableEntity implements ApiEntityInterface, DatabaseEntityInterface
{
    /** @var string */
    private $id;

    /** @var string */
    private $reason;

    /** @var string */
    private $message;

    /** @var bool */
    private $disclaimer;

    /**
     * @return string
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param string $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return string
     */
    public function getReason()
    {
        return $this->reason;
    }

    /**
     * @param string $reason
     */
    public function setReason($reason)
    {
        $this->reason = $reason;
    }

    /**
     * @return string
     */
    public function getMessage()
    {
        return $this->message;
    }

    /**
     * @param string $message
     */
    public function setMessage($message)
    {
        $this->message = $message;
    }

    /**
     * @return bool
     */
    public function getDisclaimer()
    {
        return $this->disclaimer;
    }

    /**
     * @param bool $disclaimer
     */
    public function setDisclaimer($disclaimer)
    {
        $this->disclaimer = $disclaimer;
    }
}