<?php
namespace includes\classes\RabbitMqClient\Entity;

class GroupUnsubscription extends AbstractSerializableEntity
{
    /** @var  string */
    private $id;

    /** @var  string */
    private $group;

    /**
     * @return string
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param string $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return string
     */
    public function getGroup()
    {
        return $this->group;
    }

    /**
     * @param string $group
     */
    public function setGroup($group)
    {
        $this->group = $group;
    }
}