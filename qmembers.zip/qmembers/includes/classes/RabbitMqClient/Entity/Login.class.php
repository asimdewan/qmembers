<?php
namespace includes\classes\RabbitMqClient\Entity;

class Login extends AbstractSerializableEntity
{
    /** @var  string */
    private $email;

    /** @var  string */
    private $password;

    /** @var  string */
    private $memberID;

    /**
     * @return string
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * @param string $email
     */
    public function setEmail($email)
    {
        $this->email = $email;
    }

    /**
     * @return string
     */
    public function getPassword()
    {
        return $this->password;
    }

    /**
     * @param string $password
     */
    public function setPassword($password)
    {
        $this->password = $password;
    }

    /**
     * @return string
     */
    public function getMemberID()
    {
        return $this->memberID;
    }

    /**
     * @param string $email
     */
    public function setMemberID($memberID)
    {
        $this->memberID = $memberID;
    }
}