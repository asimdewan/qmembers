<?php
namespace includes\classes\RabbitMqClient\Validator;

class MembershipPrimaryEmailValidator extends AbstractValidator {
    protected $validations = [
        [['id', 'primaryEmail'], 'required'],
    ];
}