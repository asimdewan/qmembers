<?php
namespace includes\classes\RabbitMqClient\Validator;

class PasswordChangeValidator extends AbstractValidator
{
    protected $validations = [
        [['password', 'hash'], 'required'],
        [['password'], 'password'],
    ];
}