<?php
namespace includes\classes\RabbitMqClient\Validator;

class PasswordRecoveryValidator extends AbstractValidator
{
    protected $validations = [
        [['email'], 'required'],
        [['email'], 'email'],
    ];
}