<?php
namespace includes\classes\RabbitMqClient\Validator;

class ImageValidator extends AbstractValidator
{
    protected $validations = [
        [['id', 'url'], 'required'],
        [['url', 'originalUrl'], 'url'],
    ];
}