<?php
namespace includes\classes\RabbitMqClient\Validator;

use includes\classes\RabbitMqClient\Entity\MembershipBilling;

class MembershipBillingValidator extends AbstractValidator
{
    protected $validations = [
        [['id', 'billingAddress'], 'required'],
        [['billingAddress'], 'integer'],
        [['firstName', 'lastName', 'company', 'address', 'zip', 'city', 'country', 'telephone'], 'required', 'billingAddress', MembershipBilling::BILLING_ADDRESS_OTHER],
        [['title', 'firstName', 'lastName', 'city', 'region', 'country'], 'maxlength', '50'],
        [['company', 'department', 'room', 'address', 'addressAddition'], 'maxlength', '255'],
        [['zip'], 'maxlength', '10'],
        [['email'], 'email'],
        [['telephone'], 'telephonenumber'],
    ];
}