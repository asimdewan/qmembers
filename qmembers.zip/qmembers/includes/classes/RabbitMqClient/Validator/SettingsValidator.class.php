<?php
namespace includes\classes\RabbitMqClient\Validator;

class SettingsValidator extends AbstractValidator
{
    protected $validations = [
        [['id', 'newPassword', 'oldPassword'], 'required'],
        [['newPassword', 'oldPassword'], 'password'],
    ];
}