<?php
namespace includes\classes\RabbitMqClient\Validator;

class GroupSubscriptionValidator extends AbstractValidator
{
    protected $validations = [
        [['id', 'group'], 'required'],
    ];
}