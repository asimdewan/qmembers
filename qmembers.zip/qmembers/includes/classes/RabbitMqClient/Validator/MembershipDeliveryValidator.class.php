<?php
namespace includes\classes\RabbitMqClient\Validator;

class MembershipDeliveryValidator extends AbstractValidator
{
    protected $validations = [
        [['id', 'deliveryAddress'], 'required'],
        [['deliveryAddress'], 'integer'],
    ];
}