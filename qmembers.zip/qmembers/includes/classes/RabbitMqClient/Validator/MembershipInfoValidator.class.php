<?php
namespace includes\classes\RabbitMqClient\Validator;

class MembershipInfoValidator extends AbstractValidator {
    protected $validations = [
        // TODO: Kerstin, please check if it is ok to just check the id
        //[['id', 'from', 'until', 'type', 'customerNumber'], 'required'],
        [['id'], 'required'],
    ];
}