<?php
namespace includes\classes\RabbitMqClient\Validator;

class LoginValidator extends AbstractValidator
{
    protected $validations = [
        [['email', 'password'], 'required'],
        [['email'], 'email'],
    ];
}