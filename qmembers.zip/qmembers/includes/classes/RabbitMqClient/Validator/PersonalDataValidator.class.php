<?php
namespace includes\classes\RabbitMqClient\Validator;

class PersonalDataValidator extends AbstractValidator
{
    protected $validations = [
        [['id', 'firstName', 'lastName', 'address', 'zip', 'city', 'email', 'telephone'], 'required'],
        [['title', 'firstName', 'lastName', 'city', 'region', 'country'], 'maxlength', '50'],
        [['address', 'addressAddition', 'xing', 'linkedIn'], 'maxlength', '255'],
        [['zip'], 'maxlength', '10'],
        [['email'], 'email'],
        [['xing', 'linkedIn'], 'url'],
        [['telephone'], 'telephonenumber'],
    ];
}