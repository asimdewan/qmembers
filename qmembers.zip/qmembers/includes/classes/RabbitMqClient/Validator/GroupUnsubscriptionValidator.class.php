<?php
namespace includes\classes\RabbitMqClient\Validator;

class GroupUnsubscriptionValidator extends AbstractValidator
{
    protected $validations = [
        [['id', 'group'], 'required'],
    ];
}