<?php
namespace includes\classes\RabbitMqClient\Validator;

use includes\classes\RabbitMqClient\Entity\AbstractSerializableEntity;

class AbstractValidator
{
    protected $validations = [];

    protected $errors = [];

    public function validate(AbstractSerializableEntity $objectData)
    {
        $data = $objectData->jsonSerialize();

        foreach ($this->validations as $validation) {
            $fields = $validation[0];
            $function = $validation[1];

            switch ($function) {
                case 'required':
                    if (isset($validation[2]) && isset($validation[3])) {
                        // required with condition
                        $whenField = $validation[2];
                        $whenValue = $validation[3];

                        foreach ($fields as $field) {
                            if (empty(trim($data[$field])) && $data[$whenField] == $whenValue) {
                                $this->errors[$field][] = 'field is required';
                            }
                        }
                    } else {
                        // required withOUT condition
                        foreach ($fields as $field) {
                            if (empty(trim($data[$field]))) {
                                $this->errors[$field][] = 'field is required';
                            }
                        }
                    }

                    break;
                case 'integer':
                    foreach ($fields as $field) {
                        if (!is_integer($data[$field])) {
                            $this->errors[$field][] = 'field needs to be an integer';
                        }
                    }
                    break;
                case 'bool':
                    $value = $validation[2];
                    foreach ($fields as $field) {
                        if (($data[$field]) !== $value) {
                            $this->errors[$field][] = 'field needs to a boolean of ' . ($value ? 'true' : 'false');
                        }
                    }
                    break;
                case 'email':
                    foreach ($fields as $field) {
                        if (!empty(trim($data[$field])) && !filter_var(trim($data[$field]), FILTER_VALIDATE_EMAIL)) {
                            $this->errors[$field][] = 'field needs to be an email address';
                        }
                    }
                    break;
                case 'url':
                    foreach ($fields as $field) {
                        if (!empty(trim($data[$field])) && !filter_var(trim($data[$field]), FILTER_VALIDATE_URL)) {
                            $this->errors[$field][] = 'field needs to be an url';
                        }
                    }
                    break;
                case 'telephonenumber':
                    foreach ($fields as $field) {
                        if (!empty(trim($data[$field])) && (substr($data[$field], 0, 1) != '+'|| !preg_match('/^[0-9]+$/', substr($data[$field], 1)))) {
                            $this->errors[$field][] = 'field needs to be an international telephonnumber e.g. +49301234567';
                        }
                    }
                    break;
                case 'maxlength':
                    $length = $validation[2];
                    foreach ($fields as $field) {
                        if (!empty(trim($data[$field])) && strlen(trim($data[$field])) > $length) {
                            $this->errors[$field][] = 'field should be maximum of ' . $length . ' characters';
                        }
                    }
                    break;
                case 'password':
                    foreach ($fields as $field) {
                        $length = 6;
                        if (!empty(trim($data[$field])) && strlen(trim($data[$field])) < $length) {
                            $this->errors[$field][] = 'field should be minimum of ' . $length . ' characters';
                        }
                    }
                    break;
            }
        }
        return empty($this->errors) ? true : false;
    }

    public function getErrors()
    {
        return $this->errors;
    }
}