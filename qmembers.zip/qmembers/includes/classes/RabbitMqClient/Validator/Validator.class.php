<?php

namespace includes\classes\RabbitMqClient\Validator;

use includes\classes\RabbitMqClient\Entity\AbstractSerializableEntity;
use includes\classes\RabbitMqClient\Entity\BusinessData;
use includes\classes\RabbitMqClient\Entity\GroupSubscription;
use includes\classes\RabbitMqClient\Entity\GroupUnsubscription;
use includes\classes\RabbitMqClient\Entity\Image;
use includes\classes\RabbitMqClient\Entity\Login;
use includes\classes\RabbitMqClient\Entity\MembershipBilling;
use includes\classes\RabbitMqClient\Entity\MembershipDelivery;
use includes\classes\RabbitMqClient\Entity\MembershipInfo;
use includes\classes\RabbitMqClient\Entity\MembershipPrimaryEmail;
use includes\classes\RabbitMqClient\Entity\PasswordChange;
use includes\classes\RabbitMqClient\Entity\PasswordRecovery;
use includes\classes\RabbitMqClient\Entity\PersonalData;
use includes\classes\RabbitMqClient\Entity\Settings;
use includes\classes\RabbitMqClient\Entity\TerminateMembership;
use includes\classes\RabbitMqClient\Exception\InvalidArgumentException;
use includes\classes\RabbitMqClient\Exception\ValidationException;

class Validator
{
    public function validate(AbstractSerializableEntity $entity)
    {
        if ($entity instanceof PersonalData) {
            $validator = new PersonalDataValidator();
        } elseif ($entity instanceof BusinessData) {
            $validator = new BusinessDataValidator();
        } elseif ($entity instanceof MembershipBilling) {
            $validator = new MembershipBillingValidator();
        } elseif ($entity instanceof MembershipDelivery) {
            $validator = new MembershipDeliveryValidator();
        } elseif ($entity instanceof TerminateMembership) {
            $validator = new TerminateMembershipValidator();
        } elseif ($entity instanceof Settings) {
            $validator = new SettingsValidator();
        } elseif ($entity instanceof Login) {
            $validator = new LoginValidator();
        } elseif ($entity instanceof PasswordRecovery) {
            $validator = new PasswordRecoveryValidator();
        } elseif ($entity instanceof PasswordChange) {
            $validator = new PasswordChangeValidator();
        } elseif ($entity instanceof GroupSubscription) {
            $validator = new GroupSubscriptionValidator();
        } elseif ($entity instanceof GroupUnsubscription) {
            $validator = new GroupUnsubscriptionValidator();
        } elseif ($entity instanceof Image) {
            $validator = new ImageValidator();
        } elseif ($entity instanceof MembershipInfo) {
            $validator = new MembershipInfoValidator();
        } elseif ($entity instanceof MembershipPrimaryEmail) {
            $validator = new MembershipPrimaryEmailValidator();
        } else {
            throw new InvalidArgumentException('entity must be in the list of the validators.');
        }

        $valid = $validator->validate($entity);

        if (!$valid) {
            throw new ValidationException($validator->getErrors());
        }
    }
}