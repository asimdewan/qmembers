<?php
namespace includes\classes\RabbitMqClient\Validator;

class TerminateMembershipValidator extends AbstractValidator
{
    protected $validations = [
        [['id', 'reason', 'message'], 'required'],
        [['disclaimer'], 'bool', true],
    ];
}