<?php
namespace includes\classes\RabbitMqClient\Validator;

class BusinessDataValidator extends AbstractValidator
{
    protected $validations = [
        [['id', 'company', 'position', 'address', 'zip', 'city', 'country', /*'email',*/ 'telephone'], 'required'],
        [['city', 'region', 'country', 'vatId'], 'maxlength', '50'],
        [['company', 'position', 'department', 'room', 'address', 'addressAddition', 'branch'], 'maxlength', '255'],
        [['zip'], 'maxlength', '10'],
        [['email'], 'email'],
        [['telephone'], 'telephonenumber'],
    ];

}