<?php

namespace includes\classes\RabbitMqClient;

use includes\classes\RabbitMqClient\Entity\AbstractSerializableEntity;
use includes\classes\RabbitMqClient\Entity\Authentication;
use PhpAmqpLib\Channel\AMQPChannel;
use PhpAmqpLib\Connection\AMQPSSLConnection;
use PhpAmqpLib\Exception\AMQPTimeoutException;
use PhpAmqpLib\Message\AMQPMessage;

class RabbitMqClient
{
    /** @var AMQPChannel  */
    private $channel;

    /** @var AMQPSSLConnection  */
    private $connection;

    /** @var  Authentication */
    private $authentication;

    public function connect(Authentication $authentication)
    {
        $this->authentication = $authentication;

        // setup connection
        $this->connection = new AMQPSSLConnection(
            $authentication->getHost(),
            $authentication->getPort(),
            $authentication->getUser(),
            $authentication->getPassword(),
            $authentication->getVhost(),
            $authentication->getSslOptions()
        );
        // creates a channel (with parameter you can use an existing one)
        $this->channel = $this->connection->channel();

        // declare a queue
        $this->channel->queue_declare(
            $this->authentication->getQueue(),
            false,
            true,
            false,
            false
        );
    }

    public function publishData(AbstractSerializableEntity $entity)
    {
        $data = $entity->jsonSerializeForApi();

        // create the message
        $message = new AMQPMessage($data, array('delivery_mode' => AMQPMessage::DELIVERY_MODE_PERSISTENT));

        /*
        db_set_active();
        watchdog('qmembers', 'RabbitMQ - Published Message:' . json_encode($message), array(), WATCHDOG_DEBUG);
        db_set_active('qmembers');
        */

        // send it to the queue over the channel
        $this->channel->basic_publish(
            $message,
            $this->authentication->getExchange(),
            $this->authentication->getRoutingKey()
        );
    }

    public function consumeData($timeout, \Closure $callback)
    {
        try {
            $this->channel->basic_qos(null, 20, null);
            $this->channel->basic_consume(
                $this->authentication->getQueue(),
                '',
                false,
                false,
                false,
                false,
                $callback
            );

            while(count($this->channel->callbacks)) {
                $this->channel->wait(NULL, true, $timeout);
            }
        } catch (AMQPTimeoutException $exception) {
            db_set_active();
            watchdog('qmembers', 'AMQPTimeoutException:' . $exception->getMessage(), array(), WATCHDOG_DEBUG);
            db_set_active('qmembers');
        } catch (\Exception $exception) {
            db_set_active();
            watchdog('qmembers', 'Exception:' . $exception->getMessage(), array(), WATCHDOG_ALERT);
            db_set_active('qmembers');
        }
    }

    public function disconnect()
    {
        $this->channel->close();
        $this->connection->close();
    }
}