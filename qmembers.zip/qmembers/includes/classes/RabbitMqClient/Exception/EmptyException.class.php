<?php

namespace includes\classes\RabbitMqClient\Exception;

use Exception;

class EmptyException extends Exception
{
}