<?php

namespace includes\classes\RabbitMqClient\Exception;

use Exception;
use Throwable;

class ValidationException extends Exception
{
    /** @var  array */
    private $errors;

    public function __construct($errors = [], $code = 0, Throwable $previous = null)
    {
        $this->errors = $errors;
        parent::__construct('Validation Errors', $code, $previous);
    }

    public function getErrors()
    {
        return $this->errors;
    }
}