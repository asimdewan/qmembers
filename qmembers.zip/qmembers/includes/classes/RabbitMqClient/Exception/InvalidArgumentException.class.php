<?php

namespace includes\classes\RabbitMqClient\Exception;

class InvalidArgumentException extends \InvalidArgumentException
{

}