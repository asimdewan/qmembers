<?php
namespace includes\classes\DatabaseClient\Exceptions;

class InvalidMessageException extends \Exception {

}