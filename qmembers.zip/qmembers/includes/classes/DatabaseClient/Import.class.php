<?php
namespace includes\classes\DatabaseClient;

use includes\classes\Config;
use includes\classes\DatabaseClient\Exceptions\InvalidMessageException;
use includes\classes\RabbitMqClient\Entity\Authentication;
use includes\classes\RabbitMqClient\RabbitMqClient;
use PhpAmqpLib\Channel\AMQPChannel;
use PhpAmqpLib\Message\AMQPMessage;

class Import extends AbstractImport
{
    /** @var Authentication  */
    private $rabbitMqAuth;

    /** @var array  */
    private $config;

    public function __construct()
    {
        $configClass = new Config;
        $this->config = $configClass->getAll();

        $this->rabbitMqAuth = new Authentication(
            $this->config['rabbitmq']['read']['host'],
            $this->config['rabbitmq']['read']['port'],
            $this->config['rabbitmq']['read']['user'],
            $this->config['rabbitmq']['read']['password'],
            $this->config['rabbitmq']['read']['queue'],
            $this->config['rabbitmq']['read']['routing_key'],
            $this->config['rabbitmq']['read']['exchange'],
            $this->config['rabbitmq']['read']['vhost'],
            $this->config['rabbitmq']['read']['certificate']
        );

        parent::__construct();
    }

    public function getErrors()
    {
        return $this->errors;
    }

    public function save()
    {
        if (variable_get('qmembers_rabbitmq_read_enable', false)) {
            $client = new RabbitMqClient();
            $client->connect($this->rabbitMqAuth);
            $importClass = $this;
            $client->consumeData(
                $this->config['rabbitmq']['read']['timeout'],
                function(AMQPMessage $message) use ($importClass) {
                    try {
                        $importClass->callback($message->body);

                        /** @var AMQPChannel $channel */
                        $channel = $message->delivery_info['channel'];
                        $channel->basic_ack($message->delivery_info['delivery_tag']);

                    } catch (InvalidMessageException $exception) {
                        db_set_active();
                        watchdog('qmembers', 'InvalidMessageException: ' . $exception->getMessage(), array(), WATCHDOG_WARNING);
                        db_set_active('qmembers');

                        // also ack faulty messages
                        /** @var AMQPChannel $channel */
                        $channel = $message->delivery_info['channel'];
                        $channel->basic_ack($message->delivery_info['delivery_tag']);

                    } catch (\Exception $exception) {
                        db_set_active();
                        watchdog('qmembers', 'Exception: ' . $exception->getMessage(), array(), WATCHDOG_ALERT);
                        db_set_active('qmembers');

                        // also ack faulty messages
                        /** @var AMQPChannel $channel */
                        $channel = $message->delivery_info['channel'];
                        $channel->basic_ack($message->delivery_info['delivery_tag']);
                    }
                }
            );
            $client->disconnect();
        }
    }

    public function callback($message)
    {
        db_set_active();
        watchdog('qmembers', 'RabbitMQ callback: ' . $message, array(), WATCHDOG_DEBUG);
        db_set_active('qmembers');

        $data = json_decode($message, true);
        if (!is_array($data)) {
            throw new InvalidMessageException('The data should contain an json encoded array');
        }

        if (isset($data[0]['type']) && in_array($data[0]['type'], $this->memberTypes)) {
            $success = $this->saveMemberData($data, false);
            if (!$success) {
                $errors = $this->getErrors();
                foreach ($errors as $error) {
                    db_set_active();
                    watchdog('qmembers', 'Error Memberdata: ' . $error, array(), WATCHDOG_ALERT);
                    db_set_active('qmembers');
                }
                throw new \Exception('Member data could not be updated.');
            }
        }

        if (isset($data['type']) && in_array($data['type'], $this->metadataTypes)) {
            $success = $this->saveMetaData($data['data']);
            if (!$success) {
                $errors = $this->getErrors();
                foreach ($errors as $error) {
                    db_set_active();
                    watchdog('qmembers', 'Error Metadata: ' . $error, array(), WATCHDOG_ALERT);
                    db_set_active('qmembers');
                }
                throw new \Exception('Meta data could not be updated.');
            }
        }

        if (isset($data[0]['type']) && in_array($data[0]['type'], $this->supporterTypes)) {
            $success = $this->saveSupporterData($data[0]['data']);
            if (!$success) {
                $errors = $this->getErrors();
                foreach ($errors as $error) {
                    db_set_active();
                    watchdog('qmembers', 'Error Supporterdata: ' . $error, array(), WATCHDOG_ALERT);
                    db_set_active('qmembers');
                }
                throw new \Exception('Supporter data could not be updated.');
            }
        }
    }
}