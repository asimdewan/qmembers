<?php
namespace includes\classes\DatabaseClient;

class InitialImport extends AbstractImport
{
    /** @var  string */
    private $file;

    /** @var  array */
    private $data;

    public function __construct($file)
    {
        $this->file = $file;
        parent::__construct();
    }

    private function readFile()
    {
        $jsonString = file_get_contents($this->file);
        $data = json_decode($jsonString, true);
        if (!is_array($data)) {
            return false;
        }

        $this->data = $data;
        return true;
    }

    public function save()
    {
        $success = $this->readFile();
        if (!$success) {
            $this->errors[] = 'File could not be read.';
            return false;
        }

        $success = $this->import();
        if (!$success) {
            return false;
        }

        return true;
    }

    public function getErrors()
    {
        return $this->errors;
    }

    private function import()
    {
        if (!empty($this->data)) {
            foreach ($this->data as $key => $data) {

                if (isset($data[0]['type']) && in_array($data[0]['type'], $this->memberTypes)) {
                    db_set_active();
                    watchdog('qmembers', 'import member ' . json_encode($data), array(), WATCHDOG_DEBUG);
                    db_set_active('qmembers');
                    $success = $this->saveMemberData($data);
                    if (!$success) {
                        continue;
                    }
                }

                if (isset($data['type']) && in_array($data['type'], $this->metadataTypes)) {
                    db_set_active();
                    watchdog('qmembers', 'import metadata ' . json_encode($data), array(), WATCHDOG_DEBUG);
                    db_set_active('qmembers');
                    $success = $this->saveMetaData($data['data']);
                    if (!$success) {
                        continue;
                    }
                }

                if (isset($data[0]['type']) && in_array($data[0]['type'], $this->supporterTypes)) {
                    db_set_active();
                    watchdog('qmembers', 'import supporter ' . json_encode($data), array(), WATCHDOG_DEBUG);
                    db_set_active('qmembers');
                    $success = $this->saveSupporterData($data[0]['data']);
                    if (!$success) {
                        continue;
                    }
                }
            }
        } else {
            $this->errors[] = 'Keine Daten in dem richtigen Format vorhanden.';
        }

        return empty($this->errors) ? true : false;
    }
}