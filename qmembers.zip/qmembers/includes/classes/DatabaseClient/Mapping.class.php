<?php
namespace includes\classes\DatabaseClient;

/**
 * be aware that all functions are used, due to magic function call in getMappingByName()
 * IDE cannot see that, so do not remove 'unused' functions
 */
class Mapping
{
    private $personalData = array(
        'id' => 'id',
        'salutation' => 'salutation_personal',
        'title' => 'title_personal',
        'firstName' => 'first_name_personal',
        'lastName' => 'last_name_personal',
        'dateOfBirth' => 'birthdate_personal',
        'address' => 'street_number_personal',
        'addressAddition' => 'line_personal',
        'zip' => 'zip_personal',
        'city' => 'city_personal',
        'region' => 'state_personal',
        'country' => 'country_personal',
        'email' => 'email_personal',
        'telephone' => 'phone_personal',
        'xing' => 'xing_personal',
        'linkedIn' => 'linkedin_personal',
    );

    private $businessData = array(
        'id' => 'id',
        'company' => 'company_professional',
        'position' => 'function_professional',
        'department' => 'department_professional',
        'room' => 'office_number_professional',
        'address' => 'street_number_professional',
        'addressAddition' => 'line_professional',
        'zip' => 'zip_professional',
        'city' => 'city_professional',
        'region' => 'state_professional',
        'country' => 'country_professional',
        'email' => 'email_professional',
        'telephone' => 'phone_professional',
        'vatId' => 'vat_professional',
        'branch' => 'business_professional',
    );

    private $membershipBilling = array(
        'id' => 'id',
        'billingAddress' => 'billing_address_membership',
        'title' => 'title_membership',
        'firstName' => 'first_name_membership',
        'lastName' => 'last_name_membership',
        'company' => 'company_membership',
        'department' => 'department_membership',
        'room' => 'office_number_membership',
        'address' => 'street_number_membership',
        'addressAddition' => 'line_membership',
        'zip' => 'zip_membership',
        'city' => 'city_membership',
        'region' => 'state_membership',
        'country' => 'country_membership',
        'email' => 'email_membership',
        'telephone' => 'phone_membership',
    );

    private $membershipDelivery = array(
        'id' => 'id',
        'deliveryAddress' => 'press_magazine_membership',
    );

    private $terminateMembership = array(
        'id' => 'id',
        'reason' => 'reason_termination',
        'message' => 'message_termination',
        'disclaimer' => 'disclaimer_termination',
    );

    private $settings = array(
        'id' => 'id',
        'newPassword' => 'password',
    );

    private $login = array(
        'email' => 'email',
        'password' => 'password',
    );

    private $passwordRecovery = array(
        'email' => 'email',
    );

    private $passwordChange = array(
        'password' => 'change_password',
        'hash' => 'hash_password_change',
    );

    private $groups = array(
        'id' => 'id',
        'groups' => 'groups',
        'group' => 'group_id',
    );

    private $image = array(
        'id' => 'id',
        'url' => 'personal_picture',
        'originalUrl' => 'original_personal_picture',
    );

    private $membershipInfo = array(
        'id' => 'id',
        'from' => 'membership_from',
        'canceled' => 'membership_canceled',
        'until' => 'membership_until',
        'type' => 'membership_level',
        'customerNumber' => 'customer_number'
    );

    private $membershipPrimaryEmail = array(
        'primaryEmail' => 'prim_email_membership'
    );

    private $serviceProviders = array(
        'branch' => 'service_provider_branch',
        'country' => 'service_provider_country',
        'company' => 'service_provider_company',
        'id' => 'service_provider_id',
        'city' => 'service_provider_city',
        'telephone' => 'service_provider_telephone',
        'email' => 'service_provider_email',
        'zip' => 'service_provider_zip',
        'address' => 'service_provider_street',
        'region' => 'service_provider_region'
    );

    /**
     * @return array
     */
    public function getPersonalData()
    {
        return $this->personalData;
    }

    /**
     * @return array
     */
    public function getBusinessData()
    {
        return $this->businessData;
    }

    /**
     * @return array
     */
    public function getMembershipBilling()
    {
        return $this->membershipBilling;
    }

    /**
     * @return array
     */
    public function getMembershipDelivery()
    {
        return $this->membershipDelivery;
    }

    /**
     * @return array
     */
    public function getTerminateMembership()
    {
        return $this->terminateMembership;
    }

    /**
     * @return array
     */
    public function getSettings()
    {
        return $this->settings;
    }

    /**
     * @return array
     */
    public function getGroups()
    {
        return $this->groups;
    }

    /**
     * @return array
     */
    public function getImage()
    {
        return $this->image;
    }

    public function getMappingByName($name)
    {
        $functionName = 'get' . $name;
        if (method_exists($this, $functionName)) {
            return $this->{$functionName}();
        }

        return array();
    }

    public function getMembershipInfo()
    {
        return $this->membershipInfo;
    }

    public function getMembershipPrimaryEmail()
    {
        return $this->membershipPrimaryEmail;
    }

    private function getLogin()
    {
        return $this->login;
    }

    private function getPasswordRecovery()
    {
        return $this->passwordRecovery;
    }

    private function getPasswordChange()
    {
        return $this->passwordChange;
    }

    public function getServiceProviders()
    {
        return $this->serviceProviders;
    }
}