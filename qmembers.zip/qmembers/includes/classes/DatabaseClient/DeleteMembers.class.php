<?php
namespace includes\classes\DatabaseClient;

class DeleteMembers
{
    /**
     * @var DatabaseClient
     */
    private $databaseClient;

    public function __construct()
    {
        $mapping = new Mapping();

        $this->databaseClient = new DatabaseClient($mapping);
    }

    public function run() {
        $members = $this->databaseClient->getExpiredMembers();

        foreach ($members as $memberId => $membershipUntil) {
            $success = $this->databaseClient->deleteMember($memberId);
            if ($success) {
                db_set_active();
                watchdog('qmembers', 'Member ' . $memberId . ' was deleted because membership_until "' . $membershipUntil . '"', array(), WATCHDOG_DEBUG);
                db_set_active('qmembers');
            } else {
                db_set_active();
                watchdog('qmembers', 'Member ' . $memberId . ' was not deleted ("' . $membershipUntil . '")', array(), WATCHDOG_WARNING);
                db_set_active('qmembers');
            }
        }
    }
}