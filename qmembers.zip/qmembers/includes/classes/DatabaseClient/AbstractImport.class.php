<?php
namespace includes\classes\DatabaseClient;

use includes\classes\Config;
use includes\classes\RabbitMqClient\Entity\BusinessData;
use includes\classes\RabbitMqClient\Entity\DatabaseEntityInterface;
use includes\classes\RabbitMqClient\Entity\Groups;
use includes\classes\RabbitMqClient\Entity\MembershipBilling;
use includes\classes\RabbitMqClient\Entity\MembershipInfo;
use includes\classes\RabbitMqClient\Entity\MembershipPrimaryEmail;
use includes\classes\RabbitMqClient\Entity\PersonalData;
use includes\classes\RabbitMqClient\Entity\TerminateMembership;
use PDOException;

class AbstractImport {

    /** @var  array */
    private   $config;

    protected $errors;

    protected $memberTypes = array(
        'PersonalData',
        'BusinessData',
        'MembershipBilling',
        'TerminateMembership',
        'MembershipInfo',
    );

    protected $metadataTypes = array(
        'MetaData',
    );

    protected $supporterTypes = array(
        'SupporterData',
    );

    protected $groupTypes = array(
        'Groups'
    );

    public function __construct()
    {
        $mapping = new Mapping();

        $this->databaseClient = new DatabaseClient($mapping);

        $config_class = new Config;
        $this->config = $config_class->getAll();
    }

    protected function saveMemberData($memberData, $initial = true)
    {
        $memberObjects = array();

        foreach ($memberData as $member) {
            if ($member['type'] == 'PersonalData') {
                $memberObjects[$member['type']] = $this->fillPersonalData($member['data']);
            }

            if ($member['type'] == 'BusinessData') {
                $memberObjects[$member['type']] = $this->fillBusinessData($member['data']);
            }

            if ($member['type'] == 'MembershipBilling') {
                $memberObjects[$member['type']] = $this->fillMembershipBilling($member['data']);
            }

            if ($member['type'] == 'TerminateMembership') {
                $memberObjects[$member['type']] = $this->fillTerminateMembership($member['data']);
            }

            if ($member['type'] == 'MembershipInfo') {
                $memberObjects[$member['type']] = $this->fillMembershipInfo($member['data']);
            }

            if ($member['type'] == 'MembershipPrimaryEmail') {
                $memberObjects[$member['type']] = $this->fillMembershipPrimaryEmail($member['data']);
            }

            if ($member['type'] == 'Groups') {
                $memberObjects[$member['type']] = $this->fillGroups($member['data']);
            }
        }

        $memberId                 = $memberObjects['BusinessData']->getId();
        $memberEmailProfessional  = $memberObjects['BusinessData']->getEmail();
        $memberEmailPersonal      = $memberObjects['PersonalData']->getEmail();


        // Validate if at least one email exists
        if ( empty($memberEmailProfessional) && empty($memberEmailPersonal) ) {
            $this->errors[] = 'Id: ' . $memberId . ' | Fehler: Berufliche und persönliche E-Mail sind beide leer.';
            return false;
        }

        // Validate if member id exists
        if ( empty($memberId) ) {
            $this->errors[] = 'Berufliche-Mail: ' . $memberEmailProfessional . ' | Persönliche E-Mail: ' . $memberEmailPersonal . ' | Fehler: Business Data id darf nicht leer sein. ';
            return false;
        }

        // check which billing address is chosen
        $memberObjects['MembershipBilling'] = $this->finalizeBillingAddress($memberObjects['MembershipBilling'], $memberObjects['BusinessData'], $memberObjects['PersonalData']);

        // save Member first, because of email and password
        if( !empty($memberEmailProfessional) ) $memberEmail = $memberEmailProfessional;
        else                                   $memberEmail = $memberEmailPersonal;

        // Disable the primary login email (saved in the "member" table) for certain member ids.
        /* Explanation: This is a special requirement for users that have a "Fördermitglied" account and a "Vollmitglied" account.
           These cannot use the same email as primary login email since this needs to be unique. So we disable
           the primary email for the "Fördermitglied" account, because these members are not allowed to login to
           the portal anyway.
        */
        if ( isset($this->config['disable-primary-login-email-for-these-member-ids-during-data-import']) && !empty($this->config['disable-primary-login-email-for-these-member-ids-during-data-import']) ){

            $excluded_member_ids = explode(',', $this->config['disable-primary-login-email-for-these-member-ids-during-data-import']);

            if ( in_array($memberId, $excluded_member_ids)){
                $memberEmail = 'PRIMARY_LOGIN_EMAIL_DISABLED@' . $memberId . '.DISABLED';
            }
        }

        try {
            $this->saveMember($memberId, $memberEmail, $initial);
        } catch (PDOException $exception) {
            $this->errors[] = 'Id: ' . $memberId . ' Datenbank Fehler: ' . $exception->getMessage();
            return false;
        } catch (\Exception $exception) {
            $this->errors[] = 'Id: ' . $memberId . ' Allgemeiner Fehler: ' . $exception->getMessage();
            return false;
        }

        // save all metadata
        try {
            foreach ($memberObjects as $data) {
                if (!empty($data) && $data instanceof DatabaseEntityInterface) {
                    $this->databaseClient->save($data);
                }
            }
        } catch (PDOException $exception) {
            $this->errors[] = 'Id: ' . $memberId . ' Datenbank Fehler: ' . $exception->getMessage();
            return false;
        } catch (\Exception $exception) {
            $this->errors[] = 'Id: ' . $memberId . ' Allgemeiner Fehler: ' . $exception->getMessage();
            return false;
        }

        return true;
    }

    protected function saveMember($id, $email, $initial)
    {
        $table = 'member';
        $password = password_hash(uniqid('', true), PASSWORD_DEFAULT);
//        $password = password_hash('123456', PASSWORD_DEFAULT);

        $entry = array(
            'memberid' => $id,
            'password' => $password,
            'email' => $email,
        );

        if ($initial) {
            db_insert($table, array())->fields($entry)->execute();
        } else {
            $exists = $this->databaseClient->doesMemberExist($id);
            if (!empty($exists)) {
                // remove password on update
                unset($entry['password']);
                db_update($table, array())->fields($entry)->condition('id', $exists)->execute();
            } else {
                db_insert($table, array())->fields($entry)->execute();
            }
        }
    }

    /**
     * @param $data
     * @return PersonalData
     */
    protected function fillPersonalData($data)
    {
        $personalData = new PersonalData();
        $personalData->setId(isset($data['id']) ? $data['id'] : '');
        $personalData->setSalutation(isset($data['salutation']) ? $data['salutation'] : '');
        $personalData->setTitle(isset($data['title']) ? $data['title'] : '');
        $personalData->setFirstName(isset($data['firstName']) ? $data['firstName'] : '');
        $personalData->setLastName(isset($data['lastname']) ? $data['lastname'] : (isset($data['lastName']) ? $data['lastName'] : ''));
        $personalData->setDateOfBirth(isset($data['dateOfBirth']) ? $data['dateOfBirth'] : '');
        $personalData->setAddress(isset($data['address']) ? $data['address'] : '');
        $personalData->setAddressAddition(isset($data['addressAddition']) ? $data['addressAddition'] : '');
        $personalData->setZip(isset($data['zip']) ? $data['zip'] : '');
        $personalData->setCity(isset($data['city']) ? $data['city'] : '');
        $personalData->setRegion(isset($data['region']) ? $data['region'] : '');
        $personalData->setCountry(isset($data['country']) ? $data['country'] : '');
        $personalData->setEmail(isset($data['email']) ? $data['email'] : '');
        $personalData->setTelephone(isset($data['telephone']) ? $data['telephone'] : '');
        $personalData->setXing(isset($data['xing']) ? $data['xing'] : '');
        $personalData->setLinkedIn(isset($data['linkedIn']) ? $data['linkedIn'] : '');
        return $personalData;
    }

    /**
     * @param $data
     * @return BusinessData
     */
    protected function fillBusinessData($data)
    {
        $businessData = new BusinessData();
        $businessData->setId(isset($data['id']) ? $data['id'] : '');
        $businessData->setCompany(isset($data['company']) ? $data['company'] : '');
        $businessData->setPosition(isset($data['position']) ? $data['position'] : '');
        $businessData->setDepartment(isset($data['department']) ? $data['department'] : '');
        $businessData->setRoom(isset($data['room']) ? $data['room'] : '');
        $businessData->setAddress(isset($data['address']) ? $data['address'] : '');
        $businessData->setAddressAddition(isset($data['addressAddition']) ? $data['addressAddition'] : '');
        $businessData->setZip(isset($data['zip']) ? $data['zip'] : '');
        $businessData->setCity(isset($data['city']) ? $data['city'] : '');
        $businessData->setRegion(isset($data['region']) ? $data['region'] : '');
        $businessData->setCountry(isset($data['country']) ? $data['country'] : '');
        $businessData->setEmail(isset($data['email']) ? $data['email'] : '');
        $businessData->setTelephone(isset($data['telephone']) ? $data['telephone'] : '');
        $businessData->setVatId(isset($data['vatId']) ? $data['vatId'] : '');
        $businessData->setBranch(isset($data['branch']) ? $data['branch'] : '');
        return $businessData;
    }

    /**
     * @param $data
     * @return MembershipBilling
     */
    protected function fillMembershipBilling($data)
    {
        $membershipBilling = new MembershipBilling();
        $membershipBilling->setId(isset($data['id']) ? $data['id'] : '');
        $membershipBilling->setCompany(isset($data['company']) ? $data['company'] : '');
        $membershipBilling->setDepartment(isset($data['department']) ? $data['department'] : '');
        $membershipBilling->setRoom(isset($data['room']) ? $data['room'] : '');
        $membershipBilling->setAddress(isset($data['address']) ? $data['address'] : '');
        $membershipBilling->setAddressAddition(isset($data['addressAddition']) ? $data['addressAddition'] : '');
        $membershipBilling->setZip(isset($data['zip']) ? $data['zip'] : '');
        $membershipBilling->setCity(isset($data['city']) ? $data['city'] : '');
        $membershipBilling->setRegion(isset($data['region']) ? $data['region'] : '');
        $membershipBilling->setCountry(isset($data['country']) ? $data['country'] : '');
        $membershipBilling->setTitle(isset($data['title']) ? $data['title'] : '');
        $membershipBilling->setFirstName(isset($data['firstName']) ? $data['firstName'] : '');
        $membershipBilling->setLastName(isset($data['lastName']) ? $data['lastName'] : '');
        return $membershipBilling;
    }

    protected function fillTerminateMembership($data)
    {
        $terminateMembership = new TerminateMembership();
        $terminateMembership->setId(isset($data['id']) ? $data['id'] : '');
        $terminateMembership->setMessage(isset($data['message']) ? $data['message'] : '');
        $terminateMembership->setReason(isset($data['reason']) ? $data['reason'] : '');
        $terminateMembership->setDisclaimer(empty($terminateMembership->getReason()) ? false : true);
        return $terminateMembership;
    }

    /**
     * @param $data
     * @return MembershipInfo
     */
    protected function fillMembershipInfo($data)
    {
        $membershipInfo = new MembershipInfo();
        $membershipInfo->setId(isset($data['id']) ? $data['id'] : '');
        $membershipInfo->setFrom(isset($data['membershipFrom']) ? $data['membershipFrom'] : '');
        $membershipInfo->setUntil(isset($data['membershipUntil']) ? $data['membershipUntil'] : '');
        $membershipInfo->setType(isset($data['membershipType']) ? $data['membershipType'] : '');
        $membershipInfo->setCustomerNumber(isset($data['customerNumber']) ? $data['customerNumber'] : '');
        return $membershipInfo;
    }

    protected function fillMembershipPrimaryEmail($data)
    {
        $membershipInfo = new MembershipPrimaryEmail();
        $membershipInfo->setId(isset($data['id']) ? $data['id'] : '');
        $membershipInfo->setPrimaryEmail(isset($data['primaryEmail']) ? $data['primaryEmail'] : '');
        return $membershipInfo;
    }

    protected function fillGroups($data)
    {
        $groups = new Groups();
        $groups->setId(isset($data['id']) ? $data['id'] : '');
        $groups->setGroups(isset($data['groups']) ? $data['groups'] : '');
        return $groups;
    }

    protected function finalizeBillingAddress(MembershipBilling $membershipBilling, BusinessData $businessData, PersonalData $personalData)
    {
        $resetBillingAddress = false;

        // check if business address == billing address - set to 'firma'
        if ($this->checkBusinessAddress($membershipBilling, $businessData)) {
            $membershipBilling->setBillingAddress(MembershipBilling::BILLING_ADDRESS_COMPANY);
            $resetBillingAddress = true;
        }

        // check if personal address == billing address - set to 'private'
        if ($this->checkPersonalAddress($membershipBilling, $personalData)) {
            $membershipBilling->setBillingAddress(MembershipBilling::BILLING_ADDRESS_PRIVATE);
            $resetBillingAddress = true;
        }

        // reset billing address
        if ($resetBillingAddress) {
            $membershipBilling->setCompany(null);
            $membershipBilling->setDepartment(null);
            $membershipBilling->setRoom(null);
            $membershipBilling->setAddress(null);
            $membershipBilling->setAddressAddition(null);
            $membershipBilling->setZip(null);
            $membershipBilling->setCity(null);
            $membershipBilling->setRegion(null);
            $membershipBilling->setCountry(null);
        } else {
            // if none of those - set to 'other address'
            $membershipBilling->setBillingAddress(MembershipBilling::BILLING_ADDRESS_OTHER);
        }

        return $membershipBilling;
    }

    private function checkBusinessAddress(MembershipBilling $membershipBilling, BusinessData $businessData)
    {
        if ($membershipBilling->getCompany() != $businessData->getCompany()) {
            return false;
        }
        if ($membershipBilling->getDepartment() != $businessData->getDepartment()) {
            return false;
        }
        if ($membershipBilling->getRoom() != $businessData->getRoom()) {
            return false;
        }
        if ($membershipBilling->getAddress() != $businessData->getAddress()) {
            return false;
        }
        if ($membershipBilling->getAddressAddition() != $businessData->getAddressAddition()) {
            return false;
        }
        if ($membershipBilling->getZip() != $businessData->getZip()) {
            return false;
        }
        if ($membershipBilling->getCity() != $businessData->getCity()) {
            return false;
        }
        if ($membershipBilling->getRegion() != $businessData->getRegion()) {
            return false;
        }
        if ($membershipBilling->getCountry() != $businessData->getCountry()) {
            return false;
        }

        return true;
    }

    private function checkPersonalAddress(MembershipBilling $membershipBilling, PersonalData $personalData)
    {
        /*
         * die Felder hat personal Data nicht
        if ($membershipBilling->getCompany() != $personalData->getCompany()) {
            return false;
        }
        if ($membershipBilling->getDepartment() != $personalData->getDepartment()) {
            return false;
        }
        if ($membershipBilling->getRoom() != $personalData->getRoom()) {
            return false;
        }
        */
        if ($membershipBilling->getAddress() != $personalData->getAddress()) {
            return false;
        }
        if ($membershipBilling->getAddressAddition() != $personalData->getAddressAddition()) {
            return false;
        }
        if ($membershipBilling->getZip() != $personalData->getZip()) {
            return false;
        }
        if ($membershipBilling->getCity() != $personalData->getCity()) {
            return false;
        }
        if ($membershipBilling->getRegion() != $personalData->getRegion()) {
            return false;
        }
        if ($membershipBilling->getCountry() != $personalData->getCountry()) {
            return false;
        }

        return true;
    }

    public function saveMetaData($metadata)
    {
        $this->saveMetaDate('country', 'name', $metadata['country']);
        $this->saveMetaDate('region', 'name', $metadata['region']);
        $this->saveMetaDate('reason', 'name', $metadata['reason']);
        $this->saveMetaDate('branch', 'name', $metadata['branch']);
        return true;
    }

    private function saveMetaDate($table, $field, $values)
    {
        $this->databaseClient->truncateTable($table);

        if (!empty($values)) {
            try {
                foreach ($values as $date) {
                    $entry = [
                        $field => $date
                    ];
                    $exists = $this->databaseClient->doesMetaExist($table, $field, $date);
                    if (!$exists) {
                        db_insert($table, array())->fields($entry)->execute();
                    }
                }
            } catch (PDOException $exception) {
                $this->errors[] = 'Table: ' . $table . ' Datenbank Fehler: ' . $exception->getMessage();
                return false;
            } catch (\Exception $exception) {
                $this->errors[] = 'Table: ' . $table . ' Allgemeiner Fehler: ' . $exception->getMessage();
                return false;
            }
        }
        return true;
    }

    public function saveSupporterData($data)
    {
        if (!empty($data)) {

            try {
                $table = 'service_providers';
                $entry = [
                    'service_provider_id' => isset($data['id']) ? $data['id'] : '',
                    'service_provider_company' => isset($data['company']) ? $data['company'] : '',
                    'service_provider_street' => isset($data['address']) ? $data['address'] : '',
                    'service_provider_zip' => isset($data['zip']) ? $data['zip'] : '',
                    'service_provider_city' => isset($data['city']) ? $data['city'] : '',
                    'service_provider_region' => isset($data['region']) ? $data['region'] : '',
                    'service_provider_country' => isset($data['country']) ? $data['country'] : '',
                    'service_provider_branch' => isset($data['branch']) ? $data['branch'] : '',
                    'service_provider_email' => isset($data['email']) ? $data['email'] : '',
                    'service_provider_telephone' => isset($data['telephone']) ? $data['telephone'] : '',
                ];
                $exists = $this->databaseClient->doesSupporterExist($table, 'service_provider_id', $data['id']);
                if ($exists) {
                    db_update($table, array())->fields($entry)->condition('service_provider_id', $exists)->execute();
                } else {
                    db_insert($table, array())->fields($entry)->execute();
                }
            } catch (PDOException $exception) {
                $this->errors[] = ' Datenbank Fehler: ' . $exception->getMessage();
                return false;
            } catch (\Exception $exception) {
                $this->errors[] = 'Allgemeiner Fehler: ' . $exception->getMessage();
                return false;
            }
        }
        return true;
    }

}
