<?php

namespace includes\classes\nodes;

use includes\classes\Text;
use includes\classes\Config;

/**
 * Displays node content
 */
class NodeMemberDataSettings
{
    private $config_class;
    private $config;
    private $text;

    /**
     * Constructor function.
     * Gets configurations from Config class and text.
     *
     */
    public function __construct()
    {
        $this->config_class     = new Config;
        $this->config           = $this->config_class->getAll();
        $this->text             = new Text;
    }


    /**
     * Displays the form for settings data
     */
    public function formMemberDataSettings(){

        $form_id            = 'qmembers-form-member-data-settings';
        $qmembers_text      = $this->text;
        $qmembers_config    = $this->config;

        require QMEMBERS_PATH_FORMS . 'formMemberDataSettings.php';
    }


    /**
     * Displays the navigation tabs on top of the member data node
     */
    public function memberDataNaviTabs(){

        $element_id         = 'qmembers-member-data-navi-tabs';
        $tab_id             = 'qmembers-form-member-data-settings';
        $qmembers_text      = $this->text;
        $qmembers_config    = $this->config;

        require QMEMBERS_PATH_MEMBER_DATA . 'memberDataNaviTabs.php';
    }
}