<?php

namespace includes\classes\nodes;

use includes\classes\Text;
use includes\classes\Config;
use includes\classes\User;

/**
 * Displays node content
 */
class NodeLogin
{
    /**
     * Displays the login form
     */
    public function formLogin(){

        $form_id                = 'qmembers-form-login';
        $qmembers_text          = new Text;
        $config_class           = new Config;
        $qmembers_config        = $config_class->getAll();

        // Redirect user if session already exists
        $user = new User;
        if ($user->isLoggedIn()){
            header('location:' . $qmembers_config['redirect-url-after-login']);
            exit;
        }

        require QMEMBERS_PATH_FORMS . 'formLogin.php';
    }
}