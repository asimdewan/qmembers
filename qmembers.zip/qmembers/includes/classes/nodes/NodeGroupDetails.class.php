<?php

namespace includes\classes\nodes;

use includes\classes\Text;
use includes\classes\Config;
use includes\classes\User;

/**
 * Displays node content
 */
class NodeGroupDetails
{
    private $config_class;
    private $config;
    private $text;

    private $node;


    /**
     * Constructor function.
     * Gets configurations from Config class and text.
     *
     */
    public function __construct()
    {
        $this->config_class     = new Config;
        $this->config           = $this->config_class->getAll();
        $this->text             = new Text;
        //$this->user             = new User;

        $this->node             = $this->setNode();
    }


    /**
     * Set $this->node
     */
    public function setNode()
    {
        $result = $this->getGroupDetailsNodeId();
        if($result['error']){
            return '';
        }

        $group_details_node_id = $result['value'];

        $result = $this->getGroupDetailsData($group_details_node_id);
        if($result['error']){
            return '';
        }

        $node = $result['value'];

        return $node;
    }


    /**
     * Displays the group title of a specific group
     */
    public function displayGroupTitle()
    {
        if(!$this->node){
            echo $this->text->get('group-details--no-title');
            return;
        }

        $title      = $this->node->title;

        echo $title;
    }

    /**
     * Displays the group details of a specific group
     */
    public function displayGroupDetails()
    {
        if(!$this->node) {
            echo $this->text->get('group-details--could-not-retrieve-group-details');
            return;
        }

        $result = $this->getGroupDetailsNodeId();
        if($result['error']){
            echo $this->text->get('group-details--could-not-retrieve-group-details');
            return;
        }

        $group_details_node_id = $result['value'];

        $nid = $group_details_node_id;
        print drupal_render(node_view(node_load($nid)));

        /*
       $img_filename               = $this->node->field_image['und'][0]['filename'];
       $img_uri                    = file_build_uri($img_filename);
       $img_url                    = file_create_url($img_uri);
       $body                       = $this->node->body[LANGUAGE_NONE][0]['safe_value'];

       // Get different field names of group content types from config settings
       $field_names_description = explode(',', $this->config['drupal-field-names-for-contact-person-description-of-groups']);
       $field_names_person      = explode(',', $this->config['drupal-field-names-for-contact-person-details-of-groups']);

       $field_name_description  = $this->getCorrectFieldNamesOfContentType($field_names_description);
       $field_name_person       = $this->getCorrectFieldNamesOfContentType($field_names_person);

       // Get contact person data
       $contact_descriptions = '';
       $contact_people       = '';
       if ($field_name_description && $field_name_person){

           $contact_descriptions       = $this->node->{$field_name_description}['und'];
           $contact_people_data        = $this->node->{$field_name_person}['und'];

           $result = $this->getContactInfos($contact_people_data);
           if ($result['error']){
               $contact_people = '';
           } else{
               $contact_people = $result['value'];
           }
       }

       require QMEMBERS_PATH_GROUP_DETAILS  . 'group-details-content.php';

       /*
       echo '<pre>';
       print_r($contact_people);
       echo '</pre>';
       */
    }

    /**
     * Returns the existing field name
     *
     * @return string       The field name;
     */
    public function getCorrectFieldNamesOfContentType($field_name_options)
    {
        foreach ( $field_name_options as $the_field_name){

            $the_field_name = trim($the_field_name);

            if ( isset($this->node->{$the_field_name}) ) {
                return $the_field_name;
            }
        }

        return '';
    }


    /**
     * Returns contact infos of group
     *
     * @return array             Contains all contact infos.
     */
    /*
    private function getContactInfos($contact_people_data)
    {
       $result['error']      = false;
       $contact_people_nodes = array();

       foreach ($contact_people_data as $key => $person_data) {

           $person_node_id  = $person_data['nid'];
           $node            = '';

           // Start query
           $query = new \EntityFieldQuery();
           $entities = $query->entityCondition('entity_type', 'node')
               //->propertyCondition('type', $content_types)
               ->propertyCondition('status', 1)
               ->propertyCondition('nid', $person_node_id)
               ->range(0, 1)
               ->execute();

           if (!empty($entities['node'])) {
               $node = node_load(array_shift(array_keys($entities['node'])));
           }

           $contact_people_nodes[$key] = $node;
       }

        if (!$contact_people_nodes){
            $result['error'] = true;
            return $result;
        }

        $result['value'] = $contact_people_nodes;
        return $result;
    }
    */

    /**
     * Returns group details node id according to GET parameter.
     *
     * @return integer             Node id of group.
     */
    private function getGroupDetailsNodeId()
    {
        $result['error'] = false;

        if ( !isset( $_GET[$this->config['group-details-parameter-name-group-id']] ) ){
            $result['error'] = true;
            $result['value'] = $this->text->get('group-details--no-group-id-passed-therefore-no-group-details');
            return $result;
        }

        $group_details_node_id = $_GET[$this->config['group-details-parameter-name-group-id']];
        $group_details_node_id = $this->sanitizeParameterContent($group_details_node_id);

        // Parameter content not valid
        if (!$group_details_node_id){
            $result['error'] = true;
            $result['value'] = $this->text->get('group-details--no-group-id-passed-therefore-no-group-details');
            return $result;
        }

        $result['value'] = $group_details_node_id;

        return $result;
    }

        /**
     * Returns group details data.
     *
     * @param array     $content_types          Content types to get data from
     * @param int       $max_results            Max. number of results.
     *
     * @return array                            Group data.
     *
     */
    private function getGroupDetailsData($group_details_node_id){

        $node           = array();
        $result['error'] = false;

        // group content types
        $content_types = explode(',', $this->config['group_content_types']);

        // Start query
        $query = new \EntityFieldQuery();
        $entities = $query->entityCondition('entity_type', 'node')
            ->propertyCondition('type', $content_types)
            ->propertyCondition('status', 1)
            ->propertyCondition('nid', $group_details_node_id)
            ->range(0, 1)
            ->execute();

        if (!empty($entities['node'])) {
            $node = node_load(array_shift(array_keys($entities['node'])));
        }

        $result['value'] = $node;

        return $result;
    }

    /**
     * Sanitize parameter content
     */
    public function sanitizeParameterContent($parameter_content){

        $parameter_content = filter_var ( $parameter_content, FILTER_SANITIZE_STRING);

        if ( !filter_var($parameter_content, FILTER_VALIDATE_INT) )
            $parameter_content = '';

        if ( strlen($parameter_content) > 10 )
            $parameter_content = '';

        return $parameter_content;
    }
}