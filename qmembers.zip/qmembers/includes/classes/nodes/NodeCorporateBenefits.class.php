<?php

namespace includes\classes\nodes;

use includes\classes\Text;
use includes\classes\Config;
use includes\classes\User;

/**
 * Displays node content
 */
class NodeCorporateBenefits
{
    private $config_class;
    private $config;
    private $text;
    private $subscribed_groups;
    private $results_number;

    /**
     * Constructor function.
     * Gets configurations from Config class and text.
     *
     */
    public function __construct()
    {
        $this->config_class     = new Config;
        $this->config           = $this->config_class->getAll();
        $this->text             = new Text;
    }

    /**
     * Displays the normal node content
     */
    public function displayNodeContent(){

        $result = $this->getNodeData();
        if ($result['error']){
            echo $result['value'];
            return;
        }

        $node = $result['value'];
        $body = $node->body[LANGUAGE_NONE][0]['value'];

        // Get member link to corporate benefits portal
        $result = $this->getMemberLinkURL();
        if ($result['error']){
            $member_link_url = '#';
            $member_link = $this->text->get('node-corporate-benefits--member-link-could-not-be-generated');
        }
        else{
            $member_link_url = $result['value'];
            $member_link     = '<a href="' . $member_link_url . '" id="qmembers-corporate-benefits-button" target="_blank">' . $this->text->get('node-corporate-benefits--button-to-corporate-benefits-text') . '</a>';
        }

        $body = str_replace('___LINK_URL___',$member_link_url, $body);
        $body = str_replace('___LINK___',    $member_link,     $body);

        echo $body;
        return;
    }

    /**
     * Returns the node data.
     *
     * @return array            Node data.
     */
    private function getNodeData(){

        $environment = $this->config['environment'];
        $node_id     = $this->config['page']['corporate-benefits']['id_source'][$environment];

        // Start query
        $query = new \EntityFieldQuery();
        $entities = $query->entityCondition('entity_type', 'node')
            ->propertyCondition('status', 1)
            ->propertyCondition('nid', $node_id)
            ->range(0, 1)
            ->execute();

        if (!empty($entities['node'])) {
            $node               = node_load(array_shift(array_keys($entities['node'])));
            $result['value']    = $node;
            return $result;
        }

        $result['error'] = true;
        $result['value'] = $this->text->get('node-content-not-found');
        return $result;
    }

    /**
     * Returns the link to the corporate benefits portal for the current member
     *
     * @return array            Node data.
     */
    private function getMemberLinkURL(){

        // Der Hash wird gebildet aus der „uid“, dem individuellen Token Ihrer Vorteilsplattform,
        // Ft54R%d-120f und einem Zeitstempel, alles zusammen per md5 verschlüsselt.
        // Example: https://bdp.rahmenvereinbarungen.de/login/auto/uid/123456/hash/37f19dc5fa0fd....

        $user       = new User;
        $member_id  = $user->getMemberId();

        if(!$member_id){
            $result['error'] = true;
            return $result;
        }

        $uid        = $member_id;   /* User-ID */
        $token      = $this->config['corporate-benefits-token'];     /* Token */
        $hash       = md5( $uid . date('Ymd') . $token );
        $link_url   = $this->config['corporate-benefits-base-url'] . 'login/auto/uid/' . $uid . '/hash/' . $hash;

        $result['value'] = $link_url;
        return $result;
    }



}