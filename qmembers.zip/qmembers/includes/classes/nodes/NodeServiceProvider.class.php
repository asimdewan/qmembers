<?php

namespace includes\classes\nodes;

use includes\classes\Text;
use includes\classes\Config;
use includes\classes\ApiHandler;

/**
 * Displays node content
 */
class NodeServiceProvider
{
    private $config_class;
    private $config;
    private $text;

    public $countResults = 0;
    public $searchResults;

    /**
     * Constructor function.
     * Gets configurations from Config class and text.
     *
     */
    public function __construct()
    {
        $this->config_class     = new Config;
        $this->config           = $this->config_class->getAll();
        $this->text             = new Text;
        $this->apiHandler       = new ApiHandler($this->config);
    }


    /**
     * Displays the search field for service provider
     */
    public function serviceProviderSearch($search = '', $filter1 = '', $filter2 = '', $search_page = ''){

        $form_id            = 'qmembers-service-provider';
        $qmembers_text      = $this->text;
        $qmembers_config    = $this->config;
        $search             = $this->sanitizeSearch($search);
        $filter1            = $this->sanitizeFilter1($filter1);
        $filter2            = $this->sanitizeFilter2($filter2);
        $search_page        = $this->sanitizeSearchPage($search_page);

        $search_result = $this->getServiceProviderSearchResults($search, $filter1, $filter2, $search_page);
        if ($search_result['error']){
            //echo $search_result['value'];
            //return;
            $this->searchResults = '';
            $this->countResults  = 0;
        }
        else{
            $this->searchResults = $search_result;
            $this->countResults  = $search_result['value']['amount'];
        }



        if ($this->countResults == 1) $count_text = $this->text->get('service-provider-count-text-singular');
        else                          $count_text = $this->text->get('service-provider-count-text-plural');

        $count = $this->countResults;
        require QMEMBERS_PATH_FORMS . 'formServiceProviderSearch.php';
    }

    /**
     * Displays the search filters for service provider
     */
    public function serviceProviderSearchFilter($filter1, $filter2){

        $form_id            = 'qmembers-service-provider-search-filter';
        $qmembers_text      = $this->text;
        $qmembers_config    = $this->config;
        $filter1            = $this->sanitizeFilter1($filter1);
        $filter2            = $this->sanitizeFilter2($filter2);

        require QMEMBERS_PATH_FORMS . 'formServiceProviderSearchFilter.php';
    }

    /**
     * Displays the service provider search results
    */
    public function displayServiceProviderSearchResults($search, $filter1, $filter2, $search_page){

        $qmembers_text      = $this->text;
        $qmembers_config    = $this->config;

        $search             = $this->sanitizeSearch($search);
        $filter1            = $this->sanitizeFilter1($filter1);
        $filter2            = $this->sanitizeFilter2($filter2);
        $search_page        = $this->sanitizeSearchPage($search_page);

        $search_result = $this->searchResults;

        // Output results
        if ($filter2){
            echo '<div id="qmembers-service-provider-search-results-filter-head">';
                echo $filter2;
            echo '</div>';
        }

        echo '<div class="qmembers-service-provider-search-results">';

                if ( !$search_result['value']['list'] ){
                    // No results
                    echo $qmembers_text->get('service-provider-no-results');
                }
                else{
                    foreach ($search_result['value']['list'] as $value) {

                        require QMEMBERS_PATH_SERVICE_PROVIDER . 'serviceProviderSearchResults.php';
                    }
                }

        echo '</div>';

        echo '<div id="qmembers-service-provider-count-hidden" data-count="' . $search_result['value']['amount'] . '"></div>';

        // Pagination
        //$search_parameter = $search;
        $search_page = ($search_page === "")?1:intval($search_page);
        if ($this->config['max_results_service_providers'] < $search_result['value']['amount']) {

            $last_page = (floor($search_result['value']['amount'] / $this->config['max_results_service_providers'])) + 1;
            echo '<br/><div class="qmembers-form-pagination">';

            //$search_url = ($this->config['url-service-provider']).(($search_parameter != "")?('?'.($this->config['list-search-parameter-name']).'='.($search_parameter).'&'):'?');

            $pagination_url_parameter  = '';
            $pagination_url_parameter .= $this->config['list-search-parameter-name'] . '=' . $search;
            $pagination_url_parameter .= '&' . $this->config['service-provider-parameter-name-filter1'] . '=' . $filter1;
            $pagination_url_parameter .= '&' . $this->config['service-provider-parameter-name-filter2'] . '=' . $filter2;

            $search_url = QMEMBERS_CURRENT_URL_WITHOUT_PARAMS . '?' . $pagination_url_parameter . '&';


            // Previous and first page
            if ($search_page != 1) {
                echo '<a href="'.($search_url).($this->config['list-search-page-name']).'='.($search_page - 1).'" class="qmembers-pagination-arrow"> &lt; </a> ';
                echo '<a href="'.($search_url).($this->config['list-search-page-name']).'=1"> 1 </a> ';
            }

            // Previous two pages
            if ($search_page > 4) {
                echo '<span class="qmembers-pagination-dots"> ... </span>';
            }
            if ($search_page > 3) {
                echo ' <a href="'.($search_url).($this->config['list-search-page-name']).'='.($search_page - 2).'"> '.($search_page - 2).' </a> ';
            }
            if ($search_page > 2) {
                echo ' <a href="'.($search_url).($this->config['list-search-page-name']).'='.($search_page - 1).'"> '.($search_page - 1).' </a> ';
            }

            // Current page
            echo ' <a class="qmembers-pagination-current-page"> '.$search_page.' </a> ';

            // Next two pages
            if ($search_page < ($last_page - 1)) {
                echo ' <a href="'.($search_url).($this->config['list-search-page-name']).'='.($search_page + 1).'"> '.($search_page + 1).' </a> ';
            }
            if ($search_page < ($last_page - 2)) {
                echo ' <a href="'.($search_url).($this->config['list-search-page-name']).'='.($search_page + 2).'"> '.($search_page + 2).' </a> ';
            }
            if ($search_page < ($last_page - 3)) {
                echo '<span class="qmembers-pagination-dots"> ... </span>';
            }

            // Next and last page
            if ($search_page != $last_page) {
                echo ' <a href="'.($search_url).($this->config['list-search-page-name']).'='.$last_page.'"> '.$last_page.' </a>';
                echo ' <a href="'.($search_url).($this->config['list-search-page-name']).'='.($search_page + 1).'" class="qmembers-pagination-arrow"> &gt; </a>';
            }

            echo '</div>';

        }
    }

    /**
     * Get the service provider search results data
     */
    public function getServiceProviderSearchResults($search = '', $filter1 = '', $filter2 = '', $search_page = ''){

        // Get the full list of service providers
        $result = $this->getServiceProviderList();
        if ( isset($result['error']) ) return $result;

        $service_providers = $result['value'];
        $list_result       = [];

        if  ( !$search && !$filter1 && !$filter2) {
            // Save all
            $list_result = $service_providers;
        }
        else{
            foreach ($service_providers as $value) {

                $add_value = '';

                // Search fields
                if ($search){

                    if ( stripos( $value['service_provider_company'], $search ) !== false){

                        $add_value = $value;
                    }
                    else continue;

                }

                if ($filter1){

                    if ( stripos( $value['service_provider_city'], $filter1 ) !== false){

                        $add_value = $value;
                    }
                    elseif ( stripos( $value['service_provider_zip'], $filter1 ) !== false){

                        $add_value = $value;
                    }
                    else continue;

                }

                if ($filter2){

                    $first_character = mb_substr( $value['service_provider_company'], 0, 1, 'utf-8');

                    if ( $first_character == $filter2 ){

                        $add_value = $value;
                    }
                    else continue;
                }

                if($add_value){
                    $list_result[] = $add_value;
                }

            }
        }

        // filter out all results with no address
        foreach ($list_result as $key => $value){

            if (!$value['service_provider_city'] || !$value['service_provider_zip'] || !$value['service_provider_street'] || !$value['service_provider_company']){

                unset($list_result[$key]);
            }

        }

        // Needed for pagination
        $count = count($list_result);

        // Page slice the results
        $max_results = ($count > $this->config['max_results_service_providers'])?$this->config['max_results_service_providers']:$count;
        $search_page = ($search_page === "")?0:(intval($search_page) - 1);
        $initial_value = $search_page * $this->config['max_results_service_providers'];

        // Return search result list
        $result['value']['list']   = array_slice($list_result, $initial_value, $max_results);
        $result['value']['amount'] = $count;
        return $result;
    }

    /**
     * Get the full list of service providers
     */
    public function getServiceProviderList(){

        // Get the full list of service providers
        $service_providers = array();

        if ( !isset( $_SESSION[ $this->config['session']['name']]['service_providers']) ) {

            $service_providers = $this->apiHandler->getServiceProviders();

            if (empty($service_providers)) {
                $result['error']    = true;
                $result['value']    = $this->text->get('error-service-provider-list-not-available');
                return $result;
            }

            $_SESSION[ $this->config['session']['name']]['service_providers'] = $service_providers;
        }

        $service_providers = $_SESSION[ $this->config['session']['name']]['service_providers'];

        if (empty($service_providers)) {
            $result['error']    = true;
            $result['value']    = $this->text->get('error-service-provider-list-not-available');
            return $result;
        }

        $result['value'] = $service_providers;
        return $result;
    }

    /**
     * Sanitize filter1
     */
    public function sanitizeFilter1($filter1){

        $filter1 = filter_var($filter1,FILTER_SANITIZE_STRING);
        if ( strlen($filter1) > 100 ) $filter1 = substr($filter1, 0, 100);

        return $filter1;
    }

    /**
     * Sanitize filter2
     */
    public function sanitizeFilter2($filter2){

        $filter2 = filter_var($filter2,FILTER_SANITIZE_STRING);

        $expected_values   = range('A', 'Z');
        $expected_values[] = '0-9';
        if ( !in_array($filter2,$expected_values) ) $filter2 = '';

        return $filter2;
    }

    /**
     * Sanitize search
     */
    public function sanitizeSearch($search){

        $search = filter_var ( $search, FILTER_SANITIZE_STRING);
        if ( strlen($search) > 100 ) $search = substr($search, 0, 100);

        return $search;
    }

    /**
     * Sanitize search_page
     */
    public function sanitizeSearchPage($search_page){

        $search_page = filter_var($search_page,  FILTER_SANITIZE_NUMBER_INT);
        return $search_page;
    }

}