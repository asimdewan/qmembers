<?php

namespace includes\classes\nodes;

use includes\classes\Text;
use includes\classes\Config;
use includes\classes\User;

/**
 * Displays node content
 */
class NodeGroups
{
    private $config_class;
    private $config;
    private $text;
    private $results_number;

    public $subscribed_groups; // needed by other class (NodeRestrictedUploads)

    /**
     * Constructor function.
     * Gets configurations from Config class and text.
     *
     */
    public function __construct()
    {
        $this->config_class     = new Config;
        $this->config           = $this->config_class->getAll();
        $this->text             = new Text;
        //$this->user             = new User;
        $this->getSubscribedGroups();
        
    }

    /**
     * Displays the groups.
     *
     * @param string $group_filter          The selected group filter.
     *
     */
    public function displayGroups($group_filter = '', $search_page = ''){

        $accepted_group_filters_string = $this->config['group_content_types'] . ',subscribed';

        $accepted_group_filters = explode(',', $accepted_group_filters_string);
        $max_results            = $this->config['max_results_groups'];
        $summary_length         = $this->config['summary_length_groups'];

        if (!$group_filter){

            $content_types = explode(',', $this->config['group_content_types']);
            $result = self::getGroupData($content_types, $max_results, $search_page);
            if($result['error']) return $result;
        }
        else{

            // Group filter not valid
            if (!in_array($group_filter,$accepted_group_filters)){
                $result['error'] = true;
                $result['value'] = $this->text->get['group-filter-not-valid'];
                return $result;
            }

            // Get subscribed group data
            if ($group_filter == 'subscribed'){

                $result = self::getSubscribedGroupData($max_results, $search_page);
                if($result['error']) return $result;
            }
            // Get group data according to filter
            else{
                $content_types = array($group_filter);
                $result = self::getGroupData($content_types, $max_results, $search_page);
                if($result['error']) return $result;
            }
        }

        $nodes = $result['value'];


        $i = 0;
        // Output results
        foreach ($nodes as $node){

            // Here you can check all node data
            /*
              echo "<pre>";
              print_r($node);
              echo "</pre>";
            */

            $form_id            = 'qmembers-form-groups';
            $summary_index      = $i;
            
            $node_id            = $node->nid;
            $title              = $node->title;
            $body               = $node->body[LANGUAGE_NONE][0]['value'];
            $summary            = strip_tags(self::getTeaserText($body, $summary_length));

            $img_filename       = $node->field_image['und'][0]['filename'];
            $img_uri            = $node->field_image['und'][0]['uri'];
            //$contact_img_url            = image_style_url($this->config['image-style-for-group-contact-person-image'], $contact_img_uri );
            //$img_uri            = file_build_uri($img_filename);
            //$img_url            = file_create_url($img_uri);

            $img_url            = image_style_url('qmembers_group_list', $img_uri );

            $home_url           = substr(QMEMBERS_HOME_URL, 0, -1);
            //$node_url           =  $home_url . url("node/$node_id");
            $node_url           = $this->config['url-group-details'] . '?' . $this->config['group-details-parameter-name-group-id'] . '=' . $node_id;

            $read_more          = $this->text->get('read-more');

            // Group ID
            if (isset ($node->field_group_id_for_qmembers['und'][0]['value']))      $group_id  = trim($node->field_group_id_for_qmembers['und'][0]['value']);
            elseif (isset ($node->field_group2_id_for_qmembers['und'][0]['value'])) $group_id  = trim($node->field_group2_id_for_qmembers['und'][0]['value']);
            elseif (isset ($node->field_group3_id_for_qmembers['und'][0]['value'])) $group_id  = trim($node->field_group3_id_for_qmembers['und'][0]['value']);
            elseif (isset ($node->field_group4_id_for_qmembers['und'][0]['value'])) $group_id  = trim($node->field_group4_id_for_qmembers['und'][0]['value']);
            elseif (isset ($node->field_group5_id_for_qmembers['und'][0]['value'])) $group_id  = trim($node->field_group5_id_for_qmembers['und'][0]['value']);
            else                                                                    $group_id  = '';

            $belongs_user       = in_array($group_id, $this->subscribed_groups);

            require QMEMBERS_PATH_TEMPLATE_PARTS_GROUPS . 'groupSummary.php';
            $i = $i + 1;
        }

        // PAGINATION
        $search_page = ($search_page === "")?1:intval($search_page);
        if ($this->config['max_results_groups'] < $this->results_number) {
            
            $last_page = (floor($this->results_number / $this->config['max_results_groups'])) + 1;
            echo '<br/><div class="qmembers-form-pagination">';
                
                $search_url = ($this->config['url-member-data-groups']).(($group_filter != "")?('?'.($this->config['groups-filter-parameter-name']).'='.($group_filter).'&'):'?');
    
                // Previous and first page
                if ($search_page != 1) {
                    echo '<a href="'.($search_url).($this->config['list-search-page-name']).'='.($search_page - 1).'" class="qmembers-pagination-arrow"> &lt; </a> ';
                    echo '<a href="'.($search_url).($this->config['list-search-page-name']).'=1"> 1 </a> ';
                }

                // Previous two pages
                if ($search_page > 4) {
                    echo '<span class="qmembers-pagination-dots"> ... </span>';
                }
                if ($search_page > 3) {
                    echo ' <a href="'.($search_url).($this->config['list-search-page-name']).'='.($search_page - 2).'"> '.($search_page - 2).' </a> ';
                }
                if ($search_page > 2) {
                    echo ' <a href="'.($search_url).($this->config['list-search-page-name']).'='.($search_page - 1).'"> '.($search_page - 1).' </a> ';
                }

                // Current page
                echo ' <a class="qmembers-pagination-current-page"> '.$search_page.' </a> ';

                // Next two pages
                if ($search_page < ($last_page - 1)) {
                    echo ' <a href="'.($search_url).($this->config['list-search-page-name']).'='.($search_page + 1).'"> '.($search_page + 1).' </a> ';
                }
                if ($search_page < ($last_page - 2)) {
                    echo ' <a href="'.($search_url).($this->config['list-search-page-name']).'='.($search_page + 2).'"> '.($search_page + 2).' </a> ';
                }
                if ($search_page < ($last_page - 3)) {
                    echo '<span class="qmembers-pagination-dots"> ... </span>';
                }

                // Next and last page
                if ($search_page != $last_page) {
                    echo ' <a href="'.($search_url).($this->config['list-search-page-name']).'='.$last_page.'"> '.$last_page.' </a>';
                    echo ' <a href="'.($search_url).($this->config['list-search-page-name']).'='.($search_page + 1).'" class="qmembers-pagination-arrow"> &gt; </a>';
                }
            
            echo '</div>';
        }

    }


    /**
     * Returns the list of subscribed groups.
     *
     * @return array                            Group list.
     *
     */
    private function getSubscribedGroups(){

        //  GET SUBSCRIBED GROUPS HERE FROM USER CLASS (NOT DIRECTLY FROM THE SESSION)
        //  A method needs to be added in the user class.
        //  Data format = comma separated string, like 'energie,freizeit_tourismus,berlin_brandenburg'

        /* When the function exists in the User class:
           if ($result['error']) return $result;
        */

        // Dummy result ------------------------------------------------------
        //$result['value']   = 'energie,freizeit_tourismus,berlin_brandenburg';
        // -------------------------------------------------------------------

        $this->subscribed_groups = array();

        $user = new User;
        $groups = $user->getSubscribedGroups();
        
        if ($groups['error']) {
// ERROR HANDLING
            //$result['value'] = $groups['value'];
        } else if ($groups['value'] === false) {
// ERROR HANDLING
            //$result['value'] = $this->text->get('form-password-change-submit-not-saved');
        } else {
            $this->subscribed_groups = explode(',', $groups['value']);
        }
    }


    /**
     * Get the number of results.
     *
     * @param string $group_filter          The selected group filter.
     *
     */
    public function getResultsNumber($group_filter = ''){

        $accepted_group_filters_string = $this->config['group_content_types'] . ',subscribed';

        $accepted_group_filters = explode(',', $accepted_group_filters_string);
        $max_results            = $this->config['max_results_groups'];

        if (!$group_filter){

            $content_types = explode(',', $this->config['group_content_types']);
            $result = self::getGroupData($content_types, 10000);
            if($result['error']) return $result;
        }
        else{

            // Group filter not valid
            if (!in_array($group_filter,$accepted_group_filters)){
                $result['error'] = true;
                $result['value'] = $this->text->get['group-filter-not-valid'];
                return $result;
            }

            // Get subscribed group data
            if ($group_filter == 'subscribed'){

                $result = self::getSubscribedGroupData(10000);
                if($result['error']) return $result;
            }
            // Get group data according to filter
            else{
                $content_types = array($group_filter);
                $result = self::getGroupData($content_types, 10000);
                if($result['error']) return $result;
            }
        }

        $nodes = $result['value'];

        $this->results_number = count($nodes);
        return $this->results_number;

    }



    /**
     * Returns group data.
     *
     * @param array     $content_types          Content types to get data from
     * @param int       $max_results            Max. number of results.
     *
     * @return array                            Group data.
     *
     */
    private function getGroupData($content_types, $max_results, $search_page = ""){

        $nodes           = array();
        $result['error'] = false;

        $search_page = ($search_page === "")?0:(intval($search_page) - 1);
        $init_value = ($search_page * $max_results);

        // Start query
        $query = new \EntityFieldQuery();
        $entities = $query->entityCondition('entity_type', 'node')
            ->propertyCondition('type', $content_types)
            ->propertyCondition('status', 1)
            ->propertyOrderBy('title','ASC')
            ->range($init_value, $max_results)
            ->execute();

        if (!empty($entities['node'])) {
            $node_ids = array_keys($entities['node']);
            $nodes = entity_load('node', $node_ids);
        }

        $result['value'] = $nodes;

        return $result;
    }

    /**
     * Returns group data of subscribed groups.
     *
     * @param int       $max_results            Max. number of results.
     *
     * @return array                            Group data.
     *
     */
    private function getSubscribedGroupData($max_results, $search_page = ""){

        $nodes           = array();
        $result['error'] = false;

        $search_page = ($search_page === "")?0:(intval($search_page) - 1);
        $init_value = ($search_page * $max_results);

        $content_types = explode(',', $this->config['group_content_types']);

        // Start query
        $query = new \EntityFieldQuery();
        $entities = $query->entityCondition('entity_type', 'node')
            ->propertyCondition('type', $content_types)
            ->propertyCondition('status', 1)
            ->propertyOrderBy('title','ASC')
            ->range(0, 10000)
            ->execute();

        if (!empty($entities['node'])) {
            $node_ids = array_keys($entities['node']);
            $nodes = entity_load('node', $node_ids);
        }

        // Filter out subscribed groups
        $subscribed_groups_data = array();

        $i = 0;
        foreach ($nodes as $key => $node){

            // Group ID
            if (isset ($node->field_group_id_for_qmembers['und'][0]['value']))      $group_id  = trim($node->field_group_id_for_qmembers['und'][0]['value']);
            elseif (isset ($node->field_group2_id_for_qmembers['und'][0]['value'])) $group_id  = trim($node->field_group2_id_for_qmembers['und'][0]['value']);
            elseif (isset ($node->field_group3_id_for_qmembers['und'][0]['value'])) $group_id  = trim($node->field_group3_id_for_qmembers['und'][0]['value']);
            elseif (isset ($node->field_group4_id_for_qmembers['und'][0]['value'])) $group_id  = trim($node->field_group4_id_for_qmembers['und'][0]['value']);
            elseif (isset ($node->field_group5_id_for_qmembers['und'][0]['value'])) $group_id  = trim($node->field_group5_id_for_qmembers['und'][0]['value']);
            else                                                                    $group_id  = '';

            if ((in_array($group_id,$this->subscribed_groups)) && ($i >= $init_value)){

                $subscribed_groups_data[] = $node;
            }

            $i = $i + 1;
            // Stop if max. number of results have been collected
            if (count($subscribed_groups_data) >= $max_results) break;
        }

        $result['value'] = $subscribed_groups_data;
        return $result;
    }

    /**
     * Returns a teaser version of the submitted text
     *
     * @param string $text          Input text.
     * @param int $length           Desired result length.
     * @return string               Shortened text that doesn't break words.
     *
     */
    private function getTeaserText( $text, $length = 200)
    {
        if( strlen($text) <= $length )
            return $text;

        $parts = explode(" ", $text);

        while( strlen( implode(" ", $parts) ) > $length )
            array_pop($parts);

       return implode(" ", $parts) . '...';
    }

    /**
     * Displays the groups Results Number on top of the groups node
     */
    public function showResultsNumber($group_filter, $results_number){

        $element_id         = 'qmembers-groups-results';
        $qmembers_text      = $this->text;
        $qmembers_config    = $this->config;

        $working_group_names[]  = "fachgruppen";
        $working_group_names[]  = "fachgruppe";
        $working_group_names[]  = "working_groups";

        $regional_group_names[] = "landesgruppen";
        $regional_group_names[] = "landesgruppe";
        $regional_group_names[] = "regionalgruppen";
        $regional_group_names[] = "regionalgruppe";
        $regional_group_names[] = "regional_groups";


        if ($group_filter === "") $text_label = $qmembers_text->get('navigation-groups-all');
        elseif ( in_array($group_filter, $working_group_names ) )  $text_label = $qmembers_text->get('navigation-groups-professional');
        elseif ( in_array($group_filter, $regional_group_names ) ) $text_label = $qmembers_text->get('navigation-groups-national');
        elseif ($group_filter === "subscribed")                    $text_label = $qmembers_text->get('navigation-groups-personal');
        else $text_label = $qmembers_text->get('group-filter-not-valid');

// CHECK IF THIS IS THE WAY TO DO IT OR JUST SHOW THE LINE
//        require QMEMBERS_PATH_TEMPLATE_PARTS_GROUPS . 'groupsResultsNumber.php';
        echo $text_label.' ('.$results_number.')';

    }

    /**
     * Displays the navigation tabs on top of the groups node
     */
    public function groupsNaviTabs($group_filter){

        $element_id             = 'qmembers-groups-navi-tabs';
        $tab_id                 = $group_filter;
        $qmembers_text          = $this->text;
        $qmembers_config        = $this->config;

        $filter_work_groups     = $qmembers_config['group_content_type_work_groups'];
        $filter_regional_groups = $qmembers_config['group_content_type_regional_groups'];

        $regional_groups_exist = true;

        if (!$qmembers_config['group_content_type_regional_groups'])
            $regional_groups_exist = false;

        require QMEMBERS_PATH_TEMPLATE_PARTS_GROUPS . 'groupsNaviTabs.php';
    }

}