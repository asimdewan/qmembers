<?php

namespace includes\classes\nodes;

use includes\classes\Text;
use includes\classes\Config;

/**
 * Displays node content
 */
class NodeApp
{
    private $config_class;
    private $config;
    private $text;
    private $subscribed_groups;
    private $results_number;

    /**
     * Constructor function.
     * Gets configurations from Config class and text.
     *
     */
    public function __construct()
    {
        $this->config_class     = new Config;
        $this->config           = $this->config_class->getAll();
        $this->text             = new Text;
    }

    /**
     * Displays the normal node content
     */
    public function displayNodeContent(){

        $result = $this->getNodeData();
        if ($result['error']){
            echo $result['value'];
            return;
        }

        $node = $result['value'];
        $body = $node->body[LANGUAGE_NONE][0]['value'];

        echo $body;
        return;
    }

    /**
     * Returns the node data.
     *
     * @return array            Node data.
     */
    private function getNodeData(){

        $environment = $this->config['environment'];
        $node_id     = $this->config['page']['app']['id_source'][$environment];

        // Start query
        $query = new \EntityFieldQuery();
        $entities = $query->entityCondition('entity_type', 'node')
            ->propertyCondition('status', 1)
            ->propertyCondition('nid', $node_id)
            ->range(0, 1)
            ->execute();

        if (!empty($entities['node'])) {
            $node               = node_load(array_shift(array_keys($entities['node'])));
            $result['value']    = $node;
            return $result;
        }

        $result['error'] = true;
        $result['value'] = $this->text->get('node-content-not-found');
        return $result;
    }



}