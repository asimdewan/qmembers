<?php

namespace includes\classes\nodes;

use includes\classes\Text;
use includes\classes\Config;
use includes\classes\User;

/**
 * Displays node content
 */
class NodeMemberDataMemberlist
{
    private $config_class;
    private $config;
    private $text;

    /**
     * Constructor function.
     * Gets configurations from Config class and text.
     *
     */
    public function __construct()
    {
        $this->config_class     = new Config;
        $this->config           = $this->config_class->getAll();
        $this->text             = new Text;
        $this->user             = new User;
    }


    /**
     * Displays the memberlist search field
     */
    public function memberDataMemberlistSearch($search_parameter){

        $form_id            = 'qmembers-form-member-data-memberlist';
        $qmembers_text      = $this->text;
        $qmembers_config    = $this->config;
        $search_parameter   = $search_parameter;

        $session_name = $qmembers_config['session']['name'];

        $list = array();
        if (isset($_SESSION[$session_name]['memberlist'])) {
            $list = $_SESSION[$session_name]['memberlist'];
        }
        $members_memberlist = count($list);  // CHANGE THIS WITH THE NUMBER FROM THE SEARCH (js)

        if ($members_memberlist == 1) $members_count_text = $this->text->get('members_memberlist-singular');
        else                          $members_count_text = $this->text->get('members_memberlist');

        require QMEMBERS_PATH_FORMS . 'formMemberDataMemberlistSearch.php';
    }


    /**
     * Displays the memberlist result list
    */
    public function memberDataMemberlistResults($search_parameter = "", $search_page = ""){

        $qmembers_text      = $this->text;
        $qmembers_config    = $this->config;
        $qmembers_user      = $this->user;

        $search_result = $qmembers_user->searchMemberDataMemberlist($search_parameter, $search_page);
        
        if ($search_result['error']) {
            //$result['value'] = $search_result['value'];
            echo $search_result['value'];
        } else if ($search_result['value'] === false) {
            //$result['value'] = $this->text->get('form-member-data-memberlist-submit-not-saved');
            echo $this->text->get('form-member-data-memberlist-submit-not-saved');
        } else {
            echo '<div class="qmembers-form-list-results">';
            foreach ($search_result['value']['list'] as $value) {

                if ( !isset($value['personal_picture']) || !$value['personal_picture'] ){
                    $value['personal_picture'] = QMEMBERS_FILE_URL_PROFILE_PLACEHOLDER_IMAGE;
                }

                require QMEMBERS_PATH_FORMS . "formMemberDataMemberlistResult.php";
            }
            echo '</div>';

            echo '<div id="qmembers-form-memberlist-count-hidden" data-count="' . $search_result['value']['amount'] . '"></div>';


            // PAGINATION
            $search_page = ($search_page === "")?1:intval($search_page);
            if ($this->config['list-search-max-results'] < $search_result['value']['amount']) {

                $last_page = (floor($search_result['value']['amount'] / $this->config['list-search-max-results']));
                echo '<br/><div class="qmembers-form-pagination">';
                
                $search_url = ($this->config['url-member-data-memberlist']).(($search_parameter != "")?('?'.($this->config['list-search-parameter-name']).'='.($search_parameter).'&'):'?');
    
                // Previous and first page
                if ($search_page != 1) {
                    echo '<a href="'.($search_url).($this->config['list-search-page-name']).'='.($search_page - 1).'" class="qmembers-pagination-arrow"> &lt; </a> ';
                    echo '<a href="'.($search_url).($this->config['list-search-page-name']).'=1"> 1 </a> ';
                }

                // Previous two pages
                if ($search_page > 4) {
                    echo '<span class="qmembers-pagination-dots"> ... </span>';
                }
                if ($search_page > 3) {
                    echo ' <a href="'.($search_url).($this->config['list-search-page-name']).'='.($search_page - 2).'"> '.($search_page - 2).' </a> ';
                }
                if ($search_page > 2) {
                    echo ' <a href="'.($search_url).($this->config['list-search-page-name']).'='.($search_page - 1).'"> '.($search_page - 1).' </a> ';
                }

                // Current page
                echo ' <a class="qmembers-pagination-current-page"> '.$search_page.' </a> ';

                // Next two pages
                if ($search_page < ($last_page - 1)) {
                    echo ' <a href="'.($search_url).($this->config['list-search-page-name']).'='.($search_page + 1).'"> '.($search_page + 1).' </a> ';
                }
                if ($search_page < ($last_page - 2)) {
                    echo ' <a href="'.($search_url).($this->config['list-search-page-name']).'='.($search_page + 2).'"> '.($search_page + 2).' </a> ';
                }
                if ($search_page < ($last_page - 3)) {
                    echo '<span class="qmembers-pagination-dots"> ... </span>';
                }

                // Next and last page
                if ($search_page != $last_page) {
                    echo ' <a href="'.($search_url).($this->config['list-search-page-name']).'='.$last_page.'"> '.$last_page.' </a>';
                    echo ' <a href="'.($search_url).($this->config['list-search-page-name']).'='.($search_page + 1).'" class="qmembers-pagination-arrow"> &gt; </a>';
                }
                
                echo '</div>';
            }
        }
    }


}