<?php

namespace includes\classes\nodes;

use includes\classes\Text;
use includes\classes\Config;
use includes\classes\User;

/**
 * Displays node content
 */
class NodeMemberDataProfessional
{
    private $config_class;
    private $config;
    private $text;

    /**
     * Constructor function.
     * Gets configurations from Config class and text.
     *
     */
    public function __construct()
    {
        $this->config_class     = new Config;
        $this->config           = $this->config_class->getAll();
        $this->text             = new Text;
    }

    /**
     * Displays the correct view according to the view option parameter
     */
    public function displayMemberDataViewOption(){

        if ( isset($_GET[$this->config['view-option-parameter-name']]) ) $edit_parameter = $_GET[$this->config['view-option-parameter-name']];

        if ($edit_parameter == '1') self::formMemberDataProfessional();
        else                        self::memberDataProfessional();
   }


    /**
     * Displays the professional data
     */
    public function memberDataProfessional(){

        $qmembers_text      = $this->text;
        $qmembers_config    = $this->config;

        require QMEMBERS_PATH_MEMBER_DATA . 'memberDataProfessional.php';
    }

    
    /**
     * Displays the form for professional data
     */
    public function formMemberDataProfessional(){

        $form_id            = 'qmembers-form-member-data-professional';
        $qmembers_text      = $this->text;
        $qmembers_config    = $this->config;

        $user               = new User;
        $countries          = $user->getCountries();
        $businesses         = $user->getBranches();
        $states             = $user->getStates();

        require QMEMBERS_PATH_FORMS . 'formMemberDataProfessional.php';
    }

    /**
     * Displays the navigation tabs on top of the member data node
     */
    public function memberDataNaviTabs(){

        $element_id         = 'qmembers-member-data-navi-tabs';
        $tab_id             = 'qmembers-form-member-data-professional';
        $qmembers_text      = $this->text;
        $qmembers_config    = $this->config;

        require QMEMBERS_PATH_MEMBER_DATA . 'memberDataNaviTabs.php';
    }
}