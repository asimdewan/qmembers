<?php

namespace includes\classes\nodes;

use includes\classes\Text;
use includes\classes\Config;
use includes\classes\User;

/**
 * Displays node content
 */
class NodeMemberDataMembership
{
    private $config_class;
    private $config;
    private $text;

    /**
     * Constructor function.
     * Gets configurations from Config class and text.
     *
     */
    public function __construct()
    {
        $this->config_class     = new Config;
        $this->config           = $this->config_class->getAll();
        $this->text             = new Text;
    }

    /**
     * Displays the correct view according to the view option parameter
     */
    /*
    public function displayMemberDataViewOption(){

        if ( isset($_GET[$this->config['termination-parameter-name']]) ) $edit_parameter = $_GET[$this->config['termination-parameter-name']];

        if ($edit_parameter == '1') self::formMemberDataTermination();
        else                        self::formMemberDataMembership();
    }
    */

    /**
     * Displays the form for membership data
     */
    public function formMemberDataMembership(){

        $form_id_prim_email             = 'qmembers-form-member-data-membership-prim-email';
        $form_id_bill                   = 'qmembers-form-member-data-membership-bill';
        $form_id_press                  = 'qmembers-form-member-data-membership-press';
        $form_id_temination             = 'qmembers-form-member-data-termination';
        $qmembers_text                  = $this->text;
        $qmembers_config                = $this->config;
        $user                           = new User;
        $countries                      = $user->getCountries();
        $states                         = $user->getStates();
        $membership_level_display_name  = $user->getMembershipLevelDisplayName();
        $reasons                        = $user->getReasons();
        $membership_from                = $user->getMembershipFrom();

        require QMEMBERS_PATH_FORMS . 'formMemberDataMembership.php';
    }

    
    /**
     * Displays the form for termination
     */
    /*
    public function formMemberDataTermination(){

        $form_id            = 'qmembers-form-member-data-termination';
        $qmembers_text      = $this->text;
        $qmembers_config    = $this->config;

        require QMEMBERS_PATH_FORMS . 'formMemberDataTermination.php';
    }
    /*

    /**
     * Displays the navigation tabs on top of the member data node
     */
    public function memberDataNaviTabs(){

        $element_id         = 'qmembers-member-data-navi-tabs';
        $tab_id             = 'qmembers-form-member-data-membership';
        $qmembers_text      = $this->text;
        $qmembers_config    = $this->config;

        require QMEMBERS_PATH_MEMBER_DATA . 'memberDataNaviTabs.php';
    }
}