<?php

namespace includes\classes\nodes;

use includes\classes\Config;
use includes\classes\Text;


/**
 * Displays node content
 */
class NodePasswordRecover
{
    private $config_class;
    private $config;
    private $text;

    /**
     * Constructor function.
     * Gets configurations from Config class and text.
     *
     */
    public function __construct()
    {
        $this->config_class     = new Config;
        $this->config           = $this->config_class->getAll();
        $this->text             = new Text;
    }

    /**
     * Displays the password recover form
     */
    public function formPasswordRecover(){

        $form_id            = 'qmembers-form-password-recover';
        $qmembers_text      =  $this->text;
        $qmembers_config    =  $this->config;

        require QMEMBERS_PATH_FORMS . 'formPasswordRecover.php';
    }
}