<?php

namespace includes\classes\nodes;

use includes\classes\Text;
use includes\classes\Config;
use includes\classes\User;

/**
 * Displays node content
 */
class NodeMemberDataPersonal
{
    private $config_class;
    private $config;
    private $text;

    /**
     * Constructor function.
     * Gets configurations from Config class and text.
     *
     */
    public function __construct()
    {
        $this->config_class     = new Config;
        $this->config           = $this->config_class->getAll();
        $this->text             = new Text;
    }

    /**
     * Displays the correct view according to the view option parameter
     */
    public function displayMemberDataViewOption(){

        $edit_parameter = '';

         if ( isset($_GET[$this->config['view-option-parameter-name']]) ) $edit_parameter = $_GET[$this->config['view-option-parameter-name']];

         if ($edit_parameter == '1') self::formMemberDataPersonal();
         else                        self::memberDataPersonal();
    }


    /**
     * Displays the personal data
     */
    public function memberDataPersonal(){

        $qmembers_text      = $this->text;
        $qmembers_config    = $this->config;

        $user   = new User;
        $result = $user->getPersonalPicture();
        $personal_picture  = $result['value'];
        $salution_personal = $user->getSalutationPersonal();

        require QMEMBERS_PATH_MEMBER_DATA . 'memberDataPersonal.php';
    }

    public function getimgsize($url, $referer = '')
    {
        $headers = array(
            'Range: bytes=0-32768'
        );

        /* Hint: you could extract the referer from the url */
        if (!empty($referer)) array_push($headers, 'Referer: '.$referer);

        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        $data = curl_exec($curl);
        curl_close($curl);

        $image = imagecreatefromstring($data);

        $return = array(imagesx($image), imagesy($image));

        imagedestroy($image);

        return $return;
    }


    /**
     * Displays the form for personal data
    */
    public function formMemberDataPersonal(){

        $form_id            = 'qmembers-form-member-data-personal';
        $qmembers_text      = $this->text;
        $qmembers_config    = $this->config;

        $user                       = new User;
        $result                     = $user->getPersonalPicture();
        $personal_picture           = $result['value'];
        $countries                  = $user->getCountries();
        $states                     = $user->getStates();
        $salution_personal          = $user->getSalutationPersonal();
        $birthdate_personal_split   = $user->getBirthdatePersonalSplit();

        require QMEMBERS_PATH_FORMS . 'formMemberDataPersonal.php';
    }

    /**
     * Displays the navigation tabs on top of the member data node
     */
    public function memberDataNaviTabs(){

        $element_id         = 'qmembers-member-data-navi-tabs';
        $tab_id             = 'qmembers-form-member-data-personal';
        $qmembers_text      = $this->text;
        $qmembers_config    = $this->config;

        require QMEMBERS_PATH_MEMBER_DATA . 'memberDataNaviTabs.php';
    }
}