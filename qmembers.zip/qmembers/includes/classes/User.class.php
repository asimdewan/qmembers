<?php
namespace includes\classes;

use includes\classes\RabbitMqClient\Entity\BusinessData;
use includes\classes\RabbitMqClient\Entity\GroupSubscription;
use includes\classes\RabbitMqClient\Entity\GroupUnsubscription;
use includes\classes\RabbitMqClient\Entity\Image;
use includes\classes\RabbitMqClient\Entity\Login;
use includes\classes\RabbitMqClient\Entity\MembershipPrimaryEmail;
use includes\classes\RabbitMqClient\Entity\MembershipBilling;
use includes\classes\RabbitMqClient\Entity\MembershipDelivery;
use includes\classes\RabbitMqClient\Entity\PasswordChange;
use includes\classes\RabbitMqClient\Entity\PasswordRecovery;
use includes\classes\RabbitMqClient\Entity\PersonalData;
use includes\classes\RabbitMqClient\Entity\Settings;
use includes\classes\RabbitMqClient\Entity\TerminateMembership;
use includes\classes\RabbitMqClient\Entity\MembershipInfo;

/**
 * User data
 *
 */
class User
{
    private $config;

    private $text;

    private $fieldnamesAuthentication = [
        'id',
        'memberid',
    ];

    private $fieldnamesPersonal = [
        'salutation_personal',
        'title_personal',
        'first_name_personal',
        'last_name_personal',
        'birthdate_personal',
        'street_number_personal',
        'line_personal',
        'zip_personal',
        'city_personal',
        'state_personal',
        'country_personal',
        'email_personal',
        'phone_personal',
        'xing_personal',
        'linkedin_personal',
        'picture_personal',
    ];

    private $fieldnamesProfessional = [
        'company_professional',
        'function_professional',
        'department_professional',
        'office_number_professional',
        'street_number_professional',
        'line_professional',
        'zip_professional',
        'city_professional',
        'state_professional',
        'country_professional',
        'email_professional',
        'phone_professional',
        'vat_professional',
        'business_professional',
    ];

    private $fieldnamesMembershipPrimaryEmail = [
        'prim_email_membership'
    ];

    private $fieldnamesMembershipBilling = [
        'billing_address_membership',
        'title_membership',
        'first_name_membership',
        'last_name_membership',
        'company_membership',
        'department_membership',
        'office_number_membership',
        'street_number_membership',
        'line_membership',
        'zip_membership',
        'city_membership',
        'state_membership',
        'country_membership',
        'email_membership',
        'phone_membership',
    ];

    private $fieldnamesMembershipDelivery = [
        'press_magazine_membership',
    ];

    private $fieldnamesTerminateMembership = [
        'reason_termination',
        'message_termination',
        'disclaimer_termination',
    ];

    private $fieldnamesGroupSubscription = [
        'groups',
    ];

    private $fieldnamesImage = [
        'personal_picture',
        'original_personal_picture',
    ];

    private $fieldnamesMembershipInfo = [
        'membership_from',
        'membership_canceled',
        'membership_until',
        'membership_level',
        'customer_number'
    ];

    /** @var ApiHandler  */
    private $apiHandler;

    /**
     * Gets configurations from Config class and Texts
     */
    public function __construct()
    {
        $config_class = new Config;
        $this->config = $config_class->getAll();
        $this->text = new Text;
        $this->apiHandler = new ApiHandler($this->config);
    }

    /**
     * @return bool
     */
    public function isLoggedIn()
    {
        if (isset($_SESSION[$this->config['session']['name']]['user'])) {
            return true;
        }
        return false;
    }

    /**
     * User authentication.
     *
     * @param string $email
     * @param string $password
     * @return array $result        $result['error'] - true or false (indicating that something went wrong)
     * / result['value'] - true or false (indicating if the login data is correct or not)
     */
    public function authenticate($email, $password)
    {
        $data = new Login();
        $data->setEmail($email);
        $data->setPassword($password);

        $success = $this->apiHandler->handleLogin($data);

        if (!$success) {
            $result['error'] = true;
            //$validationErrors = $this->apiHandler->getValidationErrors('Login');
            //var_dump($validationErrors);
            //$this->apiHandler->getError();

            if ($this->apiHandler->getInfoMessage() == 'membership_level_excluded_from_login')
                $result['value'] = $this->text->get('membership-level-excluded-from-login');
            else
                $result['value'] = $this->text->get('form-login-submit-wrong-login-data');

            return $result;
        }

        $data->setMemberID($this->apiHandler->getMemberID());

        $member = $this->apiHandler->getMemberData($data);
        if (empty($member)) {
            $result['error'] = true;
            $result['value'] = $this->text->get('user--authenticate-api-error');
            return $result;
        }

        // Start session
        if (!isset($_SESSION)) {
            $session = new Session;
            $user_session = $session->startSession();

            if ($user_session !== true) {
                $result['error'] = true;
                return $result;
            }
        }

        $fieldnames = array_merge(
            $this->fieldnamesAuthentication,
            $this->fieldnamesPersonal,
            $this->fieldnamesProfessional,
            $this->fieldnamesMembershipPrimaryEmail,
            $this->fieldnamesMembershipBilling,
            $this->fieldnamesMembershipDelivery,
            $this->fieldnamesTerminateMembership,
            $this->fieldnamesImage,
            $this->fieldnamesMembershipInfo
        );

        $sessionSaved = $this->saveToSession($member, $fieldnames);
        if (!$sessionSaved) {

            $result['error']  = true;
            $result['value'] = 'Session could not be saved';
            return $result;
        }

        $result['value'] = true;
        return $result;
    }

    /**
     * Gets current member data from DB an saves it to the session
     *
     */
    public function updateSessionMemberData()
    {
        if ( !$this->isLoggedIn() ){

            $result['value'] = true;
            return $result;
        }

        $memberid = $this->getMemberId();

        if ( empty($memberid) ){

            $result['value'] = true;
            return $result;
        }

        $member = $this->apiHandler->getMemberDataByMemberID($memberid);
        if (empty($member)) {
            $result['error'] = true;
            $result['value'] = $this->text->get('user--authenticate-api-error');
            return $result;
        }

        $fieldnames = array_merge(
            $this->fieldnamesAuthentication,
            $this->fieldnamesPersonal,
            $this->fieldnamesProfessional,
            $this->fieldnamesMembershipPrimaryEmail,
            $this->fieldnamesMembershipBilling,
            $this->fieldnamesMembershipDelivery,
            $this->fieldnamesTerminateMembership,
            $this->fieldnamesImage,
            $this->fieldnamesMembershipInfo,
            $this->fieldnamesGroupSubscription
        );

        $sessionSaved = $this->saveToSession($member, $fieldnames);
        if (!$sessionSaved) {

            $result['error']  = true;
            $result['value'] = 'Session could not be saved';
            return $result;
        }

        $result['value'] = true;
        return $result;
    }

    /**
     * @return string       User email or empty string if not set.
     */
    public function logout()
    {
        $session = new Session;
        $result = $session->destroySession();

        if (!$result) {
            $result['error'] = true;
            $result['value'] = $this->text->get('user--logout-error-session-name-not-in-config');
            return $result;
        }

        $result = array();
        $result['redirect_url'] = $this->config['redirect-url-after-logout'];
        return $result;
    }

    /**
     * Returns member id if user is logged in
     *
     * @return string
     */
    public function getMemberId()
    {
        if ( $this->isLoggedIn() ){
            if ( isset($_SESSION[$this->config['session']['name']]['user']['memberid']) )
                return $_SESSION[$this->config['session']['name']]['user']['memberid'];
        }

        return '';
    }

    /**
     * Returns member id if user is logged in
     *
     * @return string
     */
    public function getCustomerNumber()
    {
        if ( $this->isLoggedIn() ){
            if ( isset($_SESSION[$this->config['session']['name']]['user']['customer_number']) )
                return $_SESSION[$this->config['session']['name']]['user']['customer_number'];
        }

        return '';
    }

    /**
     * Returns member id in a certain format that should be used to display it
     *
     * @return string
     */
    public function getCustomerNumberToBeDisplayed()
    {
        $display_customer_number = '';
        $customer_number         = $this->getCustomerNumber();

        if ($customer_number)
            $display_customer_number = str_replace('.', '', $customer_number);

        return $display_customer_number;
    }

    /**
     * Processes the password recover form submission
     *
     * @param array $emailPasswordRecover       Contains posted data (may also contain other data, not only form data, e.g. request_id)
     * @return array            Contains the modification of member data result data.
     */
    public function passwordRecover($emailPasswordRecover)
    {
        $data = new PasswordRecovery();
        $data->setEmail($emailPasswordRecover['email']);

        $hashCode = $this->apiHandler->handlePasswordRecovery($data);
        if (empty($hashCode)) {
            $result['error'] = true;
            $validationErrors = $this->apiHandler->getValidationErrors('PasswordRecovery');
            //var_dump($validationErrors);
            //$result['value'] = $this->apiHandler->getError();
            $result['value'] = $this->text->get('user--password-recovery-email-not-found');
            return $result;
        }

        // Send mail
        $mail = new Mail;

        $mailtext = $this->text->get('user--email-password-recover-mailtext');
        $mailtext = str_replace('___link_hash___', $this->config['url-password-change'].$hashCode, $mailtext);

        $to         = $emailPasswordRecover['email'];
        $from       = $this->config['email-password-recover-from'];
        $from_name  = $this->config['email-password-recover-from_name'];
        $reply_to   = $this->config['email-password-recover-reply_to'];
        $subject    = $this->config['email-password-recover-subject'];
        $bcc        = $this->config['email-password-recover-bcc'];
        $attachment = '';

        $result['value'] = $mail->mailSend($to,$from,$from_name,$reply_to,$subject,$mailtext,$bcc,$attachment);
        return $result;  // $result['value'] is either true or false
    }


    /**
     * Processes the password change form submission
     *
     * @param array $passwordChange       Contains posted data (may also contain other data, not only form data, e.g. request_id)
     * @return array            Contains the modification of member data result data.
     */
    public function passwordChange($passwordChange)
    {
        $data = new PasswordChange();
        $data->setPassword($passwordChange['change_password']);
        $data->setHash($passwordChange['hash_password_change']);

        $success = $this->apiHandler->handlePasswordChange($data);
        if (!$success) {
            $result['error']  = true;
            $validationErrors = $this->apiHandler->getValidationErrors('PasswordChange');
            //var_dump($validationErrors);
            $result['value'] = $this->text->get('user--form-password-change-hash-link-expired');//$this->apiHandler->getError();
            return $result;
        }

        $result['value'] = true;
        return $result;
    }


    /**
     * Processes the member data personal form submission
     *
     * @param array $memberDataPersonal       Contains posted data (may also contain other data, not only form data, e.g. request_id)
     * @return array            Contains the modification of member data result data.
     */
    public function saveMemberDataPersonal($memberDataPersonal)
    {
        // Special requirement: Also send PrimaryEmail, MembershipBilling, MembershipDelivery to CRM
        // If these haven't been filled yet, there might be a validation error. Therefore, we check this first.
        $result = $this->preCheckRelatedData();
        if ( isset($result['error']) && $result['error'] == true){
            return $result;
        }

        $data = new PersonalData();
        $data->setId($this->getMemberId());
        $data->setSalutation($memberDataPersonal['salutation_personal']);
        $data->setTitle($memberDataPersonal['title_personal']);
        $data->setFirstName($memberDataPersonal['first_name_personal']);
        $data->setLastName($memberDataPersonal['last_name_personal']);
        $data->setDateOfBirth($memberDataPersonal['birthdate_personal']);
        $data->setAddress($memberDataPersonal['street_number_personal']);
        $data->setAddressAddition($memberDataPersonal['line_personal']);
        $data->setZip($memberDataPersonal['zip_personal']);
        $data->setCity($memberDataPersonal['city_personal']);
        $data->setRegion($memberDataPersonal['state_personal']);
        $data->setCountry($memberDataPersonal['country_personal']);
        $data->setEmail($memberDataPersonal['email_personal']);
        $data->setTelephone($memberDataPersonal['phone_personal']);
        $data->setXing($memberDataPersonal['xing_personal']);
        $data->setLinkedIn($memberDataPersonal['linkedin_personal']);

        $success = $this->apiHandler->handleData($data);
        if (!$success) {
            $result['error'] = true;
            //$validationErrors = $this->apiHandler->getValidationErrors('PersonalData');
            //var_dump($validationErrors);
            //$result['value'] = $this->apiHandler->getError();
            $result['value'] = $this->text->get('saving-member-data-failed');
            return $result;
        }

        $sessionSaved = $this->saveToSession($memberDataPersonal, $this->fieldnamesPersonal);
        if (!$sessionSaved) {
            $result['error']  = true;
            $result['value'] = $this->text->get('saving-member-data-to-session-failed');
            return $result;
        }

        // Special requirement: Also send PrimaryEmail, MembershipBilling, MembershipDelivery to CRM
        // If these haven't been filled yet, there might be a validation error. Therefore, try saving them first.
        $result = $this->saveRelatedData();
        if ( isset($result['error']) && $result['error'] == true){
            return $result;
        }

        $result = array();
        $result['value'] = true;
        return $result;
    }

    /**
     * Processes the member data professional form submission
     *
     * @param array $memberDataProfessional       Contains posted data (may also contain other data, not only form data, e.g. request_id)
     * @return array            Contains the modification of member data result data.
     */
    public function saveMemberDataProfessional($memberDataProfessional)
    {
        // Special requirement: Also send PrimaryEmail, MembershipBilling, MembershipDelivery to CRM
        // If these haven't been filled yet, there might be a validation error. Therefore, we check this first.
        $result = $this->preCheckRelatedData();
        if ( isset($result['error']) && $result['error'] == true){
            return $result;
        }

        $data = new BusinessData();
        $data->setId($this->getMemberId());
        $data->setCompany($memberDataProfessional['company_professional']);
        $data->setPosition($memberDataProfessional['function_professional']);
        $data->setDepartment($memberDataProfessional['department_professional']);
        $data->setRoom($memberDataProfessional['office_number_professional']);
        $data->setAddress($memberDataProfessional['street_number_professional']);
        $data->setAddressAddition($memberDataProfessional['line_professional']);
        $data->setZip($memberDataProfessional['zip_professional']);
        $data->setCity($memberDataProfessional['city_professional']);
        $data->setRegion($memberDataProfessional['state_professional']);
        $data->setCountry($memberDataProfessional['country_professional']);
        $data->setEmail($memberDataProfessional['email_professional']);
        $data->setTelephone($memberDataProfessional['phone_professional']);
        $data->setVatId($memberDataProfessional['vat_professional']);
        $data->setBranch($memberDataProfessional['business_professional']);

        $success = $this->apiHandler->handleData($data);
        if (!$success) {
            $result['error'] = true;
            //$validationErrors = $this->apiHandler->getValidationErrors('BusinessData');
            //var_dump($validationErrors);
            //$result['value'] = $this->apiHandler->getError();
            $result['value'] = $this->text->get('saving-member-data-failed');
            return $result;
        }

        $sessionSaved = $this->saveToSession($memberDataProfessional, $this->fieldnamesProfessional);
        if (!$sessionSaved) {
            $result['error']  = true;
            $result['value'] = 'Session could not be saved';
            return $result;
        }

        // Special requirement: Also send PrimaryEmail, MembershipBilling, MembershipDelivery to CRM
        // If these haven't been filled yet, there might be a validation error. Therefore, try saving them first.
        $result = $this->saveRelatedData();
        if ( isset($result['error']) && $result['error'] == true){
            return $result;
        }

        $result = array();
        $result['value'] = true;
        return $result;
    }


    /**
     * Validates related data.
     *
     * @return array            True or result array with error data.
     */
    public function preCheckRelatedData(){

        // Primary email
        $result = $this->getMembershipPrimaryEmail();
        if ( isset($result['error']) && $result['error'] == true){
            $result['value'] = $this->text->get('save-related-data-error-precheck-primary-email');
            return $result;
        }
        $post = $result;

        // Validate data
        $FormValidate   = new FormValidate;
        $form_config_id = 'member-data-membership-prim-email';

        $result = $FormValidate->formValidation($form_config_id, $post);

        //if (!empty($result['value'])) return $result;
        if (count($result['value']) != 0) {
            $result['error'] = true;
            $result['value'] = $this->text->get('save-related-data-error-precheck-primary-email');
            return $result;
        }


        // Billing address
        $result = $this->getMemberDataMembership();
        if ( isset($result['error']) && $result['error'] == true){
            $result['value'] = $this->text->get('save-related-data-error-precheck-billing-address');
            return $result;
        }
        $post = $result;

        // Validate form
        $FormValidate = new FormValidate;
        $form_config_id = 'member-data-membership';

        // User selected "Other" - Skip validation of empty fields
        if ($post['billing_address_membership'] != '3') {

            $form_config_id = 'member-data-membership-no-other-address';

            unset($post['title_membership']);
            unset($post['first_name_membership']);
            unset($post['last_name_membership']);
            unset($post['company_membership']);
            unset($post['department_membership']);
            unset($post['office_number_membership']);
            unset($post['street_number_membership']);
            unset($post['line_membership']);
            unset($post['zip_membership']);
            unset($post['city_membership']);
            unset($post['state_membership'] );
            unset($post['country_membership']);
            unset($post['email_membership']);
            unset($post['phone_membership']);
        }

        $result = $FormValidate->formValidation($form_config_id, $post);

        //if (!empty($result['value'])) return $result;
        if (count($result['value']) != 0) {
            $result['error'] = true;
            $result['value'] = $this->text->get('save-related-data-error-precheck-billing-address');
            return $result;
        }


        // Magazine delivery address
        $result = $this->getMemberDataMembershipPress();
        if ( isset($result['error']) && $result['error'] == true){
            $result['value'] = $this->text->get('save-related-data-error-precheck-delivery-address');
            return $result;
        }
        $post = $result;

        // Validate form
        $FormValidate = new FormValidate;
        $form_config_id = 'member-data-membership-press';

        $result = $FormValidate->formValidation($form_config_id, $post);

        //if (!empty($result['value'])) return $result;
        if (count($result['value']) != 0) {
            $result['error'] = true;
            $result['value'] = $this->text->get('save-related-data-error-precheck-delivery-address');
            return $result;
        }

        return true;
    }


    /**
     * Saves related data. This is a CRM requirement. Otherwise a delivery address, primary email or billing address might not be set correctly in the CRM.
     *
     * @return array            True or result array with error data.
     */
    public function saveRelatedData(){

        // Save primary email
        $result = $this->getMembershipPrimaryEmail();
        if ( isset($result['error']) && $result['error'] == true){
            $result['value'] = $this->text->get('save-related-data-error-primary-email');
            return $result;
        }
        $memberDataMembership = $result;

        $result = $this->saveMemberDataMembershipPrimaryEmail($memberDataMembership);
        if ( isset($result['error']) && $result['error'] == true){
            return $result;
        }

        // Save billing address
        $result = $this->getMemberDataMembership();
        if ( isset($result['error']) && $result['error'] == true){
            $result['value'] = $this->text->get('save-related-data-error-billing-address');
            return $result;
        }
        $memberDataMembership = $result;

        $result = $this->saveMemberDataMembership($memberDataMembership);
        if ( isset($result['error']) && $result['error'] == true){
            return $result;
        }

        // Save magazine delivery address
        $result = $this->getMemberDataMembershipPress();
        if ( isset($result['error']) && $result['error'] == true){
            $result['value'] = $this->text->get('save-related-data-error-delivery-address');
            return $result;
        }
        $memberDataMembership = $result;

        $result = $this->saveMemberDataMembershipPress($memberDataMembership);
        if ( isset($result['error']) && $result['error'] == true){
            return $result;
        }

        return true;
    }


    /**
     * Processes the member data membership primary email form submission
     *
     * @param array $memberDataMembership       Contains posted data (may also contain other data, not only form data, e.g. request_id)
     * @return array                            Contains result data.
     */
    public function saveMemberDataMembershipPrimaryEmail($memberDataMembership)
    {
        $data = new MembershipPrimaryEmail();
        $data->setId($this->getMemberId());
        $data->setPrimaryEmail($memberDataMembership['prim_email_membership']);

        $success = $this->apiHandler->handleData($data);
        if (!$success) {
            $result['error'] = true;
            $validationErrors = $this->apiHandler->getValidationErrors('MembershipPrimEmail');
            //var_dump($validationErrors);
            //$result['value'] = $this->apiHandler->getError();
            $result['value'] = $this->text->get('saving-member-data-failed');
            return $result;
        }

        $sessionSaved = $this->saveToSession($memberDataMembership, $this->fieldnamesMembershipPrimaryEmail);
        if (!$sessionSaved) {
            $result['error']  = true;
            //$result['value'] = 'Session could not be saved';
            $result['value'] = $this->text->get('saving-member-data-to-session-failed');
            return $result;
        }

        $result['value'] = true;
        return $result;
    }


    /**
     * Processes the member data membership form submission
     *
     * @param array $memberDataMembership       Contains posted data (may also contain other data, not only form data, e.g. request_id)
     * @return array            Contains the modification of member data result data.
     */
    public function saveMemberDataMembership($memberDataMembership)
    {
        $data = new MembershipBilling();
        $data->setId($this->getMemberId());
        $data->setBillingAddress((int) $memberDataMembership['billing_address_membership']);

        if ((int) $memberDataMembership['billing_address_membership'] == MembershipBilling::BILLING_ADDRESS_OTHER) {
            $data->setTitle($memberDataMembership['title_membership']);
            $data->setFirstName($memberDataMembership['first_name_membership']);
            $data->setLastName($memberDataMembership['last_name_membership']);
            $data->setCompany($memberDataMembership['company_membership']);
            $data->setDepartment($memberDataMembership['department_membership']);
            $data->setRoom($memberDataMembership['office_number_membership']);
            $data->setAddress($memberDataMembership['street_number_membership']);
            $data->setAddressAddition($memberDataMembership['line_membership']);
            $data->setZip($memberDataMembership['zip_membership']);
            $data->setCity($memberDataMembership['city_membership']);
            $data->setRegion($memberDataMembership['state_membership']);
            $data->setCountry($memberDataMembership['country_membership']);
            $data->setEmail($memberDataMembership['email_membership']);
            $data->setTelephone($memberDataMembership['phone_membership']);
        } else {
            // values need to be deleted from session when not used
            $memberDataMembership['title_membership']           = '';
            $memberDataMembership['first_name_membership']      = '';
            $memberDataMembership['last_name_membership']       = '';
            $memberDataMembership['company_membership']         = '';
            $memberDataMembership['department_membership']      = '';
            $memberDataMembership['office_number_membership']   = '';
            $memberDataMembership['street_number_membership']   = '';
            $memberDataMembership['line_membership']            = '';
            $memberDataMembership['zip_membership']             = '';
            $memberDataMembership['city_membership']            = '';
            $memberDataMembership['state_membership']           = '';
            $memberDataMembership['country_membership']         = '';
            $memberDataMembership['email_membership']           = '';
            $memberDataMembership['phone_membership']           = '';
        }

        $success = $this->apiHandler->handleData($data);
        if (!$success) {
            $result['error'] = true;
            //$validationErrors = $this->apiHandler->getValidationErrors('MembershipBilling');
            //var_dump($validationErrors);
            //$result['value'] = $this->apiHandler->getError();
            $result['value'] = $this->text->get('saving-member-data-failed');

            return $result;
        }

        $sessionSaved = $this->saveToSession($memberDataMembership, $this->fieldnamesMembershipBilling);
        if (!$sessionSaved) {
            $result['error']  = true;
            $result['value'] = 'Session could not be saved';
            return $result;
        }

        $result['value'] = true;
        return $result;
    }


    /**
     * Processes the member data membership press form submission
     *
     * @param array $memberDataMembership       Contains posted data (may also contain other data, not only form data, e.g. request_id)
     * @return array            Contains the modification of member data result data.
     */
    public function saveMemberDataMembershipPress($memberDataMembership)
    {
        $data = new MembershipDelivery();
        $data->setId($this->getMemberId());
        $data->setDeliveryAddress((int) $memberDataMembership['press_magazine_membership']);

        $success = $this->apiHandler->handleData($data);
        if (!$success) {
            $result['error'] = true;
            $validationErrors = $this->apiHandler->getValidationErrors('MembershipDelivery');
            //var_dump($validationErrors);
            //$result['value'] = $this->apiHandler->getError();
            $result['value'] = $this->text->get('saving-member-data-failed');
            return $result;
        }

        $sessionSaved = $this->saveToSession($memberDataMembership, $this->fieldnamesMembershipDelivery);
        if (!$sessionSaved) {
            $result['error']  = true;
            //$result['value'] = 'Session could not be saved';
            $result['value'] = $this->text->get('saving-member-data-to-session-failed');
            return $result;
        }

        $result['value'] = true;
        return $result;
    }


    /**
     * Processes the member data termination form submission
     *
     * @param array $memberDataTermination       Contains posted data (may also contain other data, not only form data, e.g. request_id)
     * @return array            Contains the modification of member data result data.
     */
    public function saveMemberDataTermination($memberDataTermination)
    {

        // Calculate termination date
        $result          = $this->calculateMembershipUntilDate();
        if ( isset($result['error']) ) {
            $result['value'] = $this->text->get('form-member-data-termination-submit-not-saved');
            return $result;
        }
        $membership_until_date = $result['value'];

        // Save general termination data
        $data = new TerminateMembership();
        $data->setId($this->getMemberId());
        $data->setReason($memberDataTermination['reason_termination']);
        $data->setMessage($memberDataTermination['message_termination']);
        $data->setDisclaimer(true);

        $success = $this->apiHandler->handleData($data);

        if (!$success) {
            $result['error'] = true;
            //$validationErrors = $this->apiHandler->getValidationErrors('TerminateMembership');
            //var_dump($validationErrors);

            $result['value'] = $this->text->get('form-member-data-termination-submit-not-saved');//$this->apiHandler->getError();
            return $result;
        }

        // Save termination date
        $data = new MembershipInfo();
        $data->setId($this->getMemberId());

        $from                       = $this->getMembershipFrom();
        $type                       = $this->getMembershipLevel();
        $customerNumber             = $this->getCustomerNumber();
        $membership_canceled_date   = date('d.m.Y', time() );

        $data->setFrom($from);
        $data->setType($type);
        $data->setCustomerNumber($customerNumber);

        $data->setCanceled($membership_canceled_date);
        $data->setUntil($membership_until_date);

        $success = $this->apiHandler->handleData($data);

        if (!$success) {
            $result['error'] = true;
            $validationErrors = $this->apiHandler->getValidationErrors('TerminateMembership');
            var_dump($validationErrors);

            $result['value'] = $this->text->get('form-member-data-termination-submit-ok-but-termination-date-not-calc');//$this->apiHandler->getError();
            return $result;
        }

        $memberDataTermination['disclaimer_termination'] = true;
        $sessionSaved = $this->saveToSession($memberDataTermination, $this->fieldnamesTerminateMembership);
        if (!$sessionSaved) {
            $result['error']  = true;
            $result['value'] = 'Session could not be saved';
            return $result;
        }

        $memberDataMembershipInfo['membership_canceled'] = $membership_canceled_date;
        $memberDataMembershipInfo['membership_until']    = $membership_until_date;
        $sessionSaved = $this->saveToSession($memberDataMembershipInfo, $this->fieldnamesMembershipInfo);
        if (!$sessionSaved) {
            $result['error']  = true;
            $result['value'] = 'Session could not be saved';
            return $result;
        }

        // Send mail
        $mail = new Mail;

        $mailtext = $this->text->get('user--email-membership-termination-mailtext');
        $mailtext = str_replace('___member_id___',           $this->getMemberId(), $mailtext);
        $mailtext = str_replace('___reason_termination___',  $memberDataTermination['reason_termination'], $mailtext);
        $mailtext = str_replace('___message_termination___', $memberDataTermination['message_termination'], $mailtext);


        $to         = $this->config['email-membership-termination-to'];
        $from       = $this->config['email-membership-termination-from'];
        $from_name  = $this->config['email-membership-termination-from_name'];
        $reply_to   = $this->config['email-membership-termination-reply_to'];
        $subject    = $this->config['email-membership-termination-subject'];
        $bcc        = $this->config['email-membership-termination-bcc'];
        $attachment = '';

        $result['value'] = $mail->mailSend($to,$from,$from_name,$reply_to,$subject,$mailtext,$bcc,$attachment);
        return $result;  // $result['value'] is either true or false
    }

            /**
             * Calculates the date on which the membership ends, based on todays termination date
             *
            * @return string           Formated date.
             */
    public function calculateMembershipUntilDate()
    {
        $termination_date = '';

        $termination_period = $this->config['membership-termination-period-in-months'];

        if ( !isset($termination_period) ){
            $return['error'] = true;
            return $return;
        }

        // A membership can only be cancelled until the end of the current year
        // if today's month + termination period is still within this year.

        $timestamp     = time();
        $current_month = date('n', $timestamp );
        $current_year  = date('Y', $timestamp );

        if( ($current_month + $termination_period) > 12) $termination_year = $current_year + 1;
        else                                             $termination_year = $current_year;

        $termination_date = '31.12.' . $termination_year;

        $return['value'] = $termination_date;

        return $return;
    }


    /**
     * Processes the member data settings form submission
     *
     * @param array $memberDataSettings       Contains posted data (may also contain other data, not only form data, e.g. request_id)
     * @return array            Contains the modification of member data result data.
     */
    public function saveMemberDataSettings($memberDataSettings)
    {
        $data = new Settings();
        $data->setId($this->getMemberId());
        $data->setOldPassword($memberDataSettings['password_old_settings']);
        $data->setNewPassword($memberDataSettings['password_new_settings']);

        $match = $this->apiHandler->validateOldPassword($data);
        if (!$match) {
            $result['error'] = true;
            $result['value'] = $this->text->get('form-member-data-settings-error-password');
            return $result;
        }

        $success = $this->apiHandler->handleData($data);
        if (!$success) {
            $result['error'] = true;
            //$validationErrors = $this->apiHandler->getValidationErrors('Settings');
            //var_dump($validationErrors);
            //$result['value'] = $this->apiHandler->getError();
            $result['value'] = $this->text->get('saving-member-data-failed');
            return $result;
        }

        $result['value'] = true;
        return $result;
    }

    /**
     * saves values of the given fieldnames of person into session
     *
     * @param array $data
     * @param array $fieldnames
     * @return bool
     */
    private function saveToSession($data, $fieldnames)
    {
        $session_name = $this->config['session']['name'];
        if (!$session_name) {
            return false;
        }

        $savedData = false;
        foreach ($fieldnames as $fieldname) {
            if (isset($data[$fieldname])) {
                $_SESSION[$session_name]['user'][$fieldname] = $data[$fieldname];
                $savedData = true;
            }
        }

        // on every data change the memberlist needs to be cleared, to get new data for memberlist
        if ($savedData) {
            unset($_SESSION[$session_name]['memberlist']);
        }

        return true;
    }

    /**
     * Search in the memberlist
     *
     * @param array $search       Contains posted data (may also contain other data, not only form data, e.g. request_id)
     * @return array            Contains the modification of member data result data.
     */
    public function searchMemberDataMemberlist($search_parameter, $search_page)
    {
        $session_name = $this->config['session']['name'];
        if (!$session_name) {
            $result['error']  = true;
            return $result;
        }

        if (!isset($_SESSION[$session_name]['memberlist'])) {

            $memberlist = $this->apiHandler->getMemberlist();

            if (empty($memberlist)) {
                $result['error']  = true;
                $result['value']  = $this->text->get('form-member-data-memberlist-submit-error');
                return $result;
            }

            $_SESSION[$session_name]['memberlist'] = $memberlist;
        }

       $list_result = [];
        foreach ($_SESSION[$session_name]['memberlist'] as $value) {
            if  ( $search_parameter == "" ) {
                $list_result[] = $value;
            }
            else{
                // Search fields
                $search_parameter = trim($search_parameter);
                
                if    (stripos($value['first_name_personal'],   $search_parameter) !== false) $list_result[] = $value;
                elseif(stripos($value['last_name_personal'],    $search_parameter) !== false) $list_result[] = $value;
                elseif(stripos($value['first_name_personal'] . ' ' . $value['last_name_personal'],    $search_parameter) !== false) $list_result[] = $value;
                elseif(stripos($value['function_professional'], $search_parameter) !== false) $list_result[] = $value;
                elseif(stripos($value['company_professional'],  $search_parameter) !== false) $list_result[] = $value;
                elseif(stripos($value['city_professional'],     $search_parameter) !== false) $list_result[] = $value;
            }

            // NEEDED FOR THE PAGINATION
            $result['value']['amount'] = count($list_result);
        }

        // PAGE SLICE THE RESULTS
        $max_results = ($result['value']['amount'] > $this->config['list-search-max-results'])?$this->config['list-search-max-results']:$result['value']['amount'];
        $search_page = ($search_page === "")?0:(intval($search_page) - 1);
        $initial_value = $search_page * $this->config['list-search-max-results'];

        $result['value']['list'] = array_slice($list_result, $initial_value, $max_results);

        return $result;
    }

    /**
     * Returns session data
     *
     * @return array            Contains the values saved in the session
     */
    public function getMembershipPrimaryEmail(){


        $session_name = $this->config['session']['name'];
        if (!$session_name) {
            $return['error'] = true;
            return $return;
        }

        $data = array();

        foreach ($this->fieldnamesMembershipPrimaryEmail as $value){

            if ( isset($_SESSION[$session_name]['user'][$value]) ){

                $data[$value] = $_SESSION[$session_name]['user'][$value];
            }
        }

        return $data;
    }

    /**
     * Returns session data
     *
     * @return array            Contains the values saved in the session
     */
    public function getMemberDataMembership(){

        $session_name = $this->config['session']['name'];
        if (!$session_name) {
            return false;
        }

        $data = array();

        foreach ($this->fieldnamesMembershipBilling as $value){

            if ( isset($_SESSION[$session_name]['user'][$value]) ){

                $data[$value] = $_SESSION[$session_name]['user'][$value];
            }
        }

        return $data;
    }

    /**
     * Returns session data
     *
     * @return array            Contains the values saved in the session
     */
    public function getMemberDataMembershipPress(){

        $session_name = $this->config['session']['name'];
        if (!$session_name) {
            return false;
        }

        $data = array();

        foreach ($this->fieldnamesMembershipDelivery as $value){

            if ( isset($_SESSION[$session_name]['user'][$value]) ){

                $data[$value] = $_SESSION[$session_name]['user'][$value];
            }
        }

        return $data;
    }

    /**
     * @return string of groups
     */
    public function getGroups()
    {
        if ( $this->isLoggedIn() ){
            if ( isset($_SESSION[$this->config['session']['name']]['user']['groups']) )
                return $_SESSION[$this->config['session']['name']]['user']['groups'];
        }

        return '';
    }

    /**
     * Get subscribedgGroups
     *
     * @return string            Contains the subscribed groups
     */
    public function getSubscribedGroups()
    {
//TODO: user data has field 'groups' of the current logged in user, therefore this function might not be needed, please check
        // or use function getGroups, to get it from session
        $result['value'] = $this->getGroups();
        return $result;
/*


        $groupslist = 'energie,freizeit_tourismus,berlin_brandenburg';
// WHEN API READY UNCOMMENT ALL THIS LINES AND REMOVE THE PREVIOUS ONE
        $data = new Groups();
        $data->setId($this->getMemberId());
        //$groupslist = $this->apiHandler->getSubscribedGroups(self::getMemberId());
        $groupslist = $this->apiHandler->handleData($data);
        if (!$groupslist) {
            $result['error'] = true;
            $validationErrors = $this->apiHandler->getValidationErrors();
            var_dump($validationErrors);
            $result['value'] = $this->apiHandler->getError();
            return $result;
        }

        $result['value'] = $groupslist;
        return $result;

*/
    }

    /**
     * Processes the subscribe group form submission
     *
     * @param array $groupsJoinSubmit       Contains posted data (may also contain other data, not only form data, e.g. request_id)
     * @return array            Contains the modification of member data result data.
     */
    public function subscribeMemberGroup($groupsJoinSubmit)
    {
        $data = new GroupSubscription();
        $data->setId($this->getMemberId());
        $data->setGroup($groupsJoinSubmit['group_id']);

        $joinedGroups = $this->apiHandler->handleGroups($data, $this->getGroups());
        if (!$joinedGroups) {
            $result['error'] = true;
            //$validationErrors = $this->apiHandler->getValidationErrors('Groups');
            //var_dump($validationErrors);
            //$result['value'] = $this->apiHandler->getError();
            $result['value'] = $this->text->get('saving-member-data-failed');
            return $result;
        }

        $sessionSaved = $this->saveToSession(array('groups' => $joinedGroups), $this->fieldnamesGroupSubscription);
        if (!$sessionSaved) {
            $result['error']  = true;
            $result['value'] = 'Session could not be saved';
            return $result;
        }

        $result['value'] = true;
        return $result;
    }


    /**
     * Processes the unsubscribe group form submission
     *
     * @param array $groupsLeaveSubmit       Contains posted data (may also contain other data, not only form data, e.g. request_id)
     * @return array            Contains the modification of member data result data.
     */
    public function unsubscribeMemberGroup($groupsLeaveSubmit)
    {
        $data = new GroupUnsubscription();
        $data->setId($this->getMemberId());
        $data->setGroup($groupsLeaveSubmit['group_id']);

        $joinedGroups = $this->apiHandler->handleGroups($data, $this->getGroups());
        if ($joinedGroups === false) {
            $result['error'] = true;
            //$validationErrors = $this->apiHandler->getValidationErrors('Groups');
            //var_dump($validationErrors);
            //$result['value'] = $this->apiHandler->getError();
            $result['value'] = $this->text->get('saving-member-data-failed');
            return $result;
        }

        $sessionSaved = $this->saveToSession(array('groups' => $joinedGroups), $this->fieldnamesGroupSubscription);
        if (!$sessionSaved) {
            $result['error']  = true;
            $result['value'] = 'Session could not be saved';
            return $result;
        }

        $result['value'] = true;
        return $result;
    }

    /**
     * Gets the list of countries
     *
     * @return array            Contains the list of countries.
     */
    public function getCountries() {

        $countries = array();
        db_set_active('qmembers');
        $query = db_select('country', 'c');
        $query->fields('c');
        $query->orderBy('name');
        $result = $query->execute();
        while ($row = $result->fetchAssoc()) {
            $countries[$row['name']] = $row['name'];
        }
        db_set_active();

        return $countries;
    }

    /**
     * Gets the list of branches
     *
     * @return array            Contains the list of branches.
     */
    public function getBranches() {

        $branches = array();
        db_set_active('qmembers');
        $query = db_select('branch', 'b');
        $query->fields('b');
        $query->orderBy('name');
        $result = $query->execute();
        while ($row = $result->fetchAssoc()) {
            $branches[$row['name']] = $row['name'];
        }
        db_set_active();

        return $branches;
    }

    /**
     * Gets the list of reasons
     *
     * @return array            Contains the list of reasons.
     */
    public function getReasons() {

        $reasons = array();
        db_set_active('qmembers');
        $query = db_select('reason', 'b');
        $query->fields('b');
        $query->orderBy('name');
        $result = $query->execute();
        while ($row = $result->fetchAssoc()) {
            $reasons[$row['name']] = $row['name'];
        }
        db_set_active();

        return $reasons;
    }

    /**
     * Gets the list of states
     *
     * @return array            Contains the list of states.
     */
    public function getStates() {

        $states = array();
        db_set_active('qmembers');
        $query = db_select('region', 'r');
        $query->fields('r');
        $query->orderBy('name');
        $result = $query->execute();
        while ($row = $result->fetchAssoc()) {
            $states[$row['name']] = $row['name'];
        }
        db_set_active();

        return $states;

    /*
        $states = [
            'Bundesland 1',
            'Bundesland 2',
            'Bundesland 3',
            'Bundesland 4',
            'Bundesland 5',
            'Bundesland 6',
            'Bundesland 7',
            'Bundesland 8',
            'Bundesland 9',
            'Bundesland 10'
        ];
    */

        //return $states;
    }

    /**
     * Gets the URL of the profile image
     *
     * @return array            Contains the key image_url.
     */
    public function getPersonalPicture($path_type = '', $originalPicture = false)
    {
        $result['value'] = '';

        $fieldname = $this->fieldnamesImage[0];
        if ($originalPicture) {
            $fieldname = $this->fieldnamesImage[1];
        }

        if (isset($_SESSION[$this->config['session']['name']]['user'][$fieldname])) {

            if ($path_type == 'server_path'){

                $result['value'] = QMEMBERS_PATH_PROFILE_IMAGES . basename($_SESSION[$this->config['session']['name']]['user'][$fieldname]);
                return $result;
            }

            $result['value'] = $_SESSION[$this->config['session']['name']]['user'][$fieldname];
            return $result;
        }

        /*
        echo '<pre>';
        print_r($_SESSION[$this->config['session']['name']]);
        echo '</pre>';
        */

        if ($path_type == 'server_path'){
            $result['value'] = '';
            return $result;
        }

        // Return placeholder url if there is no image in the session
        $result['value'] = QMEMBERS_FILE_URL_PROFILE_PLACEHOLDER_IMAGE;
        return $result;
    }

    /**
     * Saves the profile image
     *
     * @param array $file 'picture_personal' and 'original_picture_personal'
     * @return array Contains the key image_url.
     */
    public function setPersonalPicture($files)
    {
        $FileHandler = new FileHandler;
        $result      = $FileHandler->savePersonalPicture($files);

        if (isset($result['image_url'])) {
            $data = new Image();
            $data->setId($this->getMemberId());
            $data->setUrl($result['image_url']);
            $data->setOriginalUrl($result['original_image_url']);

            $success = $this->apiHandler->handleData($data);
            if (!$success) {
                $result['error'] = true;
                //$validationErrors = $this->apiHandler->getValidationErrors('Image');
                //var_dump($validationErrors);
                //$result['value'] = $this->apiHandler->getError();
                $result['value'] = $this->text->get('saving-profile-image-failed');
                return $result;
            }

            $sessionData = array(
                $this->fieldnamesImage[0] => $result['image_url'],
                $this->fieldnamesImage[1] => $result['original_image_url'],
            );

            $sessionSaved = $this->saveToSession($sessionData, $this->fieldnamesImage);
            if (!$sessionSaved) {
                $result['error']  = true;
                //$result['value'] = 'Session could not be saved';
                $result['value'] = $this->text->get('saving-member-data-to-session-failed');
                return $result;
            }

            return $result;
        }

        return $result;
    }

    /**
     * Gets the membership level
     *
     * @return string           Membership level.
     */
    public function getMembershipLevel()
    {

        $membership_level = '';

        if (isset($_SESSION[$this->config['session']['name']]['user']['membership_level'])){

            $membership_level = $_SESSION[$this->config['session']['name']]['user']['membership_level'];
            return $membership_level;
        }

        return $membership_level;
    }

    /**
     * Returns the membership level display name
     *
     * @return string           Membership level display name.
     */
    public function getMembershipLevelDisplayName()
    {

        $membership_level_display_name = '';
        $membership_level = $this->getMembershipLevel();

        if ($membership_level == 'Vollmitglied')
            $membership_level_display_name = $this->text->get('membership-level-display-name-full-member');
        elseif ($membership_level == 'Fördermitglied')
            $membership_level_display_name = $this->text->get('membership-level-display-name-support-member');
        elseif ($membership_level == 'Alumnimitglied')
            $membership_level_display_name = $this->text->get('membership-level-display-name-alumni-member');
        else
            $membership_level_display_name = $membership_level;


        return $membership_level_display_name;
    }

    /**
     * Gets the membership from date
     *
     * @return string           Membership from date.
     */
    public function getMembershipFrom()
    {

        $membership_from = '';

        if (isset($_SESSION[$this->config['session']['name']]['user']['membership_from'])){

            $membership_from = $_SESSION[$this->config['session']['name']]['user']['membership_from'];
            return $membership_from;
        }

        return $membership_from;
    }

    /**
     * Gets the salutation
     *
     * @return string           Salutation.
     */
    public function getSalutationPersonal()
    {
        if (isset($_SESSION[$this->config['session']['name']]['user']['salutation_personal'])){
            return $_SESSION[$this->config['session']['name']]['user']['salutation_personal'];
        }

        return '';
    }

    /**
 * Gets the birth date split up.
 *
 * @return array           Birthday split up.
 */
    public function getBirthdatePersonalSplit()
    {
        // Defualt values if not set
        $birthday_personal_split['day']   = date('j', time() );
        $birthday_personal_split['month'] = date('n', time() );
        $birthday_personal_split['year']  = date('Y', time() );


        if (isset($_SESSION[$this->config['session']['name']]['user']['birthdate_personal'])){

            $birthdate_split = explode('.', $_SESSION[$this->config['session']['name']]['user']['birthdate_personal']);

            // Set saved values
            if ( isset($birthdate_split[0]) )
                $birthday_personal_split['day']     = $birthdate_split[0];

            if ( isset($birthdate_split[1]) )
                $birthday_personal_split['month']   = $birthdate_split[1];

            if ( isset($birthdate_split[2]) )
                $birthday_personal_split['year']    = $birthdate_split[2];
        }

        return $birthday_personal_split;
    }

    /**
     * Returns the display name for the personal salutation
     *
     * @return string           Display name for personal salutation
     */
    public function getDisplayNameForSalutationPersonal()
    {
        $session_name = $this->config['session']['name'];

        if (isset($_SESSION[$session_name]['user']['salutation_personal'])){

           $salutation = $_SESSION[$session_name]['user']['salutation_personal'];

           if($salutation == 'Männlich')
               $displayNameForSalutationPersonal = $this->text->get('form-member-data-personal-salutation-mr');
           elseif($salutation == 'Weiblich')
               $displayNameForSalutationPersonal = $this->text->get('form-member-data-personal-salutation-mrs');
           else
               $displayNameForSalutationPersonal = $salutation;
        }

        return $displayNameForSalutationPersonal;
    }

    /**
     * Returns the personal email.
     *
     * @return string           Personal email.
     */
    public function getEmailPersonal()
    {
        $email_personal = false;

        $session_name = $this->config['session']['name'];

        if (isset($_SESSION[$session_name]['user']['email_personal'])){

           $email_personal = $_SESSION[$session_name]['user']['email_personal'];
        }

        return $email_personal;
    }

    /**
     * Returns the user role of the current user.
     *
     * @return string           User role.
     */
    public function getUserRole()
    {
        // Dummy user roles to test

        // possible options (not confirmed yet)
        // user_with_uploads
        // user
        // content_team

        $user_role = 'user_with_uploads';

        return $user_role;
    }

    /**
     * Returns true if the user is allowed to upload files
     *
     * @return boolean
     */
    public function hasFileUploadPermission()
    {
        $user_role                         = $this->getUserRole();
        $user_roles_with_upload_permission = explode(',', $this->config['user-roles-with-upload-permission']);

        if ( in_array($user_role, $user_roles_with_upload_permission ) ) return true;
        else                                                             return false;
    }

    /**
     * Returns true if the user belongs to the content team of the site
     *
     * @return boolean
     */
    public function belongsToContentTeam()
    {
        $user_role                              = $this->getUserRole();
        $user_roles_belonging_to_content_team   = explode(',', $this->config['user-roles-belonging-to-content-team']);

        if ( in_array($user_role, $user_roles_belonging_to_content_team ) ) return true;
        else                                                                return false;
    }

}