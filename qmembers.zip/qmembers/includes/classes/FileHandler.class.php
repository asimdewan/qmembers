<?php

namespace includes\classes;


/**
 * Processes all forms
 */
class FileHandler
{

    private $config_class;
    private $config;
    private $text;


    /**
     * Constructor function.
     * Gets configurations from Config class (to be used in this class).
     * Instantiates text class.
     */
    public function __construct()
    {
        $this->config_class = new Config;
        $this->config = $this->config_class->getAll();

        $this->text = new Text;

        $this-> createFileDirectories();
    }

    private function createFileDirectories(){
        $file_dir_for_modul          = QMEMBERS_PATH_FILE_UPLOADS;
        $file_dir_for_profile_images = QMEMBERS_PATH_PROFILE_IMAGES;


        if (!file_exists(QMEMBERS_PATH_FILE_UPLOADS)) {
            mkdir(QMEMBERS_PATH_FILE_UPLOADS, 0755, true);
        }

        if (!file_exists($file_dir_for_profile_images)) {
            mkdir($file_dir_for_profile_images, 0755, true);
        }

    }

    public function savePersonalPicture($files){

        $user = new User;
        $result = array();

        if (empty($files['picture_personal'])) {
            $result['error'] = true;
            $result['value'] = $this->text->get('filehandler--error-during-image-upload') . PHP_EOL;
            return $result['value'];
        }

        // saved cropped image
        if (!empty($files['picture_personal'])) {

            // Delete old file
            $resultExistingPicture = $user->getPersonalPicture('server_path');
            if (!empty($resultExistingPicture['value'])) {
                unlink($resultExistingPicture['value']);
            }


            $name  = $user->getMemberId() . '-' . hash('sha256', uniqid() ) . '.png';
            $data = $files['picture_personal'];

            list($type, $data) = explode(';', $data);
            list(, $data)      = explode(',', $data);
            $data = base64_decode($data);

            $target_file = QMEMBERS_PATH_PROFILE_IMAGES . $name;

            $success = file_put_contents($target_file, $data);
            if (!$success){
                $result['error'] = true;
                $result['value'] = $this->text->get('filehandler--error-during-image-upload') . PHP_EOL;
                return $result['value'];
            }
            $result['image_url'] = QMEMBERS_PATH_URL_PROFILE_IMAGES . basename($target_file);
        }

        // save original image
        if (!empty($files['original_picture_personal'])) {

            // Delete old file
            $resultExistingPicture = $user->getPersonalPicture('server_path', true);
            if (!empty($resultExistingPicture['value'])) {
                unlink($resultExistingPicture['value']);
            }


            $name  = $user->getMemberId() . '-' . hash('sha256', uniqid() ) . '.png';
            $data = $files['original_picture_personal'];

            list($type, $data) = explode(';', $data);
            list(, $data)      = explode(',', $data);
            $data = base64_decode($data);

            $original_target_file = QMEMBERS_PATH_PROFILE_IMAGES . $name;

            $success = file_put_contents($original_target_file, $data);
            if (!$success){
                $result['error'] = true;
                $result['value'] = $this->text->get('filehandler--error-during-image-upload') . PHP_EOL;
                return $result['value'];
            }
            $result['original_image_url'] = QMEMBERS_PATH_URL_PROFILE_IMAGES . basename($original_target_file);
        } else {
            // needs to be set, or will be null in the database, because if it is the same image, it will not be transmitted
            $result['original_image_url'] = $user->getPersonalPicture('', true);
        }

        return $result;
    }
}
