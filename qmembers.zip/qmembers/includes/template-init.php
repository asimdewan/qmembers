<?php

use includes\classes\Text;
use includes\classes\User;

global $qmembers_config;

$qmembers_text = new Text;
$qmembers_user = new User;


if ( isset($qmembers_config['php-var-to-js'])){
   $php_var_to_js = json_encode($qmembers_config['php-var-to-js']);

   echo '<div id="qmembers-js-vars-workaround" data-json=\'' . $php_var_to_js . '\'></div>';
}

