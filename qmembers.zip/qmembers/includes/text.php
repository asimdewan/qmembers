<?php
$qmembers_text = array();

// Login
$qmembers_text['form-login-submit-button']['text']                        = 'Login';

$qmembers_text['validation-info-example']['text']                         = 'Dieses Feld darf max. %1 Zeichen enthalten';
$qmembers_text['validation-info-example']['vars'][1]                      = $qmembers_config['form']['member-data-personal']['first_name_personal']['max_len'];

$qmembers_text['validation--no-validation-rules-set']['text']             = 'Für dieses Formular wurden keine Validierungsregeln festgelegt. Bitte kontaktieren Sie den Administrator.';
$qmembers_text['validation--email-failed']['text']                        = 'Diese E-Mail ist nicht gültig.';
$qmembers_text['validation--password-failed']['text']                     = 'Ihre Logindaten sind nicht korrekt.';


// Header
$qmembers_text['header-default--bdp-member-area']['text']                 = 'BDP MITGLIEDERBEREICH';
$qmembers_text['header-default--member-id']['text']                       = 'Mitgliedsnr';
$qmembers_text['header-default--logout']['text']                          = 'Logout';


// Login
$qmembers_text['form-login-submit-error']['text']                         = 'Während des Logins ist ein Fehler aufgetreten. Bitte versuchen Sie es noch einmal. Sollte das Problem weiterhin bestehen, dann kontaktieren Sie uns bitte.';
$qmembers_text['form-login-submit-wrong-login-data']['text']              = 'Ihre Logindaten sind nicht korrekt.';
$qmembers_text['form-login-password-recover-button']['text']              = 'Passwort vergessen';
$qmembers_text['user--authenticate-api-error']['text']                    = 'Während des Login-Vorgangs ist ein Fehler mit der Datenbankkommunikation aufgetreten. Bitte versuchen Sie es noch einmal. Sollte das Problem weiterhin bestehen, dann kontaktieren Sie uns bitte.';
$qmembers_text['membership-level-excluded-from-login']['text']            = 'Mit ihrem Mitgliedschaftstyp können Sie sich nicht in das Portal einloggen.';


// Logout error
$qmembers_text['user--logout-error-session-name-not-in-config']['text']   = 'Während des Logout-Vorgangs ist ein Fehler aufgetreten. Bitte versuchen Sie es noch einmal. Sollte das Problem weiterhin bestehen, dann kontaktieren Sie uns bitte.';


// Password recovery
$qmembers_text['user--password-recovery-email-not-found']['text']         = 'Diese E-Mail ist nicht registriert.';
$qmembers_text['user--email-password-recover-mailtext']['text']           = '

Sehr geehrtes BdP-Mitglied

für den Mitgliederbereich des BdP wurde die Wiederherstellung Ihres Passworts angefordert.
Bitte klicken Sie auf den folgenden Link, um ihr Passwort wiederherzustellen: 
 ___link_hash___
 
 Wenn Sie Ihr Passwort nicht wiederherstellen möchten, dann ignorieren Sie bitte diese E-Mail.';


// Form labels
$qmembers_text['email']['text']                                           = 'E-Mail';
$qmembers_text['password']['text']                                        = 'Passwort';


// Navigation tabs
$qmembers_text['navigation-member-data-personal']['text']                 = 'Persönliche Daten';
$qmembers_text['navigation-member-data-professional']['text']             = 'Berufliche Daten';
$qmembers_text['navigation-member-data-membership']['text']               = 'Mitgliedschaft';
$qmembers_text['navigation-member-data-settings']['text']                 = 'Einstellungen';

$qmembers_text['navigation-groups-all']['text']                           = 'Alle Gruppen';
$qmembers_text['navigation-groups-professional']['text']                  = 'Fachgruppen';
$qmembers_text['navigation-groups-national']['text']                      = 'Landesgruppen';
$qmembers_text['navigation-groups-personal']['text']                      = 'Meine Gruppen';


// Empty field
$qmembers_text['empty_field']['text']                                     = '----------';


// Personal Data
$qmembers_text['form-member-data-personal-salutation-mr']['text']         = 'Herr';
$qmembers_text['form-member-data-personal-salutation-mrs']['text']        = 'Frau';

$qmembers_text['form-member-data-personal-submit-button']['text']         = 'Speichern';
$qmembers_text['form-member-data-personal-cancel-button']['text']         = 'Abbrechen';
$qmembers_text['member-data-personal-edit-button']['text']                = 'Daten bearbeiten';

$qmembers_text['form-member-data-personal-submit-success']['text']        = 'Ihre Daten wurden erfolgreich gespeichert!';
$qmembers_text['form-member-data-personal-submit-error']['text']          = 'Ein Fehler ist aufgetreten. Bitte versuchen Sie es noch einmal. Sollte das Problem weiterhin bestehen, dann kontaktieren Sie uns bitte.';
$qmembers_text['form-member-data-personal-submit-not-saved']['text']      = 'Persönliche Daten nicht gespeichert.';

$qmembers_text['form-member-data-personal-explanation']['text']           = 'In diesem Bereich haben Sie die Möglichkeit Ihre persönlichen Angaben zur Mitgliedschaft zu bearbeiten. Die optimale Auflösung für Ihr Profilbild beträgt 1024x1024px, idealerweise im Seitenverhältnis 1:1. Mögliche Bildformate sind PNG und JPG. Änderungen des Passworts können Sie in den Einstellungen vornehmen.';
$qmembers_text['info_name_change']['text']                                = 'Bei Namensänderung schicken Sie uns bitte eine E-mail';
$qmembers_text['form-member-data-personal-result']['text']                = 'Ihre Daten wurden erfolgreich gespeichert!';
$qmembers_text['form-member-data-personal-error']['text']                 = 'Dieses Feld muss ausgefüllt werden';

$qmembers_text['mandatory']['text']                                       = 'Pflichtfelder';
$qmembers_text['mandatory_sign']['text']                                  = '*';

$qmembers_text['name-of-month-1']['text']                                 = 'Januar';
$qmembers_text['name-of-month-2']['text']                                 = 'Februar';
$qmembers_text['name-of-month-3']['text']                                 = 'März';
$qmembers_text['name-of-month-4']['text']                                 = 'April';
$qmembers_text['name-of-month-5']['text']                                 = 'Mai';
$qmembers_text['name-of-month-6']['text']                                 = 'Juni';
$qmembers_text['name-of-month-7']['text']                                 = 'Juli';
$qmembers_text['name-of-month-8']['text']                                 = 'August';
$qmembers_text['name-of-month-9']['text']                                 = 'September';
$qmembers_text['name-of-month-10']['text']                                = 'Oktober';
$qmembers_text['name-of-month-11']['text']                                = 'November';
$qmembers_text['name-of-month-12']['text']                                = 'Dezember';


// Personal picture - Validation
$qmembers_text['validation--personal-image-size-failed']['text']          = 'Ihr Bild darf max. %1 MB groß sein.';
$qmembers_text['validation--personal-image-size-failed']['vars'][1]       = $qmembers_config['max-image-size-picture-personal'];

$qmembers_text['validation--personal-image-type-failed']['text']          = 'Sie können nur die folgenden Bildtypen verwenden: %1';
$qmembers_text['validation--personal-image-type-failed']['vars'][1]       = $qmembers_config['allowed-image-types-picture-personal'];
$qmembers_text['no-personal-picture-sent-via-ajax']['text']               = 'Es wurde kein Bild übermittelt. Bitte versuchen Sie es noch einmal.';


// File Handler
$qmembers_text['filehandler--file-does-not-work']['text']                 = 'Dieses Bild kann leider nicht als Profilbild verwendet werden. Bitte wählen Sie ein anderes Bild aus.';
$qmembers_text['filehandler--error-during-image-upload']['text']          = 'Während des Uploads des Bildes ist ein Fehler aufgetreten. Das Bild konnte nicht gespeichert werden. Bitte versuchen Sie es noch einmal.';


// Form labels - Personal data
$qmembers_text['private']['text']                                         = '(Privat)';
$qmembers_text['picture_personal']['text']                                = 'Bild ändern';
$qmembers_text['picture_personal-submit-button']['text']                  = 'Bild speichern';
$qmembers_text['picture_personal-upload-info']['text']                    = 'Mit dem Upload Ihres Fotos stimmen Sie der Nutzung desselben für die BdP-Sprechercard zu.';
$qmembers_text['salutation_personal']['text']                             = 'Anrede';
$qmembers_text['title_personal']['text']                                  = 'Titel';
$qmembers_text['first_name_personal']['text']                             = 'Vorname';
$qmembers_text['last_name_personal']['text']                              = 'Nachname';
$qmembers_text['birthdate_personal']['text']                              = 'Geburtstag';
$qmembers_text['street_number_personal']['text']                          = 'Straße/Hausnummer';
$qmembers_text['line_personal']['text']                                   = 'Zuzeile (c/o)';
$qmembers_text['zip_personal']['text']                                    = 'PLZ';
$qmembers_text['city_personal']['text']                                   = 'Ort';
$qmembers_text['state_personal']['text']                                  = 'Bundesland';
$qmembers_text['state_personal_choose']['text']                           = 'Bitte wählen';
$qmembers_text['country_personal']['text']                                = 'Land';
$qmembers_text['country_personal_choose']['text']                         = 'Bitte wählen';
$qmembers_text['email_personal']['text']                                  = 'E-Mail-Adresse';
$qmembers_text['phone_personal']['text']                                  = 'Telefon';
$qmembers_text['xing_personal']['text']                                   = 'Xing Profil';
$qmembers_text['linkedin_personal']['text']                               = 'LinkedIn Profil';


// Professional Data
$qmembers_text['form-member-data-professional-submit-button']['text']     = 'Speichern';
$qmembers_text['form-member-data-professional-cancel-button']['text']     = 'Abbrechen';
$qmembers_text['member-data-professional-edit-button']['text']            = 'Daten bearbeiten';

$qmembers_text['form-member-data-professional-submit-success']['text']    = 'Ihre Daten wurden erfolgreich gespeichert!';
$qmembers_text['form-member-data-professional-submit-error']['text']      = 'Ein Fehler ist aufgetreten. Bitte versuchen Sie es noch einmal. Sollte das Problem weiterhin bestehen, dann kontaktieren Sie uns bitte.';
$qmembers_text['form-member-data-professional-submit-not-saved']['text']  = 'Berufliche Daten nicht gespeichert.';

$qmembers_text['form-member-data-professional-explanation']['text']       = 'In diesem Bereich haben Sie die Möglichkeit Ihre beruflichen Angaben zur Mitgliedschaft zu bearbeiten. Angaben zur Rechnungs- und Lieferadresse finden Sie unter „Mitgliedschaft”.';
$qmembers_text['form-member-data-professional-result']['text']            = 'Ihre Daten wurden erfolgreich gespeichert!';
$qmembers_text['form-member-data-professional-error']['text']             = 'Dieses Feld muss ausgefüllt werden';


// Form labels - Professional data
$qmembers_text['professional']['text']                                    = '(Beruflich)';
$qmembers_text['company_professional']['text']                            = 'Firma / Organisation';
$qmembers_text['function_professional']['text']                           = 'Funktion/Stellung';
$qmembers_text['department_professional']['text']                         = 'Abteilung';
$qmembers_text['office_number_professional']['text']                      = 'Büronummer (Raumnummer/Zustellnummer)';
$qmembers_text['street_number_professional']['text']                      = 'Straße/Hausnummer';
$qmembers_text['line_professional']['text']                               = 'Zuzeile (PF)';
$qmembers_text['zip_professional']['text']                                = 'PLZ';
$qmembers_text['city_professional']['text']                               = 'Ort';
$qmembers_text['state_professional']['text']                              = 'Bundesland';
$qmembers_text['state_professional_choose']['text']                       = 'Bitte wählen';
$qmembers_text['country_professional']['text']                            = 'Land';
$qmembers_text['country_professional_choose']['text']                     = 'Bitte wählen';
$qmembers_text['email_professional']['text']                              = 'E-Mail';
$qmembers_text['phone_professional']['text']                              = 'Telefon';
$qmembers_text['vat_professional']['text']                                = 'Umsatzsteuer-Identifikationsnummer';
$qmembers_text['business_professional']['text']                           = 'Branche';
$qmembers_text['business_professional_choose']['text']                    = 'Bitte wählen';


// Saving related data when personal or professional data is being saved
$qmembers_text['save-related-data-error-primary-email']['text']             = 'Ein Fehler ist aufgetreten. Bitte speichern Sie auch Ihre primäre E-Mail unter Mitgliedschaft.';
$qmembers_text['save-related-data-error-billing-address']['text']           = 'Ein Fehler ist aufgetreten. Bitte speichern Sie auch Ihre Rechnungsadresse unter Mitgliedschaft.';
$qmembers_text['save-related-data-error-delivery-address']['text']          = 'Ein Fehler ist aufgetreten. Bitte speichern Sie auch Ihre Lieferadresse unter Mitgliedschaft.';
$qmembers_text['save-related-data-error-precheck-primary-email']['text']    = 'Bitte speichern Sie zuerst alle Daten unter Mitgliedschaft.';
$qmembers_text['save-related-data-error-precheck-billing-address']['text']  = 'Bitte speichern Sie zuerst alle Daten unter Mitgliedschaft.';
$qmembers_text['save-related-data-error-precheck-delivery-address']['text'] = 'Bitte speichern Sie zuerst alle Daten unter Mitgliedschaft.';


// Membership Data
$qmembers_text['form-member-data-membership-submit-button']['text']       = 'Speichern';
$qmembers_text['form-member-data-membership-cancel-button']['text']       = 'Abbrechen';
$qmembers_text['form-member-data-membership-termination-button']['text']  = 'Mitgliedschaft kündigen';

$qmembers_text['form-member-data-membership-submit-success']['text']      = 'Ihre Daten wurden erfolgreich gespeichert!';
$qmembers_text['form-member-data-membership-submit-error']['text']        = 'Ein Fehler ist aufgetreten. Bitte versuchen Sie es noch einmal. Sollte das Problem weiterhin bestehen, dann kontaktieren Sie uns bitte.';
$qmembers_text['form-member-data-membership-submit-not-saved']['text']    = 'Mitgliedschaft Daten nicht gespeichert.';

$qmembers_text['form-member-data-membership-explanation']['text']         = 'In diesem Bereich haben Sie die Möglichkeit Ihre Rechnungs- und Lieferadresse für die Mitgliedschaft anzugeben. Zentrale/Abweichende Buchhaltungsanschriften können Sie unter der Option „andere Adresse” angeben.';
$qmembers_text['form-member-data-membership-result']['text']              = 'Ihre Daten wurden erfolgreich gespeichert!';
$qmembers_text['form-member-data-membership-error']['text']               = 'Dieses Feld muss ausgefüllt werden';


// Form labels  - Membership data

$qmembers_text['prim_email_membership']['text']                           = 'Primäre E-Mail-Adresse';
$qmembers_text['prim_email_membership_descr']['text']                     = 'Mit welcher E-Mail-Adresse möchten Sie kontaktiert werden?';
$qmembers_text['prim_email_membership_personal']['text']                  = 'Persönliche E-Mail-Adresse';
$qmembers_text['prim_email_membership_business']['text']                  = 'Berufliche E-Mail-Adresse';
$qmembers_text['billing_address_membership']['text']                      = 'Rechnungsadresse';
$qmembers_text['billing_private_membership']['text']                      = 'Privatanschrift';
$qmembers_text['billing_company_membership']['text']                      = 'Firmenanschrift';
$qmembers_text['billing_other_membership']['text']                        = 'andere Adresse';
$qmembers_text['billing_data_saved_successfully']['text']                 = 'Ihre Daten wurden erfolgreich gespeichert!';
$qmembers_text['title_membership']['text']                                = 'Titel';
$qmembers_text['first_name_membership']['text']                           = 'Vorname';
$qmembers_text['last_name_membership']['text']                            = 'Nachname';
$qmembers_text['company_membership']['text']                              = 'Firma / Organisation';
$qmembers_text['department_membership']['text']                           = 'Abteilung';
$qmembers_text['office_number_membership']['text']                        = 'Büronummer (Raumnummer/Zustellnummer)';
$qmembers_text['street_number_membership']['text']                        = 'Straße/Hausnummer';
$qmembers_text['line_membership']['text']                                 = 'Zuzeile (PF)';
$qmembers_text['zip_membership']['text']                                  = 'PLZ';
$qmembers_text['city_membership']['text']                                 = 'Ort';
$qmembers_text['state_membership']['text']                                = 'Bundesland';
$qmembers_text['state_membership_choose']['text']                         = 'Bitte wählen';
$qmembers_text['country_membership']['text']                              = 'Land';
$qmembers_text['country_membership_choose']['text']                       = 'Bitte wählen';
$qmembers_text['email_membership']['text']                                = 'E-Mail';
$qmembers_text['phone_membership']['text']                                = 'Telefon';
$qmembers_text['press_magazine_membership']['text']                       = 'Pressesprecher Magazin';
$qmembers_text['press_deliver_membership']['text']                        = 'Lieferung erfolgt an';
$qmembers_text['press_private_membership']['text']                        = 'Privatanschrift';
$qmembers_text['press_company_membership']['text']                        = 'Firmenanschrift';
$qmembers_text['changes_label_membership']['text']                        = 'Weitere Anliegen zur Mitgliedschaft und Datenänderungen';
$qmembers_text['changes_info_membership']['text']                         = 'Für alle anderen Anliegen E-mail an %1';
$qmembers_text['changes_info_membership']['vars'][1]                      = $qmembers_config['email-membership-services'];
$qmembers_text['termination_membership']['text']                          = 'Mitgliedschaft kündigen';

// Termination text if no form will be displayed
$qmembers_text['membership-termination-info-text-instead-of-termination-form']['text']      = 'Wenn Sie Ihre Mitgliedschaft kündigen möchten, senden Sie die Kündigung bitte schriftlich an: <br/><br/> [ADRESSE BITTE ÜBERMITTELN].';

// Termination Data
$qmembers_text['form-member-data-termination-submit-button']['text']      = 'Senden';
$qmembers_text['form-member-data-termination-cancel-button']['text']      = 'Abbrechen';

$qmembers_text['form-member-data-termination-submit-success']['text']     = 'Ihre Daten wurden erfolgreich gespeichert!';
$qmembers_text['form-member-data-termination-submit-error']['text']       = 'Ein Fehler ist aufgetreten. Bitte versuchen Sie es noch einmal. Sollte das Problem weiterhin bestehen, dann kontaktieren Sie uns bitte.';
$qmembers_text['form-member-data-termination-submit-not-saved']['text']   = 'Ihre Kündigung konnte nicht gespeichert werden.';
$qmembers_text['form-member-data-termination-submit-ok-but-termination-date-not-calc']['text']   = 'Ihre Kündigung wurde gespeichert, allerdings gab es ein Problem bei der Ermittlung des Enddatums Ihrer Mitgliedschaft. Bitte setzen Sie sich unbedingt mit uns in Verbindung, damit wir das Enddatum manuell eintragen können. Vielen Dank!';

$qmembers_text['form-member-data-termination-title']['text']              = 'Kündigung der Mitgliedschaft';
$qmembers_text['form-member-data-termination-result']['text']             = 'Ihre Daten wurden erfolgreich gespeichert!';
$qmembers_text['form-member-data-termination-error']['text']              = 'Dieses Feld muss ausgefüllt werden.';
$qmembers_text['membership-canceled-info']['text']                        = 'Sie haben die Mitgliedschaft bereits gekündigt.';



$qmembers_text['user--email-membership-termination-mailtext']['text']     = '

Ein Mitglied hat das Kündigungsformular des Mitgliederbereichs (Self-Service-Portal) ausgefüllt.

Mitglieds-ID: 
___member_id___

Austrittsgrund: 
___reason_termination___

Nachricht: 
___message_termination___
';


// Form labels - Termination
$qmembers_text['membership_n_termination']['text']                        = 'Mitgliedsnr.:';
$qmembers_text['membership_level']['text']                                = 'Mitgliedsart:';
$qmembers_text['membership_from']['text']                                 = 'Mitglied seit:';
$qmembers_text['membership_canceled_date']['text']                        = 'Gekündigt am:';
$qmembers_text['membership_until']['text']                                = 'Mitglied bis:';
$qmembers_text['title_text_termination']['text']                          = 'Kündigung';
$qmembers_text['text_termination']['text']                                = 'Sehr geehrte Damen und Herren, hiermit kündige ich meine Mitgliedschaft unter Einhaltung der Kündigungsfrist von sechs Monaten zum Jahresende im Bundesverband deutscher Pressesprecher. Ich bitte um Übersendung einer Kündigungsbestätigung per E-Mail. Mit freundlichen Grüßen!';
$qmembers_text['reason_termination']['text']                              = 'Austrittsgrund';
$qmembers_text['reason_0_termination']['text']                            = 'Bitte Wählen';
$qmembers_text['reason_1_termination']['text']                            = 'Lipsum Dotor Sit 1';
$qmembers_text['reason_2_termination']['text']                            = 'Lipsum Dotor Sit 2';
$qmembers_text['reason_3_termination']['text']                            = 'Lipsum Dotor Sit 3';
$qmembers_text['message_termination']['text']                             = 'Nachricht';
$qmembers_text['disclaimer_termination']['text']                          = 'Ich akzeptiere den Disclaimer';
$qmembers_text['text_disclaimer_termination']['text']                     = 'Duis blandit etit vel ipsum ultricies, eteifend egestas diam luctus. Morbi euismod vetit pharetra odio sollicitudin. vel pharetra quam omare. Donec quis lacus eget augue sodales eleifend ac ut eros. Nulla quis eleifend nibh. ac convallis mi. Donec volutpat purus nec uma malesuada. quis viverra lorem tempus. In eget justo eget eros dictum cursus. Fusce accumsan interdum imperdiet. In condimentum tincidunt magna porta volutpat.';


// Settings Data
$qmembers_text['form-member-data-settings-submit-button']['text']         = 'Passwort ändern';
$qmembers_text['form-member-data-settings-cancel-button']['text']         = 'Abbrechen';

$qmembers_text['form-member-data-settings-submit-success']['text']        = 'Ihre Daten wurden erfolgreich gespeichert!';
$qmembers_text['form-member-data-settings-submit-error']['text']          = 'Ein Fehler ist aufgetreten. Bitte versuchen Sie es noch einmal. Sollte das Problem weiterhin bestehen, dann kontaktieren Sie uns bitte.';
$qmembers_text['form-member-data-settings-submit-not-saved']['text']      = 'Einstellungen Daten nicht gespeichert.';

$qmembers_text['form-member-data-settings-explanation']['text']           = 'In diesem Bereich haben Sie die Möglichkeit Ihr Passwort zu ändern.';
$qmembers_text['form-member-data-settings-result']['text']                = 'Ihre Daten wurden erfolgreich gespeichert!';
$qmembers_text['form-member-data-settings-error']['text']                 = 'Dieses Feld muss ausgefüllt werden';
$qmembers_text['form-member-data-settings-error-password']['text']        = 'Ihre Passwort ist nicht korrekt.';
$qmembers_text['form-member-data-settings-error-mismatch']['text']        = 'Die Passwörter müssen übereinstimmen';


// Form labels
$qmembers_text['title_password_settings']['text']                         = 'Passwort ändern';
$qmembers_text['password_old_settings']['text']                           = 'Altes Passwort';
$qmembers_text['password_new_settings']['text']                           = 'Neues Passwort';
$qmembers_text['password_new_repeat_settings']['text']                    = 'Neues Passwort wiederholen';


// Memberlist Data
$qmembers_text['form-member-data-memberlist-submit-button']['text']       = 'Suchen';

$qmembers_text['form-member-data-memberlist-submit-success']['text']      = '';
$qmembers_text['form-member-data-memberlist-submit-error']['text']        = 'Ein Fehler ist aufgetreten. Bitte versuchen Sie es noch einmal. Sollte das Problem weiterhin bestehen, dann kontaktieren Sie uns bitte.';
$qmembers_text['form-member-data-memberlist-submit-not-saved']['text']    = 'Nicht gespeichert.';


// Form labels
$qmembers_text['search_memberlist']['text']                               = 'Mitglied suchen';
$qmembers_text['members_memberlist']['text']                              = 'Mitglieder';
$qmembers_text['members_memberlist-singular']['text']                     = 'Mitglied';
$qmembers_text['contact_memberlist']['text']                              = 'Kontaktieren';


// Password Recover Data
$qmembers_text['form-password-recover-submit-button']['text']             = 'Senden';
$qmembers_text['form-password-recover-back-button']['text']               = 'Zurück';
$qmembers_text['form-password-recover-submit-success']['text']            = 'Wir haben Ihnen eine E-Mail mit einem Wiederherstellungslink gesendet. Bitte schauen Sie auch in Ihrem Spam-Ordner nach.';
$qmembers_text['form-password-recover-submit-error']['text']              = 'Ein Fehler ist aufgetreten. Bitte versuchen Sie es noch einmal. Sollte das Problem weiterhin bestehen, dann kontaktieren Sie uns bitte.';
$qmembers_text['form-password-recover-submit-not-saved']['text']          = 'Diese E-Mail ist nicht gültig.';


// Password Change Data
$qmembers_text['form-password-change-submit-button']['text']              = 'Senden';
$qmembers_text['form-password-change-submit-success']['text']             = 'Ihre Daten wurden erfolgreich gespeichert!';
$qmembers_text['form-password-change-submit-error']['text']               = 'Ein Fehler ist aufgetreten. Bitte versuchen Sie es noch einmal. Sollte das Problem weiterhin bestehen, dann kontaktieren Sie uns bitte.';
$qmembers_text['form-password-change-submit-not-saved']['text']           = 'Diese Passwort ist nicht gültig.';
$qmembers_text['form-password-change-back-button']['text']                = 'Abbrechen';
$qmembers_text['user--form-password-change-hash-link-expired']['text']    = 'Der Link zur Wiederherstellung des Passwords ist bereits abgelaufen. Bitte fordern Sie die Passwort-Wiederherstellung erneut an.';


// Form labels
$qmembers_text['change_password']['text']                                 = 'Neues Passwort';
$qmembers_text['repeat_change_password']['text']                          = 'Neues Passwort wiederholen';


// Groups Data
$qmembers_text['new_group_groups']['text']                                = 'Neue Gruppe erstellen +';
$qmembers_text['read-more']['text']                                       = 'Mehr lesen';

// Form labels
$qmembers_text['join_group_groups']['text']                               = 'Gruppe beitreten';
$qmembers_text['belongs_group_groups']['text']                            = 'Sie sind Mitglied dieser Gruppe';
$qmembers_text['leave_group_groups']['text']                              = 'Aus Gruppe austreten';


// Sites, where page content is also displayed on the normal website
$qmembers_text['node-content-not-found']['text']                          = 'Der Inhalt dieser Seite konnte nicht gefunden werden.';


// Service provider
$qmembers_text['search-service-provider-list']['text']                    = 'Dienstleister suchen';
$qmembers_text['service-provider-info-text']['text']                      = '';
$qmembers_text['service-provider-filter1-label']['text']                  = 'Standort';
$qmembers_text['service-provider-filter1-placeholder']['text']            = 'Standort wählen (Stadt, PLZ)';
$qmembers_text['service-provider-filter2-label']['text']                  = 'Anfangsbuchstaben';
$qmembers_text['service-provider-count-text-plural']['text']              = 'Mitglieder';
$qmembers_text['service-provider-count-text-singular']['text']            = 'Mitglied';
$qmembers_text['error-service-provider-list-not-available']['text']       = 'Die Liste der Dienstleister konnte leider nicht abgerufen werden. Bitte versuchen Sie es zu einem späteren Zeitpunkt noch einmal.';
$qmembers_text['reset-search']['text']                                    = 'Zurücksetzen';
$qmembers_text['service-provider-no-results']['text']                     = 'Ihre Suche lieferte keine Ergebnisse.';


// Corporate benefits
$qmembers_text['node-corporate-benefits--member-link-could-not-be-generated']['text']   = 'Der Mitglieder-Link zum Corporate-Benefits-Portal konnte leider nicht generiert werden.';
$qmembers_text['node-corporate-benefits--button-to-corporate-benefits-text']['text']    = 'zu Corporate Benefits';


// VALIDATION MESSAGES
$qmembers_text['validation-failed']['text']                               = 'Dieses Feld muss korrekt ausgefüllt werden.';

$qmembers_text['validation--email-failed']['text']                        = 'Bitte geben Sie eine gültige E-Mail-Adresse ein.';

$qmembers_text['validation--password-failed']['text']                     = ''; // No message needed.

$qmembers_text['validation--title_personal-failed']['text']               = 'Bitte geben Sie max. 50 Zeichen ein.';

$qmembers_text['validation--first_name_personal-failed']['text']          = 'Dieses Feld wird benötigt. Bitte geben Sie max. 50 Zeichen ein.';

$qmembers_text['validation--last_name_personal-failed']['text']           = 'Dieses Feld wird benötigt. Bitte geben Sie max. 50 Zeichen ein.';

$qmembers_text['validation--street_number_personal-failed']['text']       = 'Dieses Feld wird benötigt. Bitte geben Sie max. 255 Zeichen ein.';

$qmembers_text['validation--line_personal-failed']['text']                = 'Bitte geben Sie max. 255 Zeichen ein.';

$qmembers_text['validation--zip_personal-failed']['text']                 = 'Dieses Feld wird benötigt. Bitte geben Sie max. 5 Zeichen ein.';

$qmembers_text['validation--city_personal-failed']['text']                = 'Dieses Feld wird benötigt. Bitte geben Sie max. 50 Zeichen ein.';

$qmembers_text['validation--state_personal-failed']['text']               = 'Bitte wählen Sie ein Bundesland.';

$qmembers_text['validation--country_personal-failed']['text']             = 'Bitte wählen Sie ein Land.';

$qmembers_text['validation--email_personal-failed']['text']               = 'Bitte geben Sie eine gültige E-Mail-Adresse ein.';

$qmembers_text['validation--phone_personal-failed']['text']               = 'Bitte geben Sie die Telefonnummer im internationalen Format mit + am Anfang an, z.B. +49301234567';

$qmembers_text['validation--xing_personal-failed']['text']                = 'Bitte verwenden Sie eine gültige URL mit max. 255 Zeichen.';

$qmembers_text['validation--linkedin_personal-failed']['text']            = 'Bitte verwenden Sie eine gültige URL mit max. 255 Zeichen.';

$qmembers_text['validation--company_professional-failed']['text']         = 'Dieses Feld wird benötigt. Bitte geben Sie max. 255 Zeichen ein.';

$qmembers_text['validation--function_professional-failed']['text']        = 'Dieses Feld wird benötigt. Bitte geben Sie max. 255 Zeichen ein.';

$qmembers_text['validation--department_professional-failed']['text']      = 'Bitte geben Sie max. 255 Zeichen ein.';

$qmembers_text['validation--office_number_professional-failed']['text']   = 'Bitte geben Sie max. 255 Zeichen ein.';

$qmembers_text['validation--street_number_professional-failed']['text']   = 'Dieses Feld wird benötigt. Bitte geben Sie max. 255 Zeichen ein.';

$qmembers_text['validation--line_professional-failed']['text']            = 'Bitte geben Sie max. 255  Zeichen ein.';

$qmembers_text['validation--zip_professional-failed']['text']             = 'Dieses Feld wird benötigt. Bitte geben Sie max. 5 Zeichen ein.';

$qmembers_text['validation--city_professional-failed']['text']            = 'Dieses Feld wird benötigt. Bitte geben Sie max. 255 Zeichen ein.';

$qmembers_text['validation--state_professional-failed']['text']           = 'Bitte wählen Sie ein Bundesland.';

$qmembers_text['validation--country_professional-failed']['text']         = 'Bitte geben Sie max. 255 Zeichen ein.';

$qmembers_text['validation--email_professional-failed']['text']           = 'Bitte geben Sie eine gültige E-Mail-Adresse ein.';

$qmembers_text['validation--professional-email-cannot-be-empty-if-no-personal-email-is-set']['text']  = 'Sie können diese E-Mail nicht löschen, wenn keine persönliche E-Mail angegeben ist. Wir benötigen mindestens eine E-Mail für den Login.';

$qmembers_text['validation--phone_professional-failed']['text']           = 'Bitte geben Sie die Telefonnummer im internationalen Format mit + am Anfang an, z.B. +49301234567';

$qmembers_text['validation--vat_professional-failed']['text']             = 'Bitte geben Sie max. 50 Zeichen ein.';

$qmembers_text['validation--business_professional-failed']['text']        = 'Bitte geben Sie max. 255 Zeichen ein.';

$qmembers_text['validation--prim_email_membership-failed']['text']        = 'Bitte wählen.';

$qmembers_text['validation--billing_address_membership-failed']['text']   = 'Bitte wählen.';

$qmembers_text['validation--title_membership-failed']['text']             = 'Bitte geben Sie max. 50 Zeichen ein.';

$qmembers_text['validation--first_name_membership-failed']['text']        = 'Dieses Feld wird benötigt. Bitte geben Sie max. 50 Zeichen ein.';

$qmembers_text['validation--last_name_membership-failed']['text']         = 'Dieses Feld wird benötigt. Bitte geben Sie max. 50 Zeichen ein.';

$qmembers_text['validation--company_membership-failed']['text']           = 'Dieses Feld wird benötigt. Bitte geben Sie max. 255 Zeichen ein.';

$qmembers_text['validation--department_membership-failed']['text']        = 'Bitte geben Sie max. 255 Zeichen ein.';

$qmembers_text['validation--office_number_membership-failed']['text']     = 'Bitte geben Sie max. 255 Zeichen ein.';

$qmembers_text['validation--street_number_membership-failed']['text']     = 'Dieses Feld wird benötigt. Bitte geben Sie max. 255 Zeichen ein.';

$qmembers_text['validation--line_membership-failed']['text']              = 'Bitte geben Sie max. 255 Zeichen ein.';

$qmembers_text['validation--zip_membership-failed']['text']               = 'Dieses Feld wird benötigt. Bitte geben Sie max. 5 Zeichen ein.';

$qmembers_text['validation--city_membership-failed']['text']              = 'Dieses Feld wird benötigt. Bitte geben Sie max. 255 Zeichen ein.';

$qmembers_text['validation--state_membership-failed']['text']             = 'Bitte wählen Sie ein Bundesland.';

$qmembers_text['validation--country_membership-failed']['text']           = 'Bitte geben Sie max. 50 Zeichen ein.';

$qmembers_text['validation--email_membership-failed']['text']             = 'Bitte geben Sie eine gültige E-Mail-Adresse ein.';

$qmembers_text['validation--phone_membership-failed']['text']             = 'Bitte geben Sie die Telefonnummer im internationalen Format mit + am Anfang an, z.B. +49301234567';

$qmembers_text['validation--press_magazine_membership-failed']['text']    = 'Bitte wählen.';

$qmembers_text['validation--reason_termination-failed']['text']           = 'Bitte wählen.';

$qmembers_text['validation--message_termination-failed']['text']          = 'Dieses Feld wird benötigt.';

$qmembers_text['validation--disclaimer_termination-failed']['text']       = 'Bitte bestätigen Sie dies.';

$qmembers_text['validation--password_old_settings-failed']['text']        = 'Bitte geben Sie Ihr altes Passwort ein.';

$qmembers_text['validation--password_new_settings-failed']['text']        = 'Dieses Feld wird benötigt. Bitte verwenden Sie min. 6 und max. 20 Zeichen. Nur Buchstaben, Zahlen und Bindestriche werden akzeptiert.';

$qmembers_text['validation--password_new_repeat_settings-failed']['text'] = 'Die zweite Eingabe des neuen Passworts ist nicht identisch mit der ersten.';

$qmembers_text['validation--search_memberlist-failed']['text']            = ''; // Not needed.

$qmembers_text['validation--change_password-failed']['text']              = 'Dieses Feld wird benötigt. Bitte verwenden Sie min. 6 und max. 20 Zeichen. Nur Buchstaben, Zahlen und Bindestriche werden akzeptiert.';

$qmembers_text['validation--repeat_change_password-failed']['text']       = 'Die (neuen) Passwörter müssen übereinstimmen.';



// Group details

$qmembers_text['group-details--no-group-id-passed-therefore-no-group-details']['text']      = 'Die Gruppendetails können nicht angezeigt werden, weil keine Gruppen-ID übermittelt wurde.';

$qmembers_text['group-details--could-not-retrieve-group-details']['text']                   = 'Die Details dieser Gruppe können nicht angezeigt werden.';

$qmembers_text['group-details--no-title']['text']                                           = 'Keine Gruppendetails';

$qmembers_text['group-details--back-to-list']['text']                                       = 'Zurück zur Liste';


// Errors
$qmembers_text['saving-member-data-failed']['text']                                         = 'Ihre Daten konnten nicht gespeichert werden.';

$qmembers_text['saving-member-data-to-session-failed']['text']                              = 'Ihre Daten wurden in der Datenbank gespeichert, konnten aber nicht in der Session gespeichert werden. Bitte loggen Sie sich aus und danach wieder ein.';

$qmembers_text['saving-profile-image-failed']['text']                                       = 'Ihr Bild konnte nicht gespeichert werden.';


// Membership level display name
$qmembers_text['membership-level-display-name-full-member']['text']                         = 'Vollmitglied';

$qmembers_text['membership-level-display-name-support-member']['text']                      = 'Fördermitglied';

$qmembers_text['membership-level-display-name-alumni-member']['text']                       = 'Alumnimitglied';


// Loading
$qmembers_text['data-is-being-saved']['text']                                               = 'Daten werden gespeichert... Einen Moment bitte.';

// Restricted uploads
$qmembers_text['error-search-results-cannot-be-displayed']['text']                          = 'Fehler: Es können keine Suchergebnisse angezeigt werden. Bitte versuchen Sie es noch einmal.';
$qmembers_text['restricted-uploads-placeholder-search-field']['text']                       = 'Datei suchen';
$qmembers_text['restricted-uploads-filter1-option-all']['text']                             = 'Alle Kategorien';
$qmembers_text['restricted-uploads-filter2-option-all']['text']                             = 'Alle meine Gruppen';
$qmembers_text['restricted-uploads-search-submit-button']['text']                           = 'Suchen';
$qmembers_text['you-are-not-allowed-to-upload-files']['text']                               = 'Sie haben nicht die nötige Berechtigung, um Dateien hochzuladen.';





?>