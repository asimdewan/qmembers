<?php

require dirname(__FILE__) . '/paths.php';
require QMEMBERS_FILE_AUTOLOAD;
require QMEMBERS_FILE_DEFAULT_CONFIG;
if ( file_exists( QMEMBERS_FILE_CONFIG ) ) require QMEMBERS_FILE_CONFIG;

//drupal_session_start();

use includes\classes\Init;
$init = new Init;

require QMEMBERS_FILE_DRUPAL_FUNCTIONS;

?>