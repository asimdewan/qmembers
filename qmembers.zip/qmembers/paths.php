<?php

// Identify local dev mode
if ( $_SERVER['SERVER_NAME'] == 'quadriga-bdp.dd' ) define( 'QMEMBERS_DEV_MODE', true );
else 												define( 'QMEMBERS_DEV_MODE', false );


// GENERAL
define( 'QMEMBERS_MODULE_NAME', basename(dirname(__FILE__)) );

if (QMEMBERS_DEV_MODE) define( 'QMEMBERS_HOME_URL', 'http' . (isset($_SERVER['HTTPS']) ? 's' : '') . '://' . $_SERVER['SERVER_NAME'] . ':' . $_SERVER['SERVER_PORT'] . '/' ); 
else 					define( 'QMEMBERS_HOME_URL', 'http' . (isset($_SERVER['HTTPS']) ? 's' : '') . '://' . $_SERVER['SERVER_NAME'] . '/' );

define( 'QMEMBERS_ROOT_PATH', dirname(__FILE__) . '/' );
define( 'QMEMBERS_RELATIVE_PATH', drupal_get_path('module', QMEMBERS_MODULE_NAME) . '/' );   
define( 'QMEMBERS_ROOT_PATH_URL', QMEMBERS_HOME_URL . 'sites/all/modules/' . QMEMBERS_MODULE_NAME . '/');
define( 'QMEMBERS_CURRENT_URL', 'http' . (isset($_SERVER['HTTPS']) ? 's' : '') . '://' . "{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}" );
define( 'QMEMBERS_CURRENT_URL_WITHOUT_PARAMS', 'http' . (isset($_SERVER['HTTPS']) ? 's' : '') . '://' . "{$_SERVER['HTTP_HOST']}" . parse_url($_SERVER["REQUEST_URI"], PHP_URL_PATH) );
define( 'QMEMBERS_PARENT_DIR_PATH', dirname(dirname(__FILE__)) . '/' );

// DIRECTORIES
$qmembers_id = 'includes';
define( 'QMEMBERS_PATH_INCLUDES',    				QMEMBERS_ROOT_PATH 				    . $qmembers_id . '/' );
define( 'QMEMBERS_PATH_URL_INCLUDES',     			QMEMBERS_ROOT_PATH_URL 			    . $qmembers_id . '/' );

$qmembers_id = 'classes';
define( 'QMEMBERS_PATH_CLASSES',    				QMEMBERS_PATH_INCLUDES 			    . $qmembers_id . '/' );
define( 'QMEMBERS_PATH_URL_CLASSES',     		    QMEMBERS_PATH_URL_INCLUDES 		    . $qmembers_id . '/' );

$qmembers_id = 'nodes';
define( 'QMEMBERS_PATH_NODES',    				    QMEMBERS_PATH_CLASSES 			    . $qmembers_id . '/' );
define( 'QMEMBERS_PATH_URL_NODES',     		        QMEMBERS_PATH_URL_CLASSES 		    . $qmembers_id . '/' );

$qmembers_id = 'templates';
define( 'QMEMBERS_PATH_TEMPLATES',    				QMEMBERS_ROOT_PATH 				    . $qmembers_id . '/' );
define( 'QMEMBERS_PATH_URL_TEMPLATES',     			QMEMBERS_ROOT_PATH_URL 			    . $qmembers_id . '/' );

$qmembers_id = 'template-parts';
define( 'QMEMBERS_PATH_TEMPLATE_PARTS',    			QMEMBERS_PATH_TEMPLATES 		    . $qmembers_id . '/' );
define( 'QMEMBERS_PATH_URL_TEMPLATE_PARTS',     	QMEMBERS_PATH_URL_TEMPLATES 	    . $qmembers_id . '/' );

$qmembers_id = 'forms';
define( 'QMEMBERS_PATH_FORMS',    			        QMEMBERS_PATH_TEMPLATE_PARTS 	    . $qmembers_id . '/' );
define( 'QMEMBERS_PATH_URL_FORMS',     	            QMEMBERS_PATH_URL_TEMPLATE_PARTS    . $qmembers_id . '/' );

$qmembers_id = 'groups';
define( 'QMEMBERS_PATH_TEMPLATE_PARTS_GROUPS',    	QMEMBERS_PATH_TEMPLATE_PARTS 	    . $qmembers_id . '/' );
define( 'QMEMBERS_PATH_URL_TEMPLATE_PARTS_GROUPS',  QMEMBERS_PATH_URL_TEMPLATE_PARTS    . $qmembers_id . '/' );

$qmembers_id = 'member-data';
define( 'QMEMBERS_PATH_MEMBER_DATA',    			QMEMBERS_PATH_TEMPLATE_PARTS 	    . $qmembers_id . '/' );
define( 'QMEMBERS_PATH_URL_MEMBER_DATA',     	    QMEMBERS_PATH_URL_TEMPLATE_PARTS    . $qmembers_id . '/' );

$qmembers_id = 'service-provider';
define( 'QMEMBERS_PATH_SERVICE_PROVIDER',    		QMEMBERS_PATH_TEMPLATE_PARTS 	    . $qmembers_id . '/' );
define( 'QMEMBERS_PATH_URL_SERVICE_PROVIDER',     	QMEMBERS_PATH_URL_TEMPLATE_PARTS    . $qmembers_id . '/' );

$qmembers_id = 'group-details';
define( 'QMEMBERS_PATH_GROUP_DETAILS',    		    QMEMBERS_PATH_TEMPLATE_PARTS 	    . $qmembers_id . '/' );
define( 'QMEMBERS_PATH_URL_GROUP_DETAILS',     	    QMEMBERS_PATH_URL_TEMPLATE_PARTS    . $qmembers_id . '/' );

$qmembers_id = 'restricted-uploads';
define( 'QMEMBERS_PATH_RESTRICTED_UPLOADS',    		QMEMBERS_PATH_TEMPLATE_PARTS 	    . $qmembers_id . '/' );
define( 'QMEMBERS_PATH_URL_RESTRICTED_UPLOADS',     QMEMBERS_PATH_URL_TEMPLATE_PARTS    . $qmembers_id . '/' );

$qmembers_id = 'js';
define( 'QMEMBERS_PATH_JS',    						QMEMBERS_ROOT_PATH 				    . $qmembers_id . '/' );
define( 'QMEMBERS_PATH_URL_JS',     				QMEMBERS_ROOT_PATH_URL 			    . $qmembers_id . '/' );
define( 'QMEMBERS_PATH_RELATIVE_JS',     			QMEMBERS_RELATIVE_PATH 			    . $qmembers_id . '/' );

$qmembers_id = 'css';
define( 'QMEMBERS_PATH_CSS',    					QMEMBERS_ROOT_PATH 				    . $qmembers_id . '/' );
define( 'QMEMBERS_PATH_URL_CSS',     				QMEMBERS_ROOT_PATH_URL 			    . $qmembers_id . '/' );
define( 'QMEMBERS_PATH_RELATIVE_CSS',     			QMEMBERS_RELATIVE_PATH 			    . $qmembers_id . '/' );

$qmembers_id = 'images';
define( 'QMEMBERS_PATH_CSS_IMAGES',    				QMEMBERS_PATH_CSS 				    . $qmembers_id . '/' );
define( 'QMEMBERS_PATH_URL_CSS_IMAGES',     		QMEMBERS_PATH_URL_CSS 			    . $qmembers_id . '/' );
define( 'QMEMBERS_PATH_RELATIVE_CSS_IMAGES',     	QMEMBERS_PATH_RELATIVE_CSS 			. $qmembers_id . '/' );

$qmembers_id = 'vendor';
define( 'QMEMBERS_PATH_VENDOR',    			        QMEMBERS_ROOT_PATH 	                . $qmembers_id . '/' );
define( 'QMEMBERS_PATH_URL_VENDOR',     	        QMEMBERS_ROOT_PATH_URL              . $qmembers_id . '/' );

$qmembers_id = '';
define( 'QMEMBERS_PATH_FILE_UPLOADS',    	        getcwd()  		                    . '/sites/default/files/qmembers/' );
define( 'QMEMBERS_PATH_URL_FILE_UPLOADS',    	    QMEMBERS_HOME_URL  		            . 'sites/default/files/qmembers/' );

$qmembers_id = '';
define( 'QMEMBERS_PATH_PROFILE_IMAGES',    	        QMEMBERS_PATH_FILE_UPLOADS  		. 'profile_images/' );
define( 'QMEMBERS_PATH_URL_PROFILE_IMAGES',    	    QMEMBERS_PATH_URL_FILE_UPLOADS      . 'profile_images/' );

// FILES
$qmembers_id = 'default.config';
define( 'QMEMBERS_FILE_DEFAULT_CONFIG',    			QMEMBERS_ROOT_PATH 				    . $qmembers_id . '.php' );
define( 'QMEMBERS_FILE_URL_DEFAULT_CONFIG',     	QMEMBERS_ROOT_PATH_URL 			    . $qmembers_id . '.php' );

$qmembers_id = 'config';
define( 'QMEMBERS_FILE_CONFIG',    					QMEMBERS_ROOT_PATH 				    . $qmembers_id . '.php' );
define( 'QMEMBERS_FILE_URL_CONFIG',     			QMEMBERS_ROOT_PATH_URL 			    . $qmembers_id . '.php' );

$qmembers_id = 'text';
define( 'QMEMBERS_FILE_TEXT',    					QMEMBERS_PATH_INCLUDES 			    . $qmembers_id . '.php' );
define( 'QMEMBERS_FILE_URL_TEXT',     				QMEMBERS_PATH_URL_INCLUDES 		    . $qmembers_id . '.php' );

$qmembers_id = 'autoload';
define( 'QMEMBERS_FILE_AUTOLOAD',    			    QMEMBERS_ROOT_PATH 				    . $qmembers_id . '.php' );
define( 'QMEMBERS_FILE_URL_AUTOLOAD',     	        QMEMBERS_ROOT_PATH_URL 			    . $qmembers_id . '.php' );

$qmembers_id = 'drupal-functions';
define( 'QMEMBERS_FILE_DRUPAL_FUNCTIONS',    		QMEMBERS_PATH_INCLUDES 			    . $qmembers_id . '.php' );
define( 'QMEMBERS_FILE_URL_DRUPAL_FUNCTIONS',     	QMEMBERS_PATH_URL_INCLUDES 		    . $qmembers_id . '.php' );

$qmembers_id = 'add-scripts-and-css';
define( 'QMEMBERS_FILE_ADD_SCRIPTS_AND_CSS',    	QMEMBERS_PATH_INCLUDES 			    . $qmembers_id . '.php' );
define( 'QMEMBERS_FILE_URL_ADD_SCRIPTS_AND_CSS',    QMEMBERS_PATH_URL_INCLUDES 		    . $qmembers_id . '.php' );

$qmembers_id = 'template-init';
define( 'QMEMBERS_FILE_TEMPLATE_INIT',    			QMEMBERS_PATH_INCLUDES 			    . $qmembers_id . '.php' );
define( 'QMEMBERS_FILE_URL_TEMPLATE_INIT',     		QMEMBERS_PATH_URL_INCLUDES 		    . $qmembers_id . '.php' );

$qmembers_id = 'ajax';
define( 'QMEMBERS_FILE_AJAX',    					QMEMBERS_PATH_INCLUDES  		    . $qmembers_id . '.php' );
define( 'QMEMBERS_FILE_URL_AJAX',     			    QMEMBERS_PATH_URL_INCLUDES 		    . $qmembers_id . '.php' );

$qmembers_id = 'wixel/gump/gump.class';
define( 'QMEMBERS_FILE_GUMP_VALIDATION',    	    QMEMBERS_PATH_VENDOR  		        . $qmembers_id . '.php' );

$qmembers_id = 'phpmailer/class.phpmailer';
define( 'QMEMBERS_FILE_PHPMAILER',    	            QMEMBERS_PATH_VENDOR  		        . $qmembers_id . '.php' );

$qmembers_id = 'profile-placeholder';
define( 'QMEMBERS_FILE_PROFILE_PLACEHOLDER_IMAGE',    	QMEMBERS_PATH_CSS_IMAGES  		. $qmembers_id . '.jpg' );
define( 'QMEMBERS_FILE_URL_PROFILE_PLACEHOLDER_IMAGE',  QMEMBERS_PATH_URL_CSS_IMAGES    . $qmembers_id . '.jpg' );


// QMEMBERSCOM DIRECTORIES
define( 'QMEMBERS_COM_PATH_TEMPLATE_PARTS',    			QMEMBERS_PARENT_DIR_PATH 		. 'qmemberscom/templates/template-parts/' );

// QMEMBERSCOM FILES
define( 'QMEMBERS_COM_TEXT',    			            QMEMBERS_PARENT_DIR_PATH 		. 'qmemberscom/includes/text.php' );

// DRUPAL AJAX PATH
define( 'QMEMBERS_DRUPAL_AJAX_PATH', '/qmembers/ajax' );


?>