<?php

spl_autoload_register(function ($name) {

    $fileName = __DIR__ . DIRECTORY_SEPARATOR . str_replace('\\', DIRECTORY_SEPARATOR, $name) . '.class.php';

    // Autoload for vendor PhpAmqpLib
    if (!file_exists($fileName)) {
        if (substr( $name, 0, 10 ) === "PhpAmqpLib") {

            $fileName = __DIR__ . '/vendor/php-amqplib/php-amqplib' . DIRECTORY_SEPARATOR . str_replace('\\', DIRECTORY_SEPARATOR, $name) . '.php';
        }
    }
    if (file_exists($fileName)) {
        require_once $fileName;
    }
});
